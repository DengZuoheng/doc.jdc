--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.5
-- Dumped by pg_dump version 9.3.5
-- Started on 2014-12-26 10:49:05 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

DROP SCHEMA IF EXISTS restore CASCADE; CREATE SCHEMA restore; SET search_path = restore, public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 270 (class 1259 OID 18617)
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE api_keys (
    id integer NOT NULL,
    key character varying(64) NOT NULL,
    user_id integer,
    created_by_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 269 (class 1259 OID 18615)
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE api_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3288 (class 0 OID 0)
-- Dependencies: 269
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE api_keys_id_seq OWNED BY api_keys.id;


--
-- TOC entry 311 (class 1259 OID 19190)
-- Name: badge_groupings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE badge_groupings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "position" integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 310 (class 1259 OID 19188)
-- Name: badge_groupings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE badge_groupings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3289 (class 0 OID 0)
-- Dependencies: 310
-- Name: badge_groupings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE badge_groupings_id_seq OWNED BY badge_groupings.id;


--
-- TOC entry 196 (class 1259 OID 17202)
-- Name: categories; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    color character varying(6) DEFAULT 'AB9364'::character varying NOT NULL,
    topic_id integer,
    topic_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer NOT NULL,
    topics_year integer DEFAULT 0,
    topics_month integer DEFAULT 0,
    topics_week integer DEFAULT 0,
    slug character varying(255) NOT NULL,
    description text,
    text_color character varying(6) DEFAULT 'FFFFFF'::character varying NOT NULL,
    read_restricted boolean DEFAULT false NOT NULL,
    auto_close_hours double precision,
    post_count integer DEFAULT 0 NOT NULL,
    latest_post_id integer,
    latest_topic_id integer,
    "position" integer,
    parent_category_id integer,
    posts_year integer DEFAULT 0,
    posts_month integer DEFAULT 0,
    posts_week integer DEFAULT 0,
    email_in character varying(255),
    email_in_allow_strangers boolean DEFAULT false,
    topics_day integer DEFAULT 0,
    posts_day integer DEFAULT 0,
    logo_url character varying(255),
    background_url character varying(255),
    allow_badges boolean DEFAULT true NOT NULL,
    name_lower character varying(50) NOT NULL,
    auto_close_based_on_last_post boolean DEFAULT false
);


--
-- TOC entry 176 (class 1259 OID 16742)
-- Name: posts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts (
    id integer NOT NULL,
    user_id integer,
    topic_id integer NOT NULL,
    post_number integer NOT NULL,
    raw text NOT NULL,
    cooked text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    reply_to_post_number integer,
    reply_count integer DEFAULT 0 NOT NULL,
    quote_count integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    off_topic_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    incoming_link_count integer DEFAULT 0 NOT NULL,
    bookmark_count integer DEFAULT 0 NOT NULL,
    avg_time integer,
    score double precision,
    reads integer DEFAULT 0 NOT NULL,
    post_type integer DEFAULT 1 NOT NULL,
    vote_count integer DEFAULT 0 NOT NULL,
    sort_order integer,
    last_editor_id integer,
    hidden boolean DEFAULT false NOT NULL,
    hidden_reason_id integer,
    notify_moderators_count integer DEFAULT 0 NOT NULL,
    spam_count integer DEFAULT 0 NOT NULL,
    illegal_count integer DEFAULT 0 NOT NULL,
    inappropriate_count integer DEFAULT 0 NOT NULL,
    last_version_at timestamp without time zone NOT NULL,
    user_deleted boolean DEFAULT false NOT NULL,
    reply_to_user_id integer,
    percent_rank double precision DEFAULT 1.0,
    notify_user_count integer DEFAULT 0 NOT NULL,
    like_score integer DEFAULT 0 NOT NULL,
    deleted_by_id integer,
    edit_reason character varying(255),
    word_count integer,
    version integer DEFAULT 1 NOT NULL,
    cook_method integer DEFAULT 1 NOT NULL,
    wiki boolean DEFAULT false NOT NULL,
    baked_at timestamp without time zone,
    baked_version integer,
    hidden_at timestamp without time zone,
    self_edits integer DEFAULT 0 NOT NULL,
    reply_quoted boolean DEFAULT false NOT NULL,
    via_email boolean DEFAULT false NOT NULL,
    raw_email text,
    public_version integer DEFAULT 1 NOT NULL
);


--
-- TOC entry 174 (class 1259 OID 16734)
-- Name: topics; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topics (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    last_posted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    posts_count integer DEFAULT 0 NOT NULL,
    user_id integer,
    last_post_user_id integer NOT NULL,
    reply_count integer DEFAULT 0 NOT NULL,
    featured_user1_id integer,
    featured_user2_id integer,
    featured_user3_id integer,
    avg_time integer,
    deleted_at timestamp without time zone,
    highest_post_number integer DEFAULT 0 NOT NULL,
    image_url character varying(255),
    off_topic_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    incoming_link_count integer DEFAULT 0 NOT NULL,
    bookmark_count integer DEFAULT 0 NOT NULL,
    star_count integer DEFAULT 0 NOT NULL,
    category_id integer,
    visible boolean DEFAULT true NOT NULL,
    moderator_posts_count integer DEFAULT 0 NOT NULL,
    closed boolean DEFAULT false NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    bumped_at timestamp without time zone NOT NULL,
    has_summary boolean DEFAULT false NOT NULL,
    vote_count integer DEFAULT 0 NOT NULL,
    archetype character varying(255) DEFAULT 'regular'::character varying NOT NULL,
    featured_user4_id integer,
    notify_moderators_count integer DEFAULT 0 NOT NULL,
    spam_count integer DEFAULT 0 NOT NULL,
    illegal_count integer DEFAULT 0 NOT NULL,
    inappropriate_count integer DEFAULT 0 NOT NULL,
    pinned_at timestamp without time zone,
    score double precision,
    percent_rank double precision DEFAULT 1.0 NOT NULL,
    notify_user_count integer DEFAULT 0 NOT NULL,
    subtype character varying(255),
    slug character varying(255),
    auto_close_at timestamp without time zone,
    auto_close_user_id integer,
    auto_close_started_at timestamp without time zone,
    deleted_by_id integer,
    participant_count integer DEFAULT 1,
    word_count integer,
    excerpt character varying(1000),
    pinned_globally boolean DEFAULT false NOT NULL,
    auto_close_based_on_last_post boolean DEFAULT false,
    auto_close_hours double precision,
    CONSTRAINT has_category_id CHECK (((category_id IS NOT NULL) OR ((archetype)::text <> 'regular'::text))),
    CONSTRAINT pm_has_no_category CHECK (((category_id IS NULL) OR ((archetype)::text <> 'private_message'::text)))
);


--
-- TOC entry 317 (class 1259 OID 19336)
-- Name: badge_posts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW badge_posts AS
 SELECT p.id,
    p.user_id,
    p.topic_id,
    p.post_number,
    p.raw,
    p.cooked,
    p.created_at,
    p.updated_at,
    p.reply_to_post_number,
    p.reply_count,
    p.quote_count,
    p.deleted_at,
    p.off_topic_count,
    p.like_count,
    p.incoming_link_count,
    p.bookmark_count,
    p.avg_time,
    p.score,
    p.reads,
    p.post_type,
    p.vote_count,
    p.sort_order,
    p.last_editor_id,
    p.hidden,
    p.hidden_reason_id,
    p.notify_moderators_count,
    p.spam_count,
    p.illegal_count,
    p.inappropriate_count,
    p.last_version_at,
    p.user_deleted,
    p.reply_to_user_id,
    p.percent_rank,
    p.notify_user_count,
    p.like_score,
    p.deleted_by_id,
    p.edit_reason,
    p.word_count,
    p.version,
    p.cook_method,
    p.wiki,
    p.baked_at,
    p.baked_version,
    p.hidden_at,
    p.self_edits,
    p.reply_quoted
   FROM ((posts p
     JOIN topics t ON ((t.id = p.topic_id)))
     JOIN categories c ON ((c.id = t.category_id)))
  WHERE ((((c.allow_badges AND (p.deleted_at IS NULL)) AND (t.deleted_at IS NULL)) AND (NOT c.read_restricted)) AND t.visible);


--
-- TOC entry 282 (class 1259 OID 18832)
-- Name: badge_types; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE badge_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 281 (class 1259 OID 18830)
-- Name: badge_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE badge_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3290 (class 0 OID 0)
-- Dependencies: 281
-- Name: badge_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE badge_types_id_seq OWNED BY badge_types.id;


--
-- TOC entry 284 (class 1259 OID 18844)
-- Name: badges; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE badges (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    badge_type_id integer NOT NULL,
    grant_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    allow_title boolean DEFAULT false NOT NULL,
    multiple_grant boolean DEFAULT false NOT NULL,
    icon character varying(255) DEFAULT 'fa-certificate'::character varying,
    listable boolean DEFAULT true,
    target_posts boolean DEFAULT false,
    query text,
    enabled boolean DEFAULT true NOT NULL,
    auto_revoke boolean DEFAULT true NOT NULL,
    badge_grouping_id integer DEFAULT 5 NOT NULL,
    trigger integer,
    show_posts boolean DEFAULT false NOT NULL,
    system boolean DEFAULT false NOT NULL,
    image character varying(255)
);


--
-- TOC entry 283 (class 1259 OID 18842)
-- Name: badges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE badges_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3291 (class 0 OID 0)
-- Dependencies: 283
-- Name: badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE badges_id_seq OWNED BY badges.id;


--
-- TOC entry 195 (class 1259 OID 17200)
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3292 (class 0 OID 0)
-- Dependencies: 195
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- TOC entry 294 (class 1259 OID 18961)
-- Name: category_custom_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_custom_fields (
    id integer NOT NULL,
    category_id integer NOT NULL,
    name character varying(256) NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 293 (class 1259 OID 18959)
-- Name: category_custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3293 (class 0 OID 0)
-- Dependencies: 293
-- Name: category_custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_custom_fields_id_seq OWNED BY category_custom_fields.id;


--
-- TOC entry 197 (class 1259 OID 17212)
-- Name: category_featured_topics; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_featured_topics (
    category_id integer NOT NULL,
    topic_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    id integer NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 18420)
-- Name: category_featured_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_featured_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3294 (class 0 OID 0)
-- Dependencies: 254
-- Name: category_featured_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_featured_topics_id_seq OWNED BY category_featured_topics.id;


--
-- TOC entry 210 (class 1259 OID 17398)
-- Name: category_featured_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_featured_users (
    id integer NOT NULL,
    category_id integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 209 (class 1259 OID 17396)
-- Name: category_featured_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_featured_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3295 (class 0 OID 0)
-- Dependencies: 209
-- Name: category_featured_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_featured_users_id_seq OWNED BY category_featured_users.id;


--
-- TOC entry 247 (class 1259 OID 18253)
-- Name: category_groups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_groups (
    id integer NOT NULL,
    category_id integer NOT NULL,
    group_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    permission_type integer DEFAULT 1
);


--
-- TOC entry 246 (class 1259 OID 18251)
-- Name: category_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3296 (class 0 OID 0)
-- Dependencies: 246
-- Name: category_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_groups_id_seq OWNED BY category_groups.id;


--
-- TOC entry 236 (class 1259 OID 17840)
-- Name: category_search_data; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_search_data (
    category_id integer NOT NULL,
    search_data tsvector,
    raw_data text,
    locale text
);


--
-- TOC entry 278 (class 1259 OID 18749)
-- Name: category_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_users (
    id integer NOT NULL,
    category_id integer NOT NULL,
    user_id integer NOT NULL,
    notification_level integer NOT NULL
);


--
-- TOC entry 277 (class 1259 OID 18747)
-- Name: category_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3297 (class 0 OID 0)
-- Dependencies: 277
-- Name: category_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_users_id_seq OWNED BY category_users.id;


--
-- TOC entry 290 (class 1259 OID 18930)
-- Name: color_scheme_colors; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE color_scheme_colors (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    hex character varying(255) NOT NULL,
    color_scheme_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 289 (class 1259 OID 18928)
-- Name: color_scheme_colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE color_scheme_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3298 (class 0 OID 0)
-- Dependencies: 289
-- Name: color_scheme_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE color_scheme_colors_id_seq OWNED BY color_scheme_colors.id;


--
-- TOC entry 288 (class 1259 OID 18920)
-- Name: color_schemes; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE color_schemes (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    versioned_id integer,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 287 (class 1259 OID 18918)
-- Name: color_schemes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE color_schemes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3299 (class 0 OID 0)
-- Dependencies: 287
-- Name: color_schemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE color_schemes_id_seq OWNED BY color_schemes.id;


--
-- TOC entry 233 (class 1259 OID 17792)
-- Name: draft_sequences; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE draft_sequences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    draft_key character varying(255) NOT NULL,
    sequence integer NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 17790)
-- Name: draft_sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE draft_sequences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3300 (class 0 OID 0)
-- Dependencies: 232
-- Name: draft_sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE draft_sequences_id_seq OWNED BY draft_sequences.id;


--
-- TOC entry 229 (class 1259 OID 17703)
-- Name: drafts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE drafts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    draft_key character varying(255) NOT NULL,
    data text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    sequence integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 17701)
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE drafts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3301 (class 0 OID 0)
-- Dependencies: 228
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE drafts_id_seq OWNED BY drafts.id;


--
-- TOC entry 215 (class 1259 OID 17519)
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_logs (
    id integer NOT NULL,
    to_address character varying(255) NOT NULL,
    email_type character varying(255) NOT NULL,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    reply_key character varying(32),
    post_id integer,
    topic_id integer,
    skipped boolean DEFAULT false,
    skipped_reason character varying(255)
);


--
-- TOC entry 214 (class 1259 OID 17517)
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE email_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3302 (class 0 OID 0)
-- Dependencies: 214
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE email_logs_id_seq OWNED BY email_logs.id;


--
-- TOC entry 227 (class 1259 OID 17689)
-- Name: email_tokens; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    confirmed boolean DEFAULT false NOT NULL,
    expired boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 17687)
-- Name: email_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE email_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3303 (class 0 OID 0)
-- Dependencies: 226
-- Name: email_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE email_tokens_id_seq OWNED BY email_tokens.id;


--
-- TOC entry 219 (class 1259 OID 17576)
-- Name: facebook_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE facebook_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    facebook_user_id bigint NOT NULL,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    gender character varying(255),
    name character varying(255),
    link character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 17574)
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE facebook_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3304 (class 0 OID 0)
-- Dependencies: 218
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE facebook_user_infos_id_seq OWNED BY facebook_user_infos.id;


--
-- TOC entry 238 (class 1259 OID 18043)
-- Name: github_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE github_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    screen_name character varying(255) NOT NULL,
    github_user_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 18041)
-- Name: github_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE github_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3305 (class 0 OID 0)
-- Dependencies: 237
-- Name: github_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE github_user_infos_id_seq OWNED BY github_user_infos.id;


--
-- TOC entry 304 (class 1259 OID 19036)
-- Name: google_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE google_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    google_user_id character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    gender character varying(255),
    name character varying(255),
    link character varying(255),
    profile_link character varying(255),
    picture character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 19034)
-- Name: google_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE google_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3306 (class 0 OID 0)
-- Dependencies: 303
-- Name: google_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE google_user_infos_id_seq OWNED BY google_user_infos.id;


--
-- TOC entry 296 (class 1259 OID 18972)
-- Name: group_custom_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE group_custom_fields (
    id integer NOT NULL,
    group_id integer NOT NULL,
    name character varying(256) NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 18970)
-- Name: group_custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE group_custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3307 (class 0 OID 0)
-- Dependencies: 295
-- Name: group_custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE group_custom_fields_id_seq OWNED BY group_custom_fields.id;


--
-- TOC entry 245 (class 1259 OID 18231)
-- Name: group_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE group_users (
    id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 18229)
-- Name: group_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE group_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3308 (class 0 OID 0)
-- Dependencies: 244
-- Name: group_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE group_users_id_seq OWNED BY group_users.id;


--
-- TOC entry 243 (class 1259 OID 18223)
-- Name: groups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    automatic boolean DEFAULT false NOT NULL,
    user_count integer DEFAULT 0 NOT NULL,
    alias_level integer DEFAULT 0,
    visible boolean DEFAULT true NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 18221)
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE groups_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3309 (class 0 OID 0)
-- Dependencies: 242
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE groups_id_seq OWNED BY groups.id;


--
-- TOC entry 315 (class 1259 OID 19261)
-- Name: incoming_domains; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE incoming_domains (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    https boolean DEFAULT false NOT NULL,
    port integer NOT NULL
);


--
-- TOC entry 314 (class 1259 OID 19259)
-- Name: incoming_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE incoming_domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3310 (class 0 OID 0)
-- Dependencies: 314
-- Name: incoming_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE incoming_domains_id_seq OWNED BY incoming_domains.id;


--
-- TOC entry 193 (class 1259 OID 17116)
-- Name: incoming_links; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE incoming_links (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    user_id integer,
    ip_address inet,
    current_user_id integer,
    post_id integer NOT NULL,
    incoming_referer_id integer
);


--
-- TOC entry 192 (class 1259 OID 17114)
-- Name: incoming_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE incoming_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3311 (class 0 OID 0)
-- Dependencies: 192
-- Name: incoming_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE incoming_links_id_seq OWNED BY incoming_links.id;


--
-- TOC entry 313 (class 1259 OID 19250)
-- Name: incoming_referers; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE incoming_referers (
    id integer NOT NULL,
    path character varying(1000) NOT NULL,
    incoming_domain_id integer NOT NULL
);


--
-- TOC entry 312 (class 1259 OID 19248)
-- Name: incoming_referers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE incoming_referers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3312 (class 0 OID 0)
-- Dependencies: 312
-- Name: incoming_referers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE incoming_referers_id_seq OWNED BY incoming_referers.id;


--
-- TOC entry 302 (class 1259 OID 19018)
-- Name: invited_groups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invited_groups (
    id integer NOT NULL,
    group_id integer,
    invite_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 301 (class 1259 OID 19016)
-- Name: invited_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE invited_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3313 (class 0 OID 0)
-- Dependencies: 301
-- Name: invited_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE invited_groups_id_seq OWNED BY invited_groups.id;


--
-- TOC entry 221 (class 1259 OID 17659)
-- Name: invites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invites (
    id integer NOT NULL,
    invite_key character varying(32) NOT NULL,
    email character varying(255),
    invited_by_id integer NOT NULL,
    user_id integer,
    redeemed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    invalidated_at timestamp without time zone
);


--
-- TOC entry 220 (class 1259 OID 17657)
-- Name: invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3314 (class 0 OID 0)
-- Dependencies: 220
-- Name: invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE invites_id_seq OWNED BY invites.id;


--
-- TOC entry 189 (class 1259 OID 16959)
-- Name: message_bus; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE message_bus (
    id integer NOT NULL,
    name character varying(255),
    context character varying(255),
    data text,
    created_at timestamp without time zone NOT NULL
);


--
-- TOC entry 188 (class 1259 OID 16957)
-- Name: message_bus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE message_bus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3315 (class 0 OID 0)
-- Dependencies: 188
-- Name: message_bus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE message_bus_id_seq OWNED BY message_bus.id;


--
-- TOC entry 191 (class 1259 OID 16982)
-- Name: notifications; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE notifications (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    user_id integer NOT NULL,
    data character varying(1000) NOT NULL,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    topic_id integer,
    post_number integer,
    post_action_id integer
);


--
-- TOC entry 190 (class 1259 OID 16980)
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3316 (class 0 OID 0)
-- Dependencies: 190
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE notifications_id_seq OWNED BY notifications.id;


--
-- TOC entry 261 (class 1259 OID 18486)
-- Name: oauth2_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE oauth2_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    uid character varying(255) NOT NULL,
    provider character varying(255) NOT NULL,
    email character varying(255),
    name character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 18484)
-- Name: oauth2_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE oauth2_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3317 (class 0 OID 0)
-- Dependencies: 260
-- Name: oauth2_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE oauth2_user_infos_id_seq OWNED BY oauth2_user_infos.id;


--
-- TOC entry 253 (class 1259 OID 18365)
-- Name: optimized_images; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE optimized_images (
    id integer NOT NULL,
    sha1 character varying(40) NOT NULL,
    extension character varying(10) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    upload_id integer NOT NULL,
    url character varying(255) NOT NULL
);


--
-- TOC entry 252 (class 1259 OID 18363)
-- Name: optimized_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE optimized_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3318 (class 0 OID 0)
-- Dependencies: 252
-- Name: optimized_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE optimized_images_id_seq OWNED BY optimized_images.id;


--
-- TOC entry 319 (class 1259 OID 19343)
-- Name: permalinks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE permalinks (
    id integer NOT NULL,
    url character varying(1000) NOT NULL,
    topic_id integer,
    post_id integer,
    category_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    external_url character varying(1000)
);


--
-- TOC entry 318 (class 1259 OID 19341)
-- Name: permalinks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE permalinks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3319 (class 0 OID 0)
-- Dependencies: 318
-- Name: permalinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE permalinks_id_seq OWNED BY permalinks.id;


--
-- TOC entry 263 (class 1259 OID 18503)
-- Name: plugin_store_rows; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE plugin_store_rows (
    id integer NOT NULL,
    plugin_name character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    type_name character varying(255) NOT NULL,
    value text
);


--
-- TOC entry 262 (class 1259 OID 18501)
-- Name: plugin_store_rows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE plugin_store_rows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3320 (class 0 OID 0)
-- Dependencies: 262
-- Name: plugin_store_rows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE plugin_store_rows_id_seq OWNED BY plugin_store_rows.id;


--
-- TOC entry 206 (class 1259 OID 17318)
-- Name: post_action_types; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_action_types (
    name_key character varying(50) NOT NULL,
    is_flag boolean DEFAULT false NOT NULL,
    icon character varying(20),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    id integer NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 213 (class 1259 OID 17494)
-- Name: post_action_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_action_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3321 (class 0 OID 0)
-- Dependencies: 213
-- Name: post_action_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_action_types_id_seq OWNED BY post_action_types.id;


--
-- TOC entry 205 (class 1259 OID 17310)
-- Name: post_actions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_actions (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    post_action_type_id integer NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_by_id integer,
    related_post_id integer,
    staff_took_action boolean DEFAULT false NOT NULL,
    deferred_by_id integer,
    targets_topic boolean DEFAULT false NOT NULL,
    agreed_at timestamp without time zone,
    agreed_by_id integer,
    deferred_at timestamp without time zone,
    disagreed_at timestamp without time zone,
    disagreed_by_id integer
);


--
-- TOC entry 204 (class 1259 OID 17308)
-- Name: post_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3322 (class 0 OID 0)
-- Dependencies: 204
-- Name: post_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_actions_id_seq OWNED BY post_actions.id;


--
-- TOC entry 298 (class 1259 OID 18983)
-- Name: post_custom_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_custom_fields (
    id integer NOT NULL,
    post_id integer NOT NULL,
    name character varying(256) NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 18981)
-- Name: post_custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3323 (class 0 OID 0)
-- Dependencies: 297
-- Name: post_custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_custom_fields_id_seq OWNED BY post_custom_fields.id;


--
-- TOC entry 266 (class 1259 OID 18580)
-- Name: post_details; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_details (
    id integer NOT NULL,
    post_id integer,
    key character varying(255),
    value character varying(255),
    extra text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 18578)
-- Name: post_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3324 (class 0 OID 0)
-- Dependencies: 265
-- Name: post_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_details_id_seq OWNED BY post_details.id;


--
-- TOC entry 194 (class 1259 OID 17126)
-- Name: post_replies; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_replies (
    post_id integer,
    reply_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 272 (class 1259 OID 18646)
-- Name: post_revisions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_revisions (
    id integer NOT NULL,
    user_id integer,
    post_id integer,
    modifications text,
    number integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    hidden boolean DEFAULT false NOT NULL
);


--
-- TOC entry 271 (class 1259 OID 18644)
-- Name: post_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_revisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3325 (class 0 OID 0)
-- Dependencies: 271
-- Name: post_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_revisions_id_seq OWNED BY post_revisions.id;


--
-- TOC entry 234 (class 1259 OID 17824)
-- Name: post_search_data; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_search_data (
    post_id integer NOT NULL,
    search_data tsvector,
    raw_data text,
    locale character varying(255)
);


--
-- TOC entry 187 (class 1259 OID 16949)
-- Name: post_timings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_timings (
    topic_id integer NOT NULL,
    post_number integer NOT NULL,
    user_id integer NOT NULL,
    msecs integer NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 18342)
-- Name: post_uploads; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_uploads (
    id integer NOT NULL,
    post_id integer NOT NULL,
    upload_id integer NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 18340)
-- Name: post_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3326 (class 0 OID 0)
-- Dependencies: 250
-- Name: post_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_uploads_id_seq OWNED BY post_uploads.id;


--
-- TOC entry 175 (class 1259 OID 16740)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3327 (class 0 OID 0)
-- Dependencies: 175
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_id_seq OWNED BY posts.id;


--
-- TOC entry 309 (class 1259 OID 19179)
-- Name: quoted_posts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE quoted_posts (
    id integer NOT NULL,
    post_id integer NOT NULL,
    quoted_post_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 308 (class 1259 OID 19177)
-- Name: quoted_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE quoted_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3328 (class 0 OID 0)
-- Dependencies: 308
-- Name: quoted_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE quoted_posts_id_seq OWNED BY quoted_posts.id;


--
-- TOC entry 172 (class 1259 OID 16728)
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 18443)
-- Name: screened_emails; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE screened_emails (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    action_type integer NOT NULL,
    match_count integer DEFAULT 0 NOT NULL,
    last_match_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    ip_address inet
);


--
-- TOC entry 256 (class 1259 OID 18441)
-- Name: screened_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE screened_emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3329 (class 0 OID 0)
-- Dependencies: 256
-- Name: screened_emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE screened_emails_id_seq OWNED BY screened_emails.id;


--
-- TOC entry 268 (class 1259 OID 18602)
-- Name: screened_ip_addresses; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE screened_ip_addresses (
    id integer NOT NULL,
    ip_address inet NOT NULL,
    action_type integer NOT NULL,
    match_count integer DEFAULT 0 NOT NULL,
    last_match_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 18600)
-- Name: screened_ip_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE screened_ip_addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3330 (class 0 OID 0)
-- Dependencies: 267
-- Name: screened_ip_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE screened_ip_addresses_id_seq OWNED BY screened_ip_addresses.id;


--
-- TOC entry 259 (class 1259 OID 18472)
-- Name: screened_urls; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE screened_urls (
    id integer NOT NULL,
    url character varying(255) NOT NULL,
    domain character varying(255) NOT NULL,
    action_type integer NOT NULL,
    match_count integer DEFAULT 0 NOT NULL,
    last_match_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    ip_address inet
);


--
-- TOC entry 258 (class 1259 OID 18470)
-- Name: screened_urls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE screened_urls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3331 (class 0 OID 0)
-- Dependencies: 258
-- Name: screened_urls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE screened_urls_id_seq OWNED BY screened_urls.id;


--
-- TOC entry 280 (class 1259 OID 18797)
-- Name: single_sign_on_records; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE single_sign_on_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    external_id character varying(255) NOT NULL,
    last_payload text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    external_username character varying(255),
    external_email character varying(255),
    external_name character varying(255),
    external_avatar_url character varying(255)
);


--
-- TOC entry 279 (class 1259 OID 18795)
-- Name: single_sign_on_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE single_sign_on_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3332 (class 0 OID 0)
-- Dependencies: 279
-- Name: single_sign_on_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE single_sign_on_records_id_seq OWNED BY single_sign_on_records.id;


--
-- TOC entry 231 (class 1259 OID 17734)
-- Name: site_customizations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE site_customizations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    stylesheet text,
    header text,
    "position" integer NOT NULL,
    user_id integer NOT NULL,
    enabled boolean NOT NULL,
    key character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    override_default_style boolean DEFAULT false NOT NULL,
    stylesheet_baked text DEFAULT ''::text NOT NULL,
    mobile_stylesheet text,
    mobile_header text,
    mobile_stylesheet_baked text
);


--
-- TOC entry 230 (class 1259 OID 17732)
-- Name: site_customizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE site_customizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3333 (class 0 OID 0)
-- Dependencies: 230
-- Name: site_customizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE site_customizations_id_seq OWNED BY site_customizations.id;


--
-- TOC entry 199 (class 1259 OID 17218)
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE site_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    data_type integer NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 198 (class 1259 OID 17216)
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE site_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3334 (class 0 OID 0)
-- Dependencies: 198
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE site_settings_id_seq OWNED BY site_settings.id;


--
-- TOC entry 239 (class 1259 OID 18143)
-- Name: site_texts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE site_texts (
    text_type character varying(255) NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 276 (class 1259 OID 18703)
-- Name: top_topics; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE top_topics (
    id integer NOT NULL,
    topic_id integer,
    yearly_posts_count integer DEFAULT 0 NOT NULL,
    yearly_views_count integer DEFAULT 0 NOT NULL,
    yearly_likes_count integer DEFAULT 0 NOT NULL,
    monthly_posts_count integer DEFAULT 0 NOT NULL,
    monthly_views_count integer DEFAULT 0 NOT NULL,
    monthly_likes_count integer DEFAULT 0 NOT NULL,
    weekly_posts_count integer DEFAULT 0 NOT NULL,
    weekly_views_count integer DEFAULT 0 NOT NULL,
    weekly_likes_count integer DEFAULT 0 NOT NULL,
    daily_posts_count integer DEFAULT 0 NOT NULL,
    daily_views_count integer DEFAULT 0 NOT NULL,
    daily_likes_count integer DEFAULT 0 NOT NULL,
    yearly_score double precision DEFAULT 0,
    monthly_score double precision DEFAULT 0,
    weekly_score double precision DEFAULT 0,
    daily_score double precision DEFAULT 0
);


--
-- TOC entry 275 (class 1259 OID 18701)
-- Name: top_topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE top_topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3335 (class 0 OID 0)
-- Dependencies: 275
-- Name: top_topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE top_topics_id_seq OWNED BY top_topics.id;


--
-- TOC entry 249 (class 1259 OID 18261)
-- Name: topic_allowed_groups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_allowed_groups (
    id integer NOT NULL,
    group_id integer NOT NULL,
    topic_id integer NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 18259)
-- Name: topic_allowed_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_allowed_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3336 (class 0 OID 0)
-- Dependencies: 248
-- Name: topic_allowed_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_allowed_groups_id_seq OWNED BY topic_allowed_groups.id;


--
-- TOC entry 217 (class 1259 OID 17543)
-- Name: topic_allowed_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_allowed_users (
    id integer NOT NULL,
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 17541)
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_allowed_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3337 (class 0 OID 0)
-- Dependencies: 216
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_allowed_users_id_seq OWNED BY topic_allowed_users.id;


--
-- TOC entry 300 (class 1259 OID 18997)
-- Name: topic_custom_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_custom_fields (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    name character varying(256) NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 299 (class 1259 OID 18995)
-- Name: topic_custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3338 (class 0 OID 0)
-- Dependencies: 299
-- Name: topic_custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_custom_fields_id_seq OWNED BY topic_custom_fields.id;


--
-- TOC entry 274 (class 1259 OID 18683)
-- Name: topic_embeds; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_embeds (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    post_id integer NOT NULL,
    embed_url character varying(255) NOT NULL,
    content_sha1 character varying(40),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 273 (class 1259 OID 18681)
-- Name: topic_embeds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_embeds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3339 (class 0 OID 0)
-- Dependencies: 273
-- Name: topic_embeds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_embeds_id_seq OWNED BY topic_embeds.id;


--
-- TOC entry 223 (class 1259 OID 17669)
-- Name: topic_invites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_invites (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    invite_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 17667)
-- Name: topic_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3340 (class 0 OID 0)
-- Dependencies: 222
-- Name: topic_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_invites_id_seq OWNED BY topic_invites.id;


--
-- TOC entry 208 (class 1259 OID 17327)
-- Name: topic_link_clicks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_link_clicks (
    id integer NOT NULL,
    topic_link_id integer NOT NULL,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    ip_address inet NOT NULL
);


--
-- TOC entry 207 (class 1259 OID 17325)
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_link_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3341 (class 0 OID 0)
-- Dependencies: 207
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_link_clicks_id_seq OWNED BY topic_link_clicks.id;


--
-- TOC entry 186 (class 1259 OID 16916)
-- Name: topic_links; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_links (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    post_id integer,
    user_id integer NOT NULL,
    url character varying(500) NOT NULL,
    domain character varying(100) NOT NULL,
    internal boolean DEFAULT false NOT NULL,
    link_topic_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    reflection boolean DEFAULT false,
    clicks integer DEFAULT 0 NOT NULL,
    link_post_id integer,
    title character varying(255),
    crawled_at timestamp without time zone,
    quote boolean DEFAULT false NOT NULL
);


--
-- TOC entry 185 (class 1259 OID 16914)
-- Name: topic_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3342 (class 0 OID 0)
-- Dependencies: 185
-- Name: topic_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_links_id_seq OWNED BY topic_links.id;


--
-- TOC entry 316 (class 1259 OID 19304)
-- Name: topic_search_data; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_search_data (
    topic_id integer NOT NULL,
    raw_data text,
    locale character varying(255) NOT NULL,
    search_data tsvector
);


--
-- TOC entry 184 (class 1259 OID 16906)
-- Name: topic_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_users (
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    starred boolean DEFAULT false NOT NULL,
    posted boolean DEFAULT false NOT NULL,
    last_read_post_number integer,
    highest_seen_post_number integer,
    starred_at timestamp without time zone,
    last_visited_at timestamp without time zone,
    first_visited_at timestamp without time zone,
    notification_level integer DEFAULT 1 NOT NULL,
    notifications_changed_at timestamp without time zone,
    notifications_reason_id integer,
    total_msecs_viewed integer DEFAULT 0 NOT NULL,
    cleared_pinned_at timestamp without time zone,
    unstarred_at timestamp without time zone,
    id integer NOT NULL,
    last_emailed_post_number integer,
    CONSTRAINT test_starred_at CHECK (((starred = false) OR (starred_at IS NOT NULL)))
);


--
-- TOC entry 255 (class 1259 OID 18431)
-- Name: topic_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3343 (class 0 OID 0)
-- Dependencies: 255
-- Name: topic_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_users_id_seq OWNED BY topic_users.id;


--
-- TOC entry 181 (class 1259 OID 16879)
-- Name: topic_views; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_views (
    topic_id integer NOT NULL,
    viewed_at date NOT NULL,
    user_id integer,
    ip_address inet NOT NULL
);


--
-- TOC entry 173 (class 1259 OID 16732)
-- Name: topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3344 (class 0 OID 0)
-- Dependencies: 173
-- Name: topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topics_id_seq OWNED BY topics.id;


--
-- TOC entry 212 (class 1259 OID 17435)
-- Name: twitter_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE twitter_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    screen_name character varying(255) NOT NULL,
    twitter_user_id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 211 (class 1259 OID 17433)
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE twitter_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3345 (class 0 OID 0)
-- Dependencies: 211
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE twitter_user_infos_id_seq OWNED BY twitter_user_infos.id;


--
-- TOC entry 183 (class 1259 OID 16891)
-- Name: uploads; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE uploads (
    id integer NOT NULL,
    user_id integer NOT NULL,
    original_filename character varying(255) NOT NULL,
    filesize integer NOT NULL,
    width integer,
    height integer,
    url character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    sha1 character varying(40),
    origin character varying(1000),
    retain_hours integer
);


--
-- TOC entry 182 (class 1259 OID 16889)
-- Name: uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3346 (class 0 OID 0)
-- Dependencies: 182
-- Name: uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE uploads_id_seq OWNED BY uploads.id;


--
-- TOC entry 203 (class 1259 OID 17295)
-- Name: user_actions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_actions (
    id integer NOT NULL,
    action_type integer NOT NULL,
    user_id integer NOT NULL,
    target_topic_id integer,
    target_post_id integer,
    target_user_id integer,
    acting_user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 202 (class 1259 OID 17293)
-- Name: user_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3347 (class 0 OID 0)
-- Dependencies: 202
-- Name: user_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_actions_id_seq OWNED BY user_actions.id;


--
-- TOC entry 306 (class 1259 OID 19049)
-- Name: user_avatars; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_avatars (
    id integer NOT NULL,
    user_id integer NOT NULL,
    custom_upload_id integer,
    gravatar_upload_id integer,
    last_gravatar_download_attempt timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 305 (class 1259 OID 19047)
-- Name: user_avatars_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_avatars_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3348 (class 0 OID 0)
-- Dependencies: 305
-- Name: user_avatars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_avatars_id_seq OWNED BY user_avatars.id;


--
-- TOC entry 286 (class 1259 OID 18857)
-- Name: user_badges; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_badges (
    id integer NOT NULL,
    badge_id integer NOT NULL,
    user_id integer NOT NULL,
    granted_at timestamp without time zone NOT NULL,
    granted_by_id integer NOT NULL,
    post_id integer,
    notification_id integer,
    seq integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 285 (class 1259 OID 18855)
-- Name: user_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3349 (class 0 OID 0)
-- Dependencies: 285
-- Name: user_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_badges_id_seq OWNED BY user_badges.id;


--
-- TOC entry 292 (class 1259 OID 18943)
-- Name: user_custom_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_custom_fields (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(256) NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 291 (class 1259 OID 18941)
-- Name: user_custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3350 (class 0 OID 0)
-- Dependencies: 291
-- Name: user_custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_custom_fields_id_seq OWNED BY user_custom_fields.id;


--
-- TOC entry 323 (class 1259 OID 19395)
-- Name: user_fields; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_fields (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    field_type character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    editable boolean DEFAULT false NOT NULL,
    description character varying(255) NOT NULL,
    required boolean DEFAULT true NOT NULL
);


--
-- TOC entry 322 (class 1259 OID 19393)
-- Name: user_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 322
-- Name: user_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_fields_id_seq OWNED BY user_fields.id;


--
-- TOC entry 241 (class 1259 OID 18191)
-- Name: user_histories; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_histories (
    id integer NOT NULL,
    action integer NOT NULL,
    acting_user_id integer,
    target_user_id integer,
    details text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    context character varying(255),
    ip_address character varying(255),
    email character varying(255),
    subject text,
    previous_value text,
    new_value text,
    topic_id integer,
    admin_only boolean DEFAULT false,
    post_id integer
);


--
-- TOC entry 240 (class 1259 OID 18189)
-- Name: user_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 240
-- Name: user_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_histories_id_seq OWNED BY user_histories.id;


--
-- TOC entry 201 (class 1259 OID 17229)
-- Name: user_open_ids; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_open_ids (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    active boolean NOT NULL
);


--
-- TOC entry 200 (class 1259 OID 17227)
-- Name: user_open_ids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_open_ids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 200
-- Name: user_open_ids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_open_ids_id_seq OWNED BY user_open_ids.id;


--
-- TOC entry 307 (class 1259 OID 19070)
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_profiles (
    user_id integer NOT NULL,
    location character varying(255),
    website character varying(255),
    bio_raw text,
    bio_cooked text,
    profile_background character varying(255),
    dismissed_banner_key integer,
    bio_cooked_version integer,
    badge_granted_title boolean DEFAULT false,
    card_background character varying(255),
    card_image_badge_id integer
);


--
-- TOC entry 235 (class 1259 OID 17832)
-- Name: user_search_data; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_search_data (
    user_id integer NOT NULL,
    search_data tsvector,
    raw_data text,
    locale text
);


--
-- TOC entry 264 (class 1259 OID 18519)
-- Name: user_stats; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_stats (
    user_id integer NOT NULL,
    topics_entered integer DEFAULT 0 NOT NULL,
    time_read integer DEFAULT 0 NOT NULL,
    days_visited integer DEFAULT 0 NOT NULL,
    posts_read_count integer DEFAULT 0 NOT NULL,
    likes_given integer DEFAULT 0 NOT NULL,
    likes_received integer DEFAULT 0 NOT NULL,
    topic_reply_count integer DEFAULT 0 NOT NULL,
    new_since timestamp without time zone NOT NULL,
    read_faq timestamp without time zone,
    first_post_created_at timestamp without time zone,
    post_count integer DEFAULT 0 NOT NULL,
    topic_count integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 17680)
-- Name: user_visits; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_visits (
    id integer NOT NULL,
    user_id integer NOT NULL,
    visited_at date NOT NULL,
    posts_read integer DEFAULT 0
);


--
-- TOC entry 224 (class 1259 OID 17678)
-- Name: user_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_visits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3354 (class 0 OID 0)
-- Dependencies: 224
-- Name: user_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_visits_id_seq OWNED BY user_visits.id;


--
-- TOC entry 178 (class 1259 OID 16754)
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(60) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying(255),
    seen_notification_id integer DEFAULT 0 NOT NULL,
    last_posted_at timestamp without time zone,
    email character varying(256) NOT NULL,
    password_hash character varying(64),
    salt character varying(32),
    active boolean DEFAULT false NOT NULL,
    username_lower character varying(60) NOT NULL,
    auth_token character varying(32),
    last_seen_at timestamp without time zone,
    admin boolean DEFAULT false NOT NULL,
    last_emailed_at timestamp without time zone,
    email_digests boolean NOT NULL,
    trust_level integer NOT NULL,
    email_private_messages boolean DEFAULT true,
    email_direct boolean DEFAULT true NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    approved_by_id integer,
    approved_at timestamp without time zone,
    digest_after_days integer,
    previous_visit_at timestamp without time zone,
    suspended_at timestamp without time zone,
    suspended_till timestamp without time zone,
    date_of_birth date,
    auto_track_topics_after_msecs integer,
    views integer DEFAULT 0 NOT NULL,
    flag_level integer DEFAULT 0 NOT NULL,
    ip_address inet,
    new_topic_duration_minutes integer,
    external_links_in_new_tab boolean NOT NULL,
    enable_quoting boolean DEFAULT true NOT NULL,
    moderator boolean DEFAULT false,
    blocked boolean DEFAULT false,
    dynamic_favicon boolean DEFAULT false NOT NULL,
    title character varying(255),
    uploaded_avatar_id integer,
    email_always boolean DEFAULT false NOT NULL,
    mailing_list_mode boolean DEFAULT false NOT NULL,
    locale character varying(10),
    primary_group_id integer,
    registration_ip_address inet,
    last_redirected_to_top_at timestamp without time zone,
    disable_jump_reply boolean DEFAULT false NOT NULL,
    edit_history_public boolean DEFAULT false NOT NULL,
    trust_level_locked boolean DEFAULT false NOT NULL
);


--
-- TOC entry 177 (class 1259 OID 16752)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3355 (class 0 OID 0)
-- Dependencies: 177
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- TOC entry 180 (class 1259 OID 16795)
-- Name: versions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE versions (
    id integer NOT NULL,
    versioned_id integer,
    versioned_type character varying(255),
    user_id integer,
    user_type character varying(255),
    user_name character varying(255),
    modifications text,
    number integer,
    reverted_from integer,
    tag character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- TOC entry 179 (class 1259 OID 16793)
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3356 (class 0 OID 0)
-- Dependencies: 179
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE versions_id_seq OWNED BY versions.id;


--
-- TOC entry 321 (class 1259 OID 19369)
-- Name: warnings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE warnings (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    user_id integer NOT NULL,
    created_by_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- TOC entry 320 (class 1259 OID 19367)
-- Name: warnings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE warnings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3357 (class 0 OID 0)
-- Dependencies: 320
-- Name: warnings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE warnings_id_seq OWNED BY warnings.id;


--
-- TOC entry 2666 (class 2604 OID 18620)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY api_keys ALTER COLUMN id SET DEFAULT nextval('api_keys_id_seq'::regclass);


--
-- TOC entry 2718 (class 2604 OID 19193)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY badge_groupings ALTER COLUMN id SET DEFAULT nextval('badge_groupings_id_seq'::regclass);


--
-- TOC entry 2689 (class 2604 OID 18835)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY badge_types ALTER COLUMN id SET DEFAULT nextval('badge_types_id_seq'::regclass);


--
-- TOC entry 2690 (class 2604 OID 18847)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY badges ALTER COLUMN id SET DEFAULT nextval('badges_id_seq'::regclass);


--
-- TOC entry 2586 (class 2604 OID 17205)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- TOC entry 2709 (class 2604 OID 18964)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_custom_fields ALTER COLUMN id SET DEFAULT nextval('category_custom_fields_id_seq'::regclass);


--
-- TOC entry 2604 (class 2604 OID 18422)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_featured_topics ALTER COLUMN id SET DEFAULT nextval('category_featured_topics_id_seq'::regclass);


--
-- TOC entry 2615 (class 2604 OID 17401)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_featured_users ALTER COLUMN id SET DEFAULT nextval('category_featured_users_id_seq'::regclass);


--
-- TOC entry 2643 (class 2604 OID 18256)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_groups ALTER COLUMN id SET DEFAULT nextval('category_groups_id_seq'::regclass);


--
-- TOC entry 2687 (class 2604 OID 18752)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_users ALTER COLUMN id SET DEFAULT nextval('category_users_id_seq'::regclass);


--
-- TOC entry 2707 (class 2604 OID 18933)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY color_scheme_colors ALTER COLUMN id SET DEFAULT nextval('color_scheme_colors_id_seq'::regclass);


--
-- TOC entry 2704 (class 2604 OID 18923)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY color_schemes ALTER COLUMN id SET DEFAULT nextval('color_schemes_id_seq'::regclass);


--
-- TOC entry 2633 (class 2604 OID 17795)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY draft_sequences ALTER COLUMN id SET DEFAULT nextval('draft_sequences_id_seq'::regclass);


--
-- TOC entry 2628 (class 2604 OID 17706)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY drafts ALTER COLUMN id SET DEFAULT nextval('drafts_id_seq'::regclass);


--
-- TOC entry 2617 (class 2604 OID 17522)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY email_logs ALTER COLUMN id SET DEFAULT nextval('email_logs_id_seq'::regclass);


--
-- TOC entry 2625 (class 2604 OID 17692)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY email_tokens ALTER COLUMN id SET DEFAULT nextval('email_tokens_id_seq'::regclass);


--
-- TOC entry 2620 (class 2604 OID 17579)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY facebook_user_infos ALTER COLUMN id SET DEFAULT nextval('facebook_user_infos_id_seq'::regclass);


--
-- TOC entry 2634 (class 2604 OID 18046)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY github_user_infos ALTER COLUMN id SET DEFAULT nextval('github_user_infos_id_seq'::regclass);


--
-- TOC entry 2714 (class 2604 OID 19039)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY google_user_infos ALTER COLUMN id SET DEFAULT nextval('google_user_infos_id_seq'::regclass);


--
-- TOC entry 2710 (class 2604 OID 18975)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY group_custom_fields ALTER COLUMN id SET DEFAULT nextval('group_custom_fields_id_seq'::regclass);


--
-- TOC entry 2642 (class 2604 OID 18234)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY group_users ALTER COLUMN id SET DEFAULT nextval('group_users_id_seq'::regclass);


--
-- TOC entry 2637 (class 2604 OID 18226)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY groups ALTER COLUMN id SET DEFAULT nextval('groups_id_seq'::regclass);


--
-- TOC entry 2720 (class 2604 OID 19264)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY incoming_domains ALTER COLUMN id SET DEFAULT nextval('incoming_domains_id_seq'::regclass);


--
-- TOC entry 2585 (class 2604 OID 17119)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY incoming_links ALTER COLUMN id SET DEFAULT nextval('incoming_links_id_seq'::regclass);


--
-- TOC entry 2719 (class 2604 OID 19253)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY incoming_referers ALTER COLUMN id SET DEFAULT nextval('incoming_referers_id_seq'::regclass);


--
-- TOC entry 2713 (class 2604 OID 19021)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY invited_groups ALTER COLUMN id SET DEFAULT nextval('invited_groups_id_seq'::regclass);


--
-- TOC entry 2621 (class 2604 OID 17662)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY invites ALTER COLUMN id SET DEFAULT nextval('invites_id_seq'::regclass);


--
-- TOC entry 2582 (class 2604 OID 16962)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY message_bus ALTER COLUMN id SET DEFAULT nextval('message_bus_id_seq'::regclass);


--
-- TOC entry 2583 (class 2604 OID 16985)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY notifications ALTER COLUMN id SET DEFAULT nextval('notifications_id_seq'::regclass);


--
-- TOC entry 2652 (class 2604 OID 18489)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY oauth2_user_infos ALTER COLUMN id SET DEFAULT nextval('oauth2_user_infos_id_seq'::regclass);


--
-- TOC entry 2647 (class 2604 OID 18368)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY optimized_images ALTER COLUMN id SET DEFAULT nextval('optimized_images_id_seq'::regclass);


--
-- TOC entry 2722 (class 2604 OID 19346)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY permalinks ALTER COLUMN id SET DEFAULT nextval('permalinks_id_seq'::regclass);


--
-- TOC entry 2653 (class 2604 OID 18506)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY plugin_store_rows ALTER COLUMN id SET DEFAULT nextval('plugin_store_rows_id_seq'::regclass);


--
-- TOC entry 2612 (class 2604 OID 17496)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_action_types ALTER COLUMN id SET DEFAULT nextval('post_action_types_id_seq'::regclass);


--
-- TOC entry 2608 (class 2604 OID 17313)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_actions ALTER COLUMN id SET DEFAULT nextval('post_actions_id_seq'::regclass);


--
-- TOC entry 2711 (class 2604 OID 18986)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_custom_fields ALTER COLUMN id SET DEFAULT nextval('post_custom_fields_id_seq'::regclass);


--
-- TOC entry 2663 (class 2604 OID 18583)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_details ALTER COLUMN id SET DEFAULT nextval('post_details_id_seq'::regclass);


--
-- TOC entry 2667 (class 2604 OID 18649)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_revisions ALTER COLUMN id SET DEFAULT nextval('post_revisions_id_seq'::regclass);


--
-- TOC entry 2646 (class 2604 OID 18345)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_uploads ALTER COLUMN id SET DEFAULT nextval('post_uploads_id_seq'::regclass);


--
-- TOC entry 2525 (class 2604 OID 16745)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts ALTER COLUMN id SET DEFAULT nextval('posts_id_seq'::regclass);


--
-- TOC entry 2717 (class 2604 OID 19182)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY quoted_posts ALTER COLUMN id SET DEFAULT nextval('quoted_posts_id_seq'::regclass);


--
-- TOC entry 2648 (class 2604 OID 18446)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY screened_emails ALTER COLUMN id SET DEFAULT nextval('screened_emails_id_seq'::regclass);


--
-- TOC entry 2664 (class 2604 OID 18605)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY screened_ip_addresses ALTER COLUMN id SET DEFAULT nextval('screened_ip_addresses_id_seq'::regclass);


--
-- TOC entry 2650 (class 2604 OID 18475)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY screened_urls ALTER COLUMN id SET DEFAULT nextval('screened_urls_id_seq'::regclass);


--
-- TOC entry 2688 (class 2604 OID 18800)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY single_sign_on_records ALTER COLUMN id SET DEFAULT nextval('single_sign_on_records_id_seq'::regclass);


--
-- TOC entry 2630 (class 2604 OID 17737)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY site_customizations ALTER COLUMN id SET DEFAULT nextval('site_customizations_id_seq'::regclass);


--
-- TOC entry 2605 (class 2604 OID 17221)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY site_settings ALTER COLUMN id SET DEFAULT nextval('site_settings_id_seq'::regclass);


--
-- TOC entry 2670 (class 2604 OID 18706)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY top_topics ALTER COLUMN id SET DEFAULT nextval('top_topics_id_seq'::regclass);


--
-- TOC entry 2645 (class 2604 OID 18264)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_allowed_groups ALTER COLUMN id SET DEFAULT nextval('topic_allowed_groups_id_seq'::regclass);


--
-- TOC entry 2619 (class 2604 OID 17546)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_allowed_users ALTER COLUMN id SET DEFAULT nextval('topic_allowed_users_id_seq'::regclass);


--
-- TOC entry 2712 (class 2604 OID 19000)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_custom_fields ALTER COLUMN id SET DEFAULT nextval('topic_custom_fields_id_seq'::regclass);


--
-- TOC entry 2669 (class 2604 OID 18686)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_embeds ALTER COLUMN id SET DEFAULT nextval('topic_embeds_id_seq'::regclass);


--
-- TOC entry 2622 (class 2604 OID 17672)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_invites ALTER COLUMN id SET DEFAULT nextval('topic_invites_id_seq'::regclass);


--
-- TOC entry 2614 (class 2604 OID 17330)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_link_clicks ALTER COLUMN id SET DEFAULT nextval('topic_link_clicks_id_seq'::regclass);


--
-- TOC entry 2577 (class 2604 OID 16919)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_links ALTER COLUMN id SET DEFAULT nextval('topic_links_id_seq'::regclass);


--
-- TOC entry 2575 (class 2604 OID 18433)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_users ALTER COLUMN id SET DEFAULT nextval('topic_users_id_seq'::regclass);


--
-- TOC entry 2497 (class 2604 OID 16737)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topics ALTER COLUMN id SET DEFAULT nextval('topics_id_seq'::regclass);


--
-- TOC entry 2616 (class 2604 OID 17438)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY twitter_user_infos ALTER COLUMN id SET DEFAULT nextval('twitter_user_infos_id_seq'::regclass);


--
-- TOC entry 2570 (class 2604 OID 16894)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY uploads ALTER COLUMN id SET DEFAULT nextval('uploads_id_seq'::regclass);


--
-- TOC entry 2607 (class 2604 OID 17298)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_actions ALTER COLUMN id SET DEFAULT nextval('user_actions_id_seq'::regclass);


--
-- TOC entry 2715 (class 2604 OID 19052)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_avatars ALTER COLUMN id SET DEFAULT nextval('user_avatars_id_seq'::regclass);


--
-- TOC entry 2702 (class 2604 OID 18860)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_badges ALTER COLUMN id SET DEFAULT nextval('user_badges_id_seq'::regclass);


--
-- TOC entry 2708 (class 2604 OID 18946)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_custom_fields ALTER COLUMN id SET DEFAULT nextval('user_custom_fields_id_seq'::regclass);


--
-- TOC entry 2724 (class 2604 OID 19398)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_fields ALTER COLUMN id SET DEFAULT nextval('user_fields_id_seq'::regclass);


--
-- TOC entry 2635 (class 2604 OID 18194)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_histories ALTER COLUMN id SET DEFAULT nextval('user_histories_id_seq'::regclass);


--
-- TOC entry 2606 (class 2604 OID 17232)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_open_ids ALTER COLUMN id SET DEFAULT nextval('user_open_ids_id_seq'::regclass);


--
-- TOC entry 2623 (class 2604 OID 17683)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_visits ALTER COLUMN id SET DEFAULT nextval('user_visits_id_seq'::regclass);


--
-- TOC entry 2551 (class 2604 OID 16757)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- TOC entry 2569 (class 2604 OID 16798)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY versions ALTER COLUMN id SET DEFAULT nextval('versions_id_seq'::regclass);


--
-- TOC entry 2723 (class 2604 OID 19372)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY warnings ALTER COLUMN id SET DEFAULT nextval('warnings_id_seq'::regclass);


--
-- TOC entry 3230 (class 0 OID 18617)
-- Dependencies: 270
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY api_keys (id, key, user_id, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3358 (class 0 OID 0)
-- Dependencies: 269
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('api_keys_id_seq', 1, false);


--
-- TOC entry 3271 (class 0 OID 19190)
-- Dependencies: 311
-- Data for Name: badge_groupings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY badge_groupings (id, name, description, "position", created_at, updated_at) FROM stdin;
1	Getting Started	\N	10	2014-11-01 07:31:02.158876	2014-11-01 07:31:02.158876
2	Community	\N	11	2014-11-01 07:31:02.1625	2014-11-01 07:31:02.1625
3	Posting	\N	12	2014-11-01 07:31:02.164362	2014-11-01 07:31:02.164362
4	Trust Level	\N	13	2014-11-01 07:31:02.166168	2014-11-01 07:31:02.166168
5	Other	\N	14	2014-11-01 07:31:02.167926	2014-11-01 07:31:02.167926
\.


--
-- TOC entry 3359 (class 0 OID 0)
-- Dependencies: 310
-- Name: badge_groupings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('badge_groupings_id_seq', 6, false);


--
-- TOC entry 3242 (class 0 OID 18832)
-- Dependencies: 282
-- Data for Name: badge_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY badge_types (id, name, created_at, updated_at) FROM stdin;
1	Gold	2014-11-01 07:31:02.140419	2014-11-01 07:31:02.140419
2	Silver	2014-11-01 07:31:02.143897	2014-11-01 07:31:02.143897
3	Bronze	2014-11-01 07:31:02.145507	2014-11-01 07:31:02.145507
\.


--
-- TOC entry 3360 (class 0 OID 0)
-- Dependencies: 281
-- Name: badge_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('badge_types_id_seq', 4, false);


--
-- TOC entry 3244 (class 0 OID 18844)
-- Dependencies: 284
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY badges (id, name, description, badge_type_id, grant_count, created_at, updated_at, allow_title, multiple_grant, icon, listable, target_posts, query, enabled, auto_revoke, badge_grouping_id, trigger, show_posts, system, image) FROM stdin;
1	Basic User	\N	3	0	2014-11-01 07:31:02.188488	2014-11-01 07:31:02.188488	f	f	fa-user	t	f	\n    SELECT u.id user_id, current_timestamp granted_at FROM users u\n    WHERE trust_level >= 1 AND (\n      :backfill OR u.id IN (:user_ids)\n    )\n	t	t	5	4	f	t	\N
2	Member	\N	3	0	2014-11-01 07:31:02.193518	2014-11-01 07:31:02.193518	f	f	fa-user	t	f	\n    SELECT u.id user_id, current_timestamp granted_at FROM users u\n    WHERE trust_level >= 2 AND (\n      :backfill OR u.id IN (:user_ids)\n    )\n	t	t	5	4	f	t	\N
3	Regular	\N	2	0	2014-11-01 07:31:02.195677	2014-11-01 07:31:02.195677	t	f	fa-user	t	f	\n    SELECT u.id user_id, current_timestamp granted_at FROM users u\n    WHERE trust_level >= 3 AND (\n      :backfill OR u.id IN (:user_ids)\n    )\n	t	t	5	4	f	t	\N
4	Leader	\N	1	0	2014-11-01 07:31:02.197988	2014-11-01 07:31:02.197988	t	f	fa-user	t	f	\n    SELECT u.id user_id, current_timestamp granted_at FROM users u\n    WHERE trust_level >= 4 AND (\n      :backfill OR u.id IN (:user_ids)\n    )\n	t	t	5	4	f	t	\N
17	Reader	\N	3	0	2014-11-01 07:31:02.20007	2014-11-01 07:31:02.20007	f	f	fa-certificate	t	f	    SELECT id user_id, current_timestamp granted_at\n    FROM users\n    WHERE id IN\n    (\n      SELECT pt.user_id\n      FROM post_timings pt\n      JOIN badge_posts b ON b.post_number = pt.post_number AND\n                            b.topic_id = pt.topic_id\n      JOIN topics t ON t.id = pt.topic_id\n      LEFT JOIN user_badges ub ON ub.badge_id = 17 AND ub.user_id = pt.user_id\n      WHERE ub.id IS NULL AND t.posts_count > 100\n      GROUP BY pt.user_id, pt.topic_id, t.posts_count\n      HAVING count(*) >= t.posts_count\n    )\n	t	f	5	\N	f	t	\N
16	Read Guidelines	\N	3	0	2014-11-01 07:31:02.202224	2014-11-01 07:31:02.202224	f	f	fa-certificate	t	f	    SELECT user_id, read_faq granted_at\n    FROM user_stats\n    WHERE read_faq IS NOT NULL AND (user_id IN (:user_ids) OR :backfill)\n	t	t	5	8	f	t	\N
15	First Quote	\N	3	0	2014-11-01 07:31:02.207356	2014-11-01 07:31:02.207356	f	f	fa-certificate	t	t	    SELECT ids.user_id, q.post_id, q.created_at granted_at\n    FROM\n    (\n      SELECT p1.user_id, MIN(q1.id) id\n      FROM quoted_posts q1\n      JOIN badge_posts p1 ON p1.id = q1.post_id\n      JOIN badge_posts p2 ON p2.id = q1.quoted_post_id\n      WHERE (:backfill OR ( p1.id IN (:post_ids) ))\n      GROUP BY p1.user_id\n    ) ids\n    JOIN quoted_posts q ON q.id = ids.id\n	t	t	5	2	t	t	\N
11	First Like	\N	3	0	2014-11-01 07:31:02.20951	2014-11-01 07:31:02.20951	f	f	fa-certificate	t	t	    SELECT pa1.user_id, pa1.created_at granted_at, pa1.post_id\n    FROM (\n      SELECT pa.user_id, min(pa.id) id\n      FROM post_actions pa\n      JOIN badge_posts p on p.id = pa.post_id\n      WHERE post_action_type_id = 2 AND\n        (:backfill OR pa.post_id IN (:post_ids) )\n      GROUP BY pa.user_id\n    ) x\n    JOIN post_actions pa1 on pa1.id = x.id\n	t	t	5	1	t	t	\N
13	First Flag	\N	3	0	2014-11-01 07:31:02.211628	2014-11-01 07:31:02.211628	f	f	fa-certificate	t	t	    SELECT pa1.user_id, pa1.created_at granted_at, pa1.post_id\n    FROM (\n      SELECT pa.user_id, min(pa.id) id\n      FROM post_actions pa\n      JOIN badge_posts p on p.id = pa.post_id\n      WHERE post_action_type_id IN (3,4,7,8) AND\n        (:backfill OR pa.post_id IN (:post_ids) )\n      GROUP BY pa.user_id\n    ) x\n    JOIN post_actions pa1 on pa1.id = x.id\n	t	f	5	1	f	t	\N
12	First Share	\N	3	0	2014-11-01 07:31:02.213893	2014-11-01 07:31:02.213893	f	f	fa-certificate	t	t	    SELECT views.user_id, i2.post_id, i2.created_at granted_at\n    FROM\n    (\n      SELECT i.user_id, MIN(i.id) i_id\n      FROM incoming_links i\n      JOIN badge_posts p on p.id = i.post_id\n      WHERE i.user_id IS NOT NULL\n      GROUP BY i.user_id\n    ) as views\n    JOIN incoming_links i2 ON i2.id = views.i_id\n	t	t	5	0	t	t	\N
21	Nice Share	\N	3	0	2014-11-01 07:31:02.21599	2014-11-01 07:31:02.21599	f	t	fa-certificate	t	t	    SELECT views.user_id, i2.post_id, i2.created_at granted_at\n    FROM\n    (\n      SELECT i.user_id, MIN(i.id) i_id\n      FROM incoming_links i\n      JOIN badge_posts p on p.id = i.post_id\n      WHERE i.user_id IS NOT NULL\n      GROUP BY i.user_id,i.post_id\n      HAVING COUNT(*) > 25\n    ) as views\n    JOIN incoming_links i2 ON i2.id = views.i_id\n	t	t	5	0	t	t	\N
22	Good Share	\N	2	0	2014-11-01 07:31:02.218235	2014-11-01 07:31:02.218235	f	t	fa-certificate	t	t	    SELECT views.user_id, i2.post_id, i2.created_at granted_at\n    FROM\n    (\n      SELECT i.user_id, MIN(i.id) i_id\n      FROM incoming_links i\n      JOIN badge_posts p on p.id = i.post_id\n      WHERE i.user_id IS NOT NULL\n      GROUP BY i.user_id,i.post_id\n      HAVING COUNT(*) > 300\n    ) as views\n    JOIN incoming_links i2 ON i2.id = views.i_id\n	t	t	5	0	t	t	\N
23	Great Share	\N	1	0	2014-11-01 07:31:02.220292	2014-11-01 07:31:02.220292	f	t	fa-certificate	t	t	    SELECT views.user_id, i2.post_id, i2.created_at granted_at\n    FROM\n    (\n      SELECT i.user_id, MIN(i.id) i_id\n      FROM incoming_links i\n      JOIN badge_posts p on p.id = i.post_id\n      WHERE i.user_id IS NOT NULL\n      GROUP BY i.user_id,i.post_id\n      HAVING COUNT(*) > 1000\n    ) as views\n    JOIN incoming_links i2 ON i2.id = views.i_id\n	t	t	5	0	t	t	\N
5	Welcome	\N	3	0	2014-11-01 07:31:02.222403	2014-11-01 07:31:02.222403	f	f	fa-certificate	t	t	    SELECT p.user_id, min(post_id) post_id, min(pa.created_at) granted_at\n    FROM post_actions pa\n    JOIN badge_posts p on p.id = pa.post_id\n    WHERE post_action_type_id = 2 AND\n        (:backfill OR pa.post_id IN (:post_ids) )\n    GROUP BY p.user_id\n	t	t	5	1	t	t	\N
9	Autobiographer	\N	3	0	2014-11-01 07:31:02.224422	2014-11-01 07:31:02.224422	f	f	fa-certificate	t	f	    SELECT u.id user_id, current_timestamp granted_at\n    FROM users u\n    JOIN user_profiles up on u.id = up.user_id\n    WHERE bio_raw IS NOT NULL AND LENGTH(TRIM(bio_raw)) > 10 AND\n          uploaded_avatar_id IS NOT NULL AND\n          (:backfill OR u.id IN (:user_ids) )\n	t	t	5	8	f	t	\N
6	Nice Post	\N	3	0	2014-11-01 07:31:02.228415	2014-11-01 07:31:02.228415	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number > 1 AND p.like_count >= 10 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
7	Good Post	\N	2	0	2014-11-01 07:31:02.230536	2014-11-01 07:31:02.230536	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number > 1 AND p.like_count >= 25 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
8	Great Post	\N	1	0	2014-11-01 07:31:02.232805	2014-11-01 07:31:02.232805	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number > 1 AND p.like_count >= 50 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
18	Nice Topic	\N	3	0	2014-11-01 07:31:02.235015	2014-11-01 07:31:02.235015	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number = 1 AND p.like_count >= 10 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
19	Good Topic	\N	2	0	2014-11-01 07:31:02.237412	2014-11-01 07:31:02.237412	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number = 1 AND p.like_count >= 25 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
20	Great Topic	\N	1	0	2014-11-01 07:31:02.240017	2014-11-01 07:31:02.240017	f	t	fa-certificate	t	t	\n    SELECT p.user_id, p.id post_id, p.updated_at granted_at\n    FROM badge_posts p\n    WHERE p.post_number = 1 AND p.like_count >= 50 AND\n      (:backfill OR p.id IN (:post_ids) )\n	t	t	5	1	t	t	\N
10	Editor	\N	3	1	2014-11-01 07:31:02.226403	2014-11-12 16:39:52.115249	f	f	fa-certificate	t	f	    SELECT p.user_id, min(p.id) post_id, min(p.created_at) granted_at\n    FROM badge_posts p\n    WHERE p.self_edits > 0 AND\n        (:backfill OR p.id IN (:post_ids) )\n    GROUP BY p.user_id\n	t	t	5	2	f	t	\N
14	First Link	\N	3	1	2014-11-01 07:31:02.204742	2014-11-30 14:53:05.604699	f	f	fa-certificate	t	t	    SELECT l.user_id, l.post_id, l.created_at granted_at\n    FROM\n    (\n      SELECT MIN(l1.id) id\n      FROM topic_links l1\n      JOIN badge_posts p1 ON p1.id = l1.post_id\n      JOIN badge_posts p2 ON p2.id = l1.link_post_id\n      WHERE NOT reflection AND p1.topic_id <> p2.topic_id AND not quote AND\n        (:backfill OR ( p1.id in (:post_ids) ))\n      GROUP BY l1.user_id\n    ) ids\n    JOIN topic_links l ON l.id = ids.id\n	t	t	5	2	t	t	\N
\.


--
-- TOC entry 3361 (class 0 OID 0)
-- Dependencies: 283
-- Name: badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('badges_id_seq', 24, false);


--
-- TOC entry 3156 (class 0 OID 17202)
-- Dependencies: 196
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY categories (id, name, color, topic_id, topic_count, created_at, updated_at, user_id, topics_year, topics_month, topics_week, slug, description, text_color, read_restricted, auto_close_hours, post_count, latest_post_id, latest_topic_id, "position", parent_category_id, posts_year, posts_month, posts_week, email_in, email_in_allow_strangers, topics_day, posts_day, logo_url, background_url, allow_badges, name_lower, auto_close_based_on_last_post) FROM stdin;
6	活动	3AB54A	13	3	2014-11-01 08:02:15.216127	2014-12-13 08:45:48.755975	1	3	2	0		\N	FFFFFF	f	\N	3	23	19	5	\N	3	2	0	\N	f	0	0	\N	\N	t	活动	f
1	Uncategorized	AB9364	\N	0	2014-11-01 07:30:59.05604	2014-12-01 07:38:41.08992	-1	0	0	0	uncategorized		FFFFFF	f	\N	2	\N	\N	0	\N	0	0	0	\N	f	0	0	\N	\N	t	uncategorized	f
2	Lounge	EEEEEE	1	1	2014-11-01 07:30:59.319108	2014-12-01 07:38:41.104859	-1	1	0	0	lounge	A category exclusive to members with trust level 3 and higher.	652D90	t	\N	1	12	9	3	\N	1	0	0	\N	f	0	0	\N	\N	t	lounge	f
4	Staff	283890	3	5	2014-11-01 07:31:00.680818	2014-12-01 07:38:41.120061	-1	5	0	0	staff	Private category for staff discussions. Topics are only visible to admins and moderators.	FFFFFF	t	\N	8	13	10	2	\N	8	0	0	\N	f	0	0	\N	\N	t	staff	f
5	站务	AB9364	12	1	2014-11-01 08:00:55.699944	2014-12-08 05:59:21.307439	1	1	1	0		\N	FFFFFF	f	\N	1	19	16	4	\N	1	1	0	\N	f	0	0	\N	\N	t	站务	f
3	Meta	808281	2	1	2014-11-01 07:31:00.581623	2014-12-08 05:59:21.337991	-1	1	1	0	meta	Discussion about this site, its organization, how it works, and how we can improve it.	FFFFFF	f	\N	2	21	17	1	\N	2	2	0	\N	f	0	0	\N	\N	t	meta	f
\.


--
-- TOC entry 3362 (class 0 OID 0)
-- Dependencies: 195
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('categories_id_seq', 6, true);


--
-- TOC entry 3254 (class 0 OID 18961)
-- Dependencies: 294
-- Data for Name: category_custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_custom_fields (id, category_id, name, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3363 (class 0 OID 0)
-- Dependencies: 293
-- Name: category_custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_custom_fields_id_seq', 1, false);


--
-- TOC entry 3157 (class 0 OID 17212)
-- Dependencies: 197
-- Data for Name: category_featured_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_featured_topics (category_id, topic_id, created_at, updated_at, rank, id) FROM stdin;
2	9	2014-11-01 07:31:06.029544	2014-11-01 07:31:06.029544	0	14
4	10	2014-11-01 07:31:06.360078	2014-11-01 07:31:06.360078	0	15
4	7	2014-11-01 07:31:06.361756	2014-11-01 07:31:06.361756	1	16
4	6	2014-11-01 07:31:06.36317	2014-11-01 07:31:06.36317	2	17
5	16	2014-11-30 13:34:53.037831	2014-11-30 13:34:53.037831	0	24
3	17	2014-11-30 14:52:48.659099	2014-11-30 14:52:48.659099	0	27
6	19	2014-11-30 15:55:18.514337	2014-11-30 15:55:18.514337	0	30
6	18	2014-11-30 15:55:18.520226	2014-11-30 15:55:18.520226	1	31
6	14	2014-11-30 15:55:18.525063	2014-11-30 15:55:18.525063	2	32
\.


--
-- TOC entry 3364 (class 0 OID 0)
-- Dependencies: 254
-- Name: category_featured_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_featured_topics_id_seq', 32, true);


--
-- TOC entry 3170 (class 0 OID 17398)
-- Dependencies: 210
-- Data for Name: category_featured_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_featured_users (id, category_id, user_id, created_at, updated_at) FROM stdin;
2	2	-1	2014-11-01 07:40:10.294579	2014-11-01 07:40:10.294579
4	4	-1	2014-11-01 07:40:10.307494	2014-11-01 07:40:10.307494
5	1	1	2014-11-01 08:10:31.985706	2014-11-01 08:10:31.985706
6	1	-1	2014-11-01 08:10:31.98691	2014-11-01 08:10:31.98691
7	5	1	2014-11-01 08:10:32.004415	2014-11-01 08:10:32.004415
8	6	1	2014-11-01 08:10:32.010859	2014-11-01 08:10:32.010859
9	3	1	2014-11-30 14:52:37.534643	2014-11-30 14:52:37.534643
10	3	-1	2014-11-30 14:52:37.53762	2014-11-30 14:52:37.53762
\.


--
-- TOC entry 3365 (class 0 OID 0)
-- Dependencies: 209
-- Name: category_featured_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_featured_users_id_seq', 10, true);


--
-- TOC entry 3207 (class 0 OID 18253)
-- Dependencies: 247
-- Data for Name: category_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_groups (id, category_id, group_id, created_at, updated_at, permission_type) FROM stdin;
1	2	13	2014-11-01 07:31:03.255119	2014-11-01 07:31:03.255119	1
2	4	3	2014-11-01 07:31:03.841114	2014-11-01 07:31:03.841114	1
\.


--
-- TOC entry 3366 (class 0 OID 0)
-- Dependencies: 246
-- Name: category_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_groups_id_seq', 2, true);


--
-- TOC entry 3196 (class 0 OID 17840)
-- Dependencies: 236
-- Data for Name: category_search_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_search_data (category_id, search_data, raw_data, locale) FROM stdin;
5	'务':2 '站':1	站 务 	zh_CN
6	'活动':1	活动 	zh_CN
\.


--
-- TOC entry 3238 (class 0 OID 18749)
-- Dependencies: 278
-- Data for Name: category_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_users (id, category_id, user_id, notification_level) FROM stdin;
\.


--
-- TOC entry 3367 (class 0 OID 0)
-- Dependencies: 277
-- Name: category_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_users_id_seq', 1, false);


--
-- TOC entry 3250 (class 0 OID 18930)
-- Dependencies: 290
-- Data for Name: color_scheme_colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY color_scheme_colors (id, name, hex, color_scheme_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3368 (class 0 OID 0)
-- Dependencies: 289
-- Name: color_scheme_colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('color_scheme_colors_id_seq', 1, false);


--
-- TOC entry 3248 (class 0 OID 18920)
-- Dependencies: 288
-- Data for Name: color_schemes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY color_schemes (id, name, enabled, versioned_id, version, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3369 (class 0 OID 0)
-- Dependencies: 287
-- Name: color_schemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('color_schemes_id_seq', 1, false);


--
-- TOC entry 3193 (class 0 OID 17792)
-- Dependencies: 233
-- Data for Name: draft_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY draft_sequences (id, user_id, draft_key, sequence) FROM stdin;
2	1	topic_11	3
3	1	topic_14	2
4	1	topic_15	1
6	1	topic_17	3
5	1	topic_16	2
7	1	topic_18	2
1	1	new_topic	7
8	1	topic_19	1
9	1	new_private_message	1
10	1	topic_20	1
\.


--
-- TOC entry 3370 (class 0 OID 0)
-- Dependencies: 232
-- Name: draft_sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('draft_sequences_id_seq', 10, true);


--
-- TOC entry 3189 (class 0 OID 17703)
-- Dependencies: 229
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY drafts (id, user_id, draft_key, data, created_at, updated_at, sequence) FROM stdin;
4	1	topic_16	{"reply":"经过两周的设计,JDC的logo定稿,现发布如下:\\n大图标:  \\n<img src=\\"/uploads/default/4/2435daeed1465e41.png\\" width=\\"500\\" height=\\"500\\"> \\n网站图标:  \\n<img src=\\"/uploads/default/5/a87baee6a18e9159.png\\" width=\\"244\\" height=\\"66\\"> \\n小图标:  \\n<img src=\\"/uploads/default/6/0d11ff046aee0976.png\\" width=\\"66\\" height=\\"66\\"> \\n\\n构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑.\\n\\n感谢yinnjiuu@sina.com的设计和实现.\\n\\ngithub地址:\\nhttps://github.com/DengZuoheng/doc.jdc/tree/master/logo","action":"edit","title":"[14/11/30]暨大开发者社区logo发布","categoryId":5,"postId":19,"archetypeId":"regular","metaData":null}	2014-11-30 15:15:50.327952	2014-11-30 15:15:50.327952	1
5	1	topic_18	{"reply":"##蟒营迭代演示W1##\\n \\n###概述###\\n- 时间：11月16日下午15:00-18:00\\n- 地点：暨南大学珠海校区教409\\n- 参与人员：\\n        + 蟒营学员：20+\\n        + 导师：Zoom.Quiet(以下简称“大妈”)\\n \\n \\n###流程###\\n####1.大妈发言，讲明本周迭代演示所要介绍的事项:\\n\\n- 产品名称\\n- 谁做了什么\\n- 下周做什么\\n\\n在此之前，投影仪出现了问题，由此引发大妈呼吁学员要获得完整的高等教育。\\n \\n####2.演示调试（两组进行参与）\\n- 组我吧：试图通过网络进行,但网速过慢,未成功\\n- 管家婆：调试基本成功。（但准备演示的只一个在台上准备）\\n\\n- 调试完毕，大妈由此提出：\\n> 任何形式的演示都可以\\n> 要学会换角色思考问题和解决问题:\\n> \\n>    - 投资人vs创业人\\n>    - 大妈vs学员\\n>    - 公司年会vs参请资源的员工   \\n> 维系团队，否则无效。加强团队之间的沟通，学会开会，以邮件或文档的形式在组员间交流一些问题，提高工作效率  \\n> 再次强调提问方面的问题。参考《提问的智慧》:http://www.oyonyou.com/  thread-3669-1-1.html\\n> 谨记：多做做错，不做不错，不做终会，一做就错\\n \\n####3.访谈\\n\\n- 每个学员进行发言\\n- 内容：\\n    - 我是谁？我在组里做什么？\\n    - 上周我们组做什么？\\n    - 什么做得好？有什么不好的地方？\\n    - 下周要做什么？\\n \\n####4.正式演示\\n - #####内容：\\n    - 说清哪组几人\\n    - 上周做了什么\\n    - 什么是最大的困难\\n    - 下周做什么\\n    \\n - #####项目：管家婆（3人）\\n   - 上周已完成：财务管理的设定\\n   - 上周最大问题：存储用户信息的设置\\n   - 解决方案：继续学习Python，编辑文档\\n   - 分工：用户界面   \\n   - 下周：实现记忆功能\\n   - 存在的问题：\\n\\n    * 只要按依照、提示两方面去做\\n    * 修改性较弱\\n    * 权限设置方面\\n\\n-  #####项目：乐帮帮(happyhelper)（5人）\\n   - 上周已完成:功能的确定、界面的设计\\n   - 上周最大问题：不知道如何把app变成软件\\n   -  解决方案：加紧Python的学习        \\n   - 下周：学习Python、争取交出app的模型\\n\\n- #####项目：邮泡（mail pop)（4人）\\n    - 上周已完成：一部分代码、原型设计、学习Python\\n    - 上周最大问题：积极性不高\\n    - 下周：继续学习Python             \\n\\n- #####项目：组我吧（Take me up）（2人）\\n    - 上周已完成：SAE申请，微信公众号“组我吧”通过验证，并通过了开发者模式\\n    - 上周最大问题：Token验证无法通过（已经解决）\\n    - 下周：\\n        * 学习Python微信公众平台开发教程（Web框架，XML相关知识）\\n        * 完成自动回复用户消息功能\\n        * 争取初步实现“组我吧”核心功能\\n\\n- #####项目：书友（bookfriend）\\n     - 上周已完成：功能和界面的确定\\n     - 上周最大问题：暂未知\\n     - 下周：暂未知（周报未写）\\n \\n \\n#### 5.大妈总结:\\n\\n > 坚持团队分工  \\n > 坚持smart原则,可验证.  \\n > 争取发日报,投入精力,让项目更易完成  \\n > 代码为客观依据  \\n > 分配任务:根据性格、能力分配  \\n > 学会寻途径(导师,同学,图书馆)来解决问题  \\n > 命令行、基础、数据库（文本当数据库略麻烦）   \\n      \\n####6.提问环节(无人提问)\\n - 大妈提出\\n  > 要以代码为\\"我学了\\"的依据  \\n  > 团队要有周报(做什么、下周做什么、最大困难是什么)\\n\\n###附录###\\n录音:http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141116-jnu-w1/","action":"edit","title":"[14/11/16]蟒营迭代演示w1纪要","categoryId":6,"postId":22,"archetypeId":"regular","metaData":null}	2014-11-30 15:37:22.295853	2014-11-30 15:37:22.295853	1
3	1	new_topic	{"reply":"###欢迎来到暨大开发者社区###\\n\\n暨大开发者社区是由暨南大学一群技术爱好者组成的开源技术社区.我们通常将暨大开发者社区简称为JDC. JDC的前身是暨南大学金山软件俱乐部(KSC). 目前,JDC与KSC时期一样托管于暨大电气信息学院团委学生会. 我们的目标,在于提供一个让大家一起折腾编程开发的平台. 任何人都可以加入暨大开发者社区,只要你对编程感兴趣,崇尚开源精神.\\n\\n在暨大开发者社区,你可以找到志同道合的朋友,与你一起走上编程这条不归路.在暨大开发者社区,你可以提出你学习编程中遇到的困难,我们会定期处理论坛和邮件列表中的提问.\\n\\n在这里(JDC社区论坛),我们会发布一些活动纪要,通知和技术文章.同时也欢迎任何人发帖讨论技术.\\n\\n**但是发帖前请仔细阅读置顶,如果管理员判断发帖者有未阅读置顶的迹象,将不予警告直接禁言或删帖**\\n\\n###目前的暨大开发者社区###\\n2014年下半年,我们与珠海GDG合作开办了新的一期蟒营,详情可参阅:\\n\\n+ [14/11/08]暨大蟒营开营纪要: http://jnu-developer.com/t/14-11-08/14\\n+ 蟒营wiki(GitCafe): https://gitcafe.com/PythoniCamp/PythoniCamp/wiki\\n+ 蟒营wiki(Google Code): https://code.google.com/p/kcpycamp/wiki/PythoniCamp?tm=6\\n+ 蟒营邮件列表: pythonicamp@googlegroups.com\\n+ 珠海GDG邮件列表: gdg-zhuhai@googlegroups.com\\n    \\n**不过,蟒营的形式限制,目前只能关注不能加入;-)**\\n\\n除了蟒营之外,我们还与中国移动合作,成立移动MM孵化基地作为暨大开发者社区的子社区,旨在开发移动平台产品,目前已经有3个开发团队和1个美术团队.\\n\\n**暨大开发者社区常年招收主程,测试,美术,产品设计,有意者联系dengzuoheng@gmail.com出示作品即可,要求暨大在校生**\\n\\n###如何加入暨大开发者社区###\\n- 只需订阅暨大开发者社区邮件列表即可视为加入:\\n    + 订阅方式:发送空邮件到jnu-developer+subscribe@googlegroups.com 即可完成订阅\\n    + 如果需要获得更及时的活动通知,可发私人邮件至暨大开发者社区技术负责人说明情况\\n    + 目前的技术负责人:dengzuoheng@gmail.com\\n- 也可注册本论坛成为论坛会员:\\n    + 注册需要通过电子邮件激活,所以注册时务必填写**真实邮件地址**否则无法注册成功.\\n\\n###社区资源###\\n论坛: jnu-dveloper.com    \\n邮件列表: jnu-developer@googlegroups.com\\n官方文档库(附开源项目列表): https://github.com/DengZuoheng/doc.jdc\\n\\n###发帖须知###\\n本讨论区采用先进的下一代论坛程序 Discourse[1] 搭建而成，具有很多新功能与新特性，所以建议您在正式开始发表话题之前，先熟悉一下这里的环境，以及本讨论区的相关说明。\\n\\n在您发表前 2 个主题或回复时，系统会自动弹出发帖指导，希望您认真阅读其中的内容后再发表。\\n\\n发帖的内容支持 Markdown[2] 语法控制格式.\\n\\n\\n[1] http://www.discourse.org21\\n\\n[2] http://wowubuntu.com/markdown28","action":"createTopic","title":"欢迎来到暨大开发者社区(JDC)","categoryId":"3","archetypeId":"regular","metaData":null}	2014-11-30 13:29:16.464981	2014-11-30 13:29:16.464981	4
\.


--
-- TOC entry 3371 (class 0 OID 0)
-- Dependencies: 228
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('drafts_id_seq', 5, true);


--
-- TOC entry 3175 (class 0 OID 17519)
-- Dependencies: 215
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY email_logs (id, to_address, email_type, user_id, created_at, updated_at, reply_key, post_id, topic_id, skipped, skipped_reason) FROM stdin;
1	dengzuoheng@gmail.com	signup	1	2014-11-01 07:37:15.298868	2014-11-01 07:37:15.298868	\N	\N	\N	f	\N
2	dengzuoheng@gmail.com	new_version	\N	2014-11-07 09:45:07.511517	2014-11-07 09:45:07.511517	\N	\N	\N	f	\N
3	dengzuoheng@gmail.com	new_version	\N	2014-11-19 10:32:53.820729	2014-11-19 10:32:53.820729	\N	\N	\N	f	\N
4	dengzuoheng@gmail.com	new_version	\N	2014-11-28 10:59:08.061742	2014-11-28 10:59:08.061742	\N	\N	\N	f	\N
5	dengzuoheng@gmail.com	digest	1	2014-11-30 03:14:47.807585	2014-11-30 03:14:47.807585	\N	\N	\N	f	\N
11	chenrenzhan@gmail.com	signup	6	2014-12-08 15:50:27.470147	2014-12-08 15:50:27.470147	\N	\N	\N	f	\N
12	chenrenzhan@gmail.com	user_private_message	6	2014-12-08 16:06:13.589294	2014-12-08 16:06:13.589294	\N	24	20	f	\N
13	dengzuoheng@gmail.com	new_version	\N	2014-12-13 14:42:21.316504	2014-12-13 14:42:21.316504	\N	\N	\N	f	\N
14	dengzuoheng@gmail.com	digest	1	2014-12-16 14:02:03.722382	2014-12-16 14:02:03.722382	\N	\N	\N	f	\N
\.


--
-- TOC entry 3372 (class 0 OID 0)
-- Dependencies: 214
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('email_logs_id_seq', 14, true);


--
-- TOC entry 3187 (class 0 OID 17689)
-- Dependencies: 227
-- Data for Name: email_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY email_tokens (id, user_id, email, token, confirmed, expired, created_at, updated_at) FROM stdin;
1	-1	no_email	ea121af6cc816d6773cd3c0ff591b504	f	f	2014-11-01 07:31:02.669552	2014-11-01 07:31:02.669552
2	1	dengzuoheng@gmail.com	d2e939bea53d9f55a3f6a9348d4851a4	t	f	2014-11-01 07:37:14.626985	2014-11-01 07:37:14.626985
7	6	chenrenzhan@gmail.com	a81a8bc0d6a7882074e4cc299edc98d4	t	f	2014-12-08 15:50:26.734747	2014-12-08 15:50:26.734747
\.


--
-- TOC entry 3373 (class 0 OID 0)
-- Dependencies: 226
-- Name: email_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('email_tokens_id_seq', 7, true);


--
-- TOC entry 3179 (class 0 OID 17576)
-- Dependencies: 219
-- Data for Name: facebook_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY facebook_user_infos (id, user_id, facebook_user_id, username, first_name, last_name, email, gender, name, link, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3374 (class 0 OID 0)
-- Dependencies: 218
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('facebook_user_infos_id_seq', 1, false);


--
-- TOC entry 3198 (class 0 OID 18043)
-- Dependencies: 238
-- Data for Name: github_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY github_user_infos (id, user_id, screen_name, github_user_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3375 (class 0 OID 0)
-- Dependencies: 237
-- Name: github_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('github_user_infos_id_seq', 1, false);


--
-- TOC entry 3264 (class 0 OID 19036)
-- Dependencies: 304
-- Data for Name: google_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY google_user_infos (id, user_id, google_user_id, first_name, last_name, email, gender, name, link, profile_link, picture, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3376 (class 0 OID 0)
-- Dependencies: 303
-- Name: google_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('google_user_infos_id_seq', 1, false);


--
-- TOC entry 3256 (class 0 OID 18972)
-- Dependencies: 296
-- Data for Name: group_custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY group_custom_fields (id, group_id, name, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3377 (class 0 OID 0)
-- Dependencies: 295
-- Name: group_custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('group_custom_fields_id_seq', 1, false);


--
-- TOC entry 3205 (class 0 OID 18231)
-- Dependencies: 245
-- Data for Name: group_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY group_users (id, group_id, user_id, created_at, updated_at) FROM stdin;
1	10	-1	2014-11-01 07:31:02.73701	2014-11-01 07:31:02.73701
2	11	-1	2014-11-01 07:31:02.742736	2014-11-01 07:31:02.742736
3	12	-1	2014-11-01 07:31:02.745704	2014-11-01 07:31:02.745704
4	13	-1	2014-11-01 07:31:02.748549	2014-11-01 07:31:02.748549
5	14	-1	2014-11-01 07:31:02.751638	2014-11-01 07:31:02.751638
6	10	1	2014-11-01 07:37:14.662715	2014-11-01 07:37:14.662715
7	1	-1	2014-11-01 07:38:59.181774	2014-11-01 07:38:59.181774
8	1	1	2014-11-01 07:38:59.185103	2014-11-01 07:38:59.185103
9	2	-1	2014-11-01 07:38:59.198953	2014-11-01 07:38:59.198953
10	3	-1	2014-11-01 07:38:59.210873	2014-11-01 07:38:59.210873
11	3	1	2014-11-01 07:38:59.212653	2014-11-01 07:38:59.212653
16	10	6	2014-12-08 15:50:26.766503	2014-12-08 15:50:26.766503
\.


--
-- TOC entry 3378 (class 0 OID 0)
-- Dependencies: 244
-- Name: group_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('group_users_id_seq', 16, true);


--
-- TOC entry 3203 (class 0 OID 18223)
-- Dependencies: 243
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY groups (id, name, created_at, updated_at, automatic, user_count, alias_level, visible) FROM stdin;
0	everyone	2014-11-01 07:31:01.993219	2014-12-26 07:08:51.86839	t	0	0	t
1	admins	2014-11-01 07:31:01.999903	2014-12-26 07:08:51.878366	t	2	0	t
2	moderators	2014-11-01 07:31:02.026557	2014-12-26 07:08:51.892291	t	1	0	t
3	staff	2014-11-01 07:31:02.033609	2014-12-26 07:08:51.901738	t	2	0	t
10	trust_level_0	2014-11-01 07:31:02.039925	2014-11-01 07:31:02.039925	t	3	0	t
11	trust_level_1	2014-11-01 07:31:02.047099	2014-11-01 07:31:02.047099	t	1	0	t
12	trust_level_2	2014-11-01 07:31:02.055045	2014-11-01 07:31:02.055045	t	1	0	t
13	trust_level_3	2014-11-01 07:31:02.061846	2014-11-01 07:31:02.061846	t	1	0	t
14	trust_level_4	2014-11-01 07:31:02.068254	2014-11-01 07:31:02.068254	t	1	0	t
\.


--
-- TOC entry 3379 (class 0 OID 0)
-- Dependencies: 242
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('groups_id_seq', 40, true);


--
-- TOC entry 3275 (class 0 OID 19261)
-- Dependencies: 315
-- Data for Name: incoming_domains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY incoming_domains (id, name, https, port) FROM stdin;
1	mail.qq.com	f	80
2	JNU-DEVELOPER.COM	f	80
3	jnu-developer.com	f	80
\.


--
-- TOC entry 3380 (class 0 OID 0)
-- Dependencies: 314
-- Name: incoming_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('incoming_domains_id_seq', 3, true);


--
-- TOC entry 3153 (class 0 OID 17116)
-- Dependencies: 193
-- Data for Name: incoming_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY incoming_links (id, created_at, user_id, ip_address, current_user_id, post_id, incoming_referer_id) FROM stdin;
1	2014-11-12 16:44:55.018744	\N	113.76.162.10	\N	17	1
2	2014-12-09 23:35:52.816777	\N	176.123.20.5	\N	22	2
3	2014-12-09 23:35:59.656571	\N	176.123.20.5	\N	22	2
4	2014-12-09 23:36:12.830967	\N	176.123.20.5	\N	17	2
5	2014-12-09 23:36:20.724833	\N	176.123.20.5	\N	17	2
6	2014-12-09 23:36:24.457608	\N	176.123.20.5	\N	20	2
7	2014-12-09 23:36:31.216223	\N	176.123.20.5	\N	21	2
8	2014-12-09 23:36:34.58085	\N	176.123.20.5	\N	20	2
9	2014-12-09 23:36:37.977056	\N	176.123.20.5	\N	19	2
10	2014-12-09 23:36:44.719564	\N	176.123.20.5	\N	19	2
11	2014-12-09 23:37:12.019286	\N	176.123.20.5	\N	16	3
12	2014-12-09 23:37:18.730529	\N	176.123.20.5	\N	16	3
13	2014-12-09 23:37:22.099289	\N	176.123.20.5	\N	15	3
14	2014-12-09 23:37:28.800878	\N	176.123.20.5	\N	15	3
15	2014-12-09 23:37:35.541178	\N	176.123.20.5	\N	2	3
16	2014-12-09 23:37:42.284357	\N	176.123.20.5	\N	2	3
17	2014-12-09 23:38:16.425298	\N	176.123.20.5	\N	23	4
18	2014-12-09 23:38:33.275926	\N	176.123.20.5	\N	22	4
19	2014-12-09 23:38:40.029889	\N	176.123.20.5	\N	19	4
20	2014-12-09 23:38:46.741447	\N	176.123.20.5	\N	17	4
\.


--
-- TOC entry 3381 (class 0 OID 0)
-- Dependencies: 192
-- Name: incoming_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('incoming_links_id_seq', 20, true);


--
-- TOC entry 3273 (class 0 OID 19250)
-- Dependencies: 313
-- Data for Name: incoming_referers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY incoming_referers (id, path, incoming_domain_id) FROM stdin;
1	/cgi-bin/readtemplate	1
2	/category/6	2
3	/category/5	2
4	/category/meta.rss	3
\.


--
-- TOC entry 3382 (class 0 OID 0)
-- Dependencies: 312
-- Name: incoming_referers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('incoming_referers_id_seq', 4, true);


--
-- TOC entry 3262 (class 0 OID 19018)
-- Dependencies: 302
-- Data for Name: invited_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY invited_groups (id, group_id, invite_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3383 (class 0 OID 0)
-- Dependencies: 301
-- Name: invited_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('invited_groups_id_seq', 1, false);


--
-- TOC entry 3181 (class 0 OID 17659)
-- Dependencies: 221
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY invites (id, invite_key, email, invited_by_id, user_id, redeemed_at, created_at, updated_at, deleted_at, deleted_by_id, invalidated_at) FROM stdin;
\.


--
-- TOC entry 3384 (class 0 OID 0)
-- Dependencies: 220
-- Name: invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('invites_id_seq', 1, false);


--
-- TOC entry 3149 (class 0 OID 16959)
-- Dependencies: 189
-- Data for Name: message_bus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY message_bus (id, name, context, data, created_at) FROM stdin;
\.


--
-- TOC entry 3385 (class 0 OID 0)
-- Dependencies: 188
-- Name: message_bus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('message_bus_id_seq', 1, false);


--
-- TOC entry 3151 (class 0 OID 16982)
-- Dependencies: 191
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY notifications (id, notification_type, user_id, data, read, created_at, updated_at, topic_id, post_number, post_action_id) FROM stdin;
1	12	1	{"badge_id":10,"badge_name":"Editor"}	t	2014-11-01 07:56:35.727759	2014-11-01 07:56:35.727759	\N	\N	\N
2	12	1	{"badge_id":10,"badge_name":"Editor"}	t	2014-11-12 16:39:52.081223	2014-11-12 16:39:52.081223	\N	\N	\N
3	12	1	{"badge_id":14,"badge_name":"First Link"}	t	2014-11-30 14:53:05.556514	2014-11-30 14:53:05.556514	\N	\N	\N
4	6	6	{"topic_title":"欢迎来到 暨大开发者社区！","original_post_id":24,"original_username":"dengzuoheng","display_username":"dengzuoheng"}	f	2014-12-08 15:56:03.616339	2014-12-08 15:56:03.616339	20	1	\N
\.


--
-- TOC entry 3386 (class 0 OID 0)
-- Dependencies: 190
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('notifications_id_seq', 4, true);


--
-- TOC entry 3221 (class 0 OID 18486)
-- Dependencies: 261
-- Data for Name: oauth2_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY oauth2_user_infos (id, user_id, uid, provider, email, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3387 (class 0 OID 0)
-- Dependencies: 260
-- Name: oauth2_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('oauth2_user_infos_id_seq', 1, false);


--
-- TOC entry 3213 (class 0 OID 18365)
-- Dependencies: 253
-- Data for Name: optimized_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY optimized_images (id, sha1, extension, width, height, upload_id, url) FROM stdin;
1	68a9784a5e2fea7814a4563b5ad74536136782c4	.png	25	25	1	/uploads/default/_optimized/68a/978/4a5e2fea78_25x25.png
2	d9e0f2094fba117664fee4bf45dd7b759f1be2cc	.png	45	45	1	/uploads/default/_optimized/d9e/0f2/094fba1176_45x45.png
3	34c41240fd0de482a19c9036b036118e26570065	.png	32	32	3	/uploads/default/_optimized/34c/412/40fd0de482_32x32.png
4	6b371a34d6154df325ca5655a6ba72d3b7d709da	.png	120	120	3	/uploads/default/_optimized/6b3/71a/34d6154df3_120x120.png
5	0ff945d5936365ab422d28313a8a7afa62f11da9	.png	45	45	3	/uploads/default/_optimized/0ff/945/d5936365ab_45x45.png
6	32befc166336b0ba4718bec552a948f73091c460	.png	25	25	3	/uploads/default/_optimized/32b/efc/166336b0ba_25x25.png
7	161f6ec855dda2b109043898fb06a31b66652294	.png	20	20	1	/uploads/default/_optimized/161/f6e/c855dda2b1_20x20.png
8	c14fc409a6c09b39c44c03044d1d6552365ac410	.png	120	120	1	/uploads/default/_optimized/c14/fc4/09a6c09b39_120x120.png
9	09bb176d2d8e0c7660cb0e9b53f54a8e11ba8cf0	.png	500	500	4	/uploads/default/_optimized/09b/b17/6d2d8e0c76_500x500.png
10	5f07616c03da3eafcae950fcd69bb9bd7fd941a1	.png	20	20	3	/uploads/default/_optimized/5f0/761/6c03da3eaf_20x20.png
11	b6c73bf4e7cf4de723b19abdb27832ba7ada0ccc	.png	90	90	3	/uploads/default/_optimized/b6c/73b/f4e7cf4de7_90x90.png
\.


--
-- TOC entry 3388 (class 0 OID 0)
-- Dependencies: 252
-- Name: optimized_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('optimized_images_id_seq', 11, true);


--
-- TOC entry 3278 (class 0 OID 19343)
-- Dependencies: 319
-- Data for Name: permalinks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY permalinks (id, url, topic_id, post_id, category_id, created_at, updated_at, external_url) FROM stdin;
\.


--
-- TOC entry 3389 (class 0 OID 0)
-- Dependencies: 318
-- Name: permalinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('permalinks_id_seq', 1, false);


--
-- TOC entry 3223 (class 0 OID 18503)
-- Dependencies: 263
-- Data for Name: plugin_store_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY plugin_store_rows (id, plugin_name, key, type_name, value) FROM stdin;
\.


--
-- TOC entry 3390 (class 0 OID 0)
-- Dependencies: 262
-- Name: plugin_store_rows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('plugin_store_rows_id_seq', 1, false);


--
-- TOC entry 3166 (class 0 OID 17318)
-- Dependencies: 206
-- Data for Name: post_action_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_action_types (name_key, is_flag, icon, created_at, updated_at, id, "position") FROM stdin;
bookmark	f	\N	2014-11-01 07:31:02.087061	2014-11-01 07:31:02.087061	1	1
like	f	heart	2014-11-01 07:31:02.091006	2014-11-01 07:31:02.091006	2	2
off_topic	t	\N	2014-11-01 07:31:02.092765	2014-11-01 07:31:02.092765	3	3
inappropriate	t	\N	2014-11-01 07:31:02.094511	2014-11-01 07:31:02.094511	4	4
vote	f	\N	2014-11-01 07:31:02.096174	2014-11-01 07:31:02.096174	5	5
spam	t	\N	2014-11-01 07:31:02.097828	2014-11-01 07:31:02.097828	8	6
notify_user	t	\N	2014-11-01 07:31:02.099557	2014-11-01 07:31:02.099557	6	7
notify_moderators	t	\N	2014-11-01 07:31:02.101243	2014-11-01 07:31:02.101243	7	8
\.


--
-- TOC entry 3391 (class 0 OID 0)
-- Dependencies: 213
-- Name: post_action_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_action_types_id_seq', 9, false);


--
-- TOC entry 3165 (class 0 OID 17310)
-- Dependencies: 205
-- Data for Name: post_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_actions (id, post_id, user_id, post_action_type_id, deleted_at, created_at, updated_at, deleted_by_id, related_post_id, staff_took_action, deferred_by_id, targets_topic, agreed_at, agreed_by_id, deferred_at, disagreed_at, disagreed_by_id) FROM stdin;
\.


--
-- TOC entry 3392 (class 0 OID 0)
-- Dependencies: 204
-- Name: post_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_actions_id_seq', 1, false);


--
-- TOC entry 3258 (class 0 OID 18983)
-- Dependencies: 298
-- Data for Name: post_custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_custom_fields (id, post_id, name, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3393 (class 0 OID 0)
-- Dependencies: 297
-- Name: post_custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_custom_fields_id_seq', 1, false);


--
-- TOC entry 3226 (class 0 OID 18580)
-- Dependencies: 266
-- Data for Name: post_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_details (id, post_id, key, value, extra, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3394 (class 0 OID 0)
-- Dependencies: 265
-- Name: post_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_details_id_seq', 1, false);


--
-- TOC entry 3154 (class 0 OID 17126)
-- Dependencies: 194
-- Data for Name: post_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_replies (post_id, reply_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3232 (class 0 OID 18646)
-- Dependencies: 272
-- Data for Name: post_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_revisions (id, user_id, post_id, modifications, number, created_at, updated_at, hidden) FROM stdin;
1	1	19	--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\nraw:\n- "经过两周的设计,JDC的logo定稿,现发布如下:\\n大图标:  \\n<img src=\\"/uploads/default/4/2435daeed1465e41.png\\"\n  width=\\"500\\" height=\\"500\\"> \\n网站图标:  \\n<img src=\\"/uploads/default/5/a87baee6a18e9159.png\\"\n  width=\\"244\\" height=\\"66\\"> \\n小图标:  \\n<img src=\\"/uploads/default/6/0d11ff046aee0976.png\\"\n  width=\\"66\\" height=\\"66\\"> \\n\\n感谢yinnjiuu@sina.com的设计和实现\\n\\ngithub地址:\\nhttps://github.com/DengZuoheng/doc.jdc/tree/master/logo"\n- "经过两周的设计,JDC的logo定稿,现发布如下:\\n大图标:  \\n<img src=\\"/uploads/default/4/2435daeed1465e41.png\\"\n  width=\\"500\\" height=\\"500\\"> \\n网站图标:  \\n<img src=\\"/uploads/default/5/a87baee6a18e9159.png\\"\n  width=\\"244\\" height=\\"66\\"> \\n小图标:  \\n<img src=\\"/uploads/default/6/0d11ff046aee0976.png\\"\n  width=\\"66\\" height=\\"66\\"> \\n\\n构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑.\\n\\n感谢yinnjiuu@sina.com的设计和实现.\\n\\ngithub地址:\\nhttps://github.com/DengZuoheng/doc.jdc/tree/master/logo"\ncooked:\n- |-\n  <p>经过两周的设计,JDC的logo定稿,现发布如下:<br>大图标:<br><div class="lightbox-wrapper"><a data-download-href="//jnu-developer.com/uploads/default/09168762f2cd57283ff54ec17bf3b806733a9cfb" href="//jnu-developer.com/uploads/default/4/2435daeed1465e41.png" class="lightbox" title="JDC-logo(1024x1024).png"><img src="//jnu-developer.com/uploads/default/_optimized/09b/b17/6d2d8e0c76_500x500.png" width="500" height="500"><div class="meta">\n  <span class="filename">JDC-logo(1024x1024).png</span><span class="informations">1024x1024 130 KB</span><span class="expand"></span>\n  </div></a></div> <br>网站图标:<br><img src="//jnu-developer.com/uploads/default/5/a87baee6a18e9159.png" width="244" height="66"> <br>小图标:<br><img src="//jnu-developer.com/uploads/default/6/0d11ff046aee0976.png" width="66" height="66"> </p>\n\n  <p>感谢yinnjiuu@sina.com的设计和实现</p>\n\n  <p>github地址:<br><a href="https://github.com/DengZuoheng/doc.jdc/tree/master/logo" class="onebox" target="_blank">https://github.com/DengZuoheng/doc.jdc/tree/master/logo</a></p>\n- |-\n  <p>经过两周的设计,JDC的logo定稿,现发布如下:<br>大图标:<br><img src="/uploads/default/4/2435daeed1465e41.png" width="500" height="500"> <br>网站图标:<br><img src="/uploads/default/5/a87baee6a18e9159.png" width="244" height="66"> <br>小图标:<br><img src="/uploads/default/6/0d11ff046aee0976.png" width="66" height="66"> </p>\n\n  <p>构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑.</p>\n\n  <p>感谢yinnjiuu@sina.com的设计和实现.</p>\n\n  <p>github地址:<br><a href="https://github.com/DengZuoheng/doc.jdc/tree/master/logo" class="onebox" target="_blank">https://github.com/DengZuoheng/doc.jdc/tree/master/logo</a></p>\nedit_reason:\n- \n- ''\n	2	2014-11-30 15:17:02.021484	2014-11-30 15:17:02.021484	f
\.


--
-- TOC entry 3395 (class 0 OID 0)
-- Dependencies: 271
-- Name: post_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_revisions_id_seq', 1, true);


--
-- TOC entry 3194 (class 0 OID 17824)
-- Dependencies: 234
-- Data for Name: post_search_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_search_data (post_id, search_data, raw_data, locale) FROM stdin;
14	'uncategorized':31 '公告':12,27 '分类':2,17 '及':13,28 '发布':4,19 '和':8,23 '有关':5,20 '本':1,16 '本站':6,21 '条款':15,30 '用于':3,18 '的':10,25 '相关':14,29 '管理':7,22 '运行':9,24 '通知':11,26	本 分类 用于 发布 有关 本站 管理 和 运行 的 通知 公告 及 相关 条款 本 分类 用于 发布 有关 本站 管理 和 运行 的 通知 公告 及 相关 条款 Uncategorized 	zh_CN
15	'200':27 '一个':41 '一段':2,12,54 '下':68 '不同':98 '不要':25 '个':28 '中':50,56 '为什么':83 '主题':42,89 '么':103 '了':33,40 '事情':77 '人们':84 '什么':82,97 '信息':62 '关于':117 '其他':93 '内容':14,72 '再次':37 '出现':18,46 '分离':112 '分类':7,20,38,44,48,58,67,79,87,91,95,102,108,116,118 '列表':49 '创建':39 '务':120,122 '包含':65 '区域':22 '可以':63 '合并':109 '后':43 '吗':110 '和':92,106 '在':19,47,51 '在此':66 '在这里':64 '字符':29 '寻找':88 '导向':73 '将':17 '尽量':24 '已有':94,107 '并':8 '应该':105 '当':30 '您':31 '成':113 '我们':99,104 '或者':36 '所以':23 '才会':45 '接下':52 '描述':6,61 '文字':16,35,55 '更多':114 '替换':9 '有':96 '来做':81 '来的':53 '用':1,80 '的':4,13,59,70,115 '站':119,121 '第':11 '等等':74 '简短':3 '编辑':32 '考虑':75 '规则':71 '讨论':69 '话':5 '详细':60 '超过':26 '输入':57 '还是':111 '这':10 '这个':78,86,90,101 '这些':76 '这段':15,34 '选择':21,85 '需要':100	用 一段 简短 的 话 描述 分类 ， 并 替换 这 第 一段 的 内容 。 这段 文字 将 出现 在 分类 选择 区域 ， 所以 尽量 不要 超过 200 个 字符 。 当 您 编辑 了 这段 文字 或者 再次 分类 创建 了 一个 主题 后 ， 分类 才会 出现 在 分类 列表 中 。 在 接下 来的 一段 文字 中 输入 分类 的 详细 描述 信息 ， 可以 在这里 包含 在此 分类 下 讨论 的 规则 、 内容 导向 等等 。 考虑 这些 事情 ： 这个 分类 用 来做 什么 ？ 为什么 人们 选择 这个 分类 寻找 主题 ？ 这个 分类 和 其他 已有 分类 有 什么 不同 ？ 我们 需要 这个 分类 么 ？ 我们 应该 和 已有 分类 合并 吗 ？ 还是 分离 成 更多 的 分类 ？ 关于 分类 ： 站 务 站 务 	zh_CN
3	'about':14 'admins':11 'and':12 'are':7 'category':2,17 'discussions':5 'for':3 'moderators':13 'only':8 'private':1 'staff':4,16,18 'the':15 'to':10 'topics':6 'visible':9	Private category for staff discussions Topics are only visible to admins and moderators About the Staff category Staff 	zh_CN
5	'change':9 'contents':11 'edit':1 'first':3 'in':5 'of':12,15,19 'page':17 'post':4 'service':16,20 'staff':21 'terms':14,18 'the':2,10,13 'this':6 'to':8 'topic':7	Edit the first post in this topic to change the contents of the Terms of Service page Terms of Service Staff 	zh_CN
7	'change':9 'contents':11 'edit':1 'faq':14,17 'first':3 'guidelines':15,18 'in':5 'of':12 'page':16 'post':4 'staff':19 'the':2,10,13 'this':6 'to':8 'topic':7	Edit the first post in this topic to change the contents of the FAQ Guidelines page FAQ Guidelines Staff 	zh_CN
9	'change':9 'contents':11 'edit':1 'first':3 'in':5 'of':12 'page':16 'policy':15,18 'post':4 'privacy':14,17 'staff':19 'the':2,10,13 'this':6 'to':8 'topic':7	Edit the first post in this topic to change the contents of the Privacy Policy page Privacy Policy Staff 	zh_CN
6	'1':678 'a':3,20,26,30,63,79,191,237,352,477,489,581,630,655,692,699,770 'abide':795 'abusive':495 'account':441 'accrue':413 'acknowledging':397 'act':130 'action':414 'actual':244 'ad':232 'adds':103 'again':116 'against':765 'agree':793 'agreeable':202 'agreed':680 'aids':49 'already':171 'always':85,472 'an':289,688 'and':36,45,114,125,143,187,294,312,321,332,402,438,459,584,594,599,622,758,762,776,779,785 'any':436,439,443,446,455,466,551,743 'anyone':518 'anything':487,505,711 'appearance':549 'are':25,42,98,170,361,368,539 'arguments':253 'as':131,698 'ask':559 'at':445 'attached':672 'attacks':234 'audio':738 'authority':359 'automatically':419 'avoid':229,546 'avoiding':295 'bad':386,394 'be':138,201,293,375,416,473,482 'before':181 'behavior':387,395,778 'being':157 'belongs':714 'best':311 'better':192,344 'bookmarks':316 'boring':752 'breaking':742 'browsing':177 'but':221,366,753 'button':684 'by':84,166,214,279,396,421,469,657,759,796 'calling':231 'can':374,617 'category':635 'chance':193 'changing':658 'choosing':280 'civil':474,483 'civilized':4,69 'clean':64,501 'cleaning':624 'collectively':308 'community':28,56,278,306,376,429,471 'concrete':541 'consider':493 'consumes':399 'content':245,437,467,650,783 'contradiction':248 'contributions':314 'conversation':40,106,257,479 'conversations':262 'counter':252 'counts':260 'criticize':224 'cross':638 'data':764 'definitions':545 'describing':774 'descriptions':724 'different':694 'digital':712 'direction':695 'disagree':151,206 'disagreeing':215 'discourse':71,300 'discovering':167 'discussed':120 'discussing':146,621 'discussion':8,12,74,83,90,164 'discussions':284,589 'divert':654 'do':298,449 'don':388,484,502,513,529,627,636,646,652,661 'each':511 'edits':320 'effort':606 'either':418 'else':334,717 'enable':304 'encourages':392 'energy':401 'engage':282 'engines':586 'enough':411 'even':148,203,547 'every':666 'everyone':270,333,404 'existing':689 'experience':331 'explicit':509 'expose':522 'extension':760 'facilitators':377 'family':598 'faq':799 'fast':46 'favorites':315 'featured':569 'feel':564 'fine':220 'flag':354,408 'flags':318,412 'folks':767 'for':6,68,82,269,363,442,465,597,730,741 'forth':323 'forum':13,288,365,528,537,583 'found':347 'friends':600 'front':572 'future':275 'great':80 'grief':517 'guidelines':59,800 'happening':172 'harass':515 'hard':44 'has':668 'hate':497 'have':190,264,357,769 'healthy':478 'help':75,271,372 'here':121,180,265 'hominem':233 'how':561 'however':94 'human':52 'ideas':225 'identify':309 'if':96,132,149,349,410,555,565 'images':595,739 'impersonate':519 'improve':72,88,162,255,328 'in':91,283,424,454,610,632,643,691 'index':587 'influence':273 'information':525,671 'instead':241,249 'intellectual':734 'interesting':290 'interests':37,200 'intervention':423 'is':2,156,165,580,751 'it':217,348,355,391,398,409,500,602,659,674 'its':243 'janitors':380 'jerk':247 'judgment':53 'just':379,407 'keep':61,499,590,601 'knee':246 'knowledge':35 'language':592 'later':117 'law':745 'laws':786 'leave':341 'legalese':750 'less':623 'let':337 'lighted':66 'like':480,683 'likes':317 'links':593,726 'll':189 'maintain':427 'make':77,286,604 'matter':122,134 'may':208,708,721 'meeting':195 'merely':48 'methods':729 'midstream':660 'moderator':422 'moderators':356,373,430,448,458 'more':619 'multiple':644 'must':755,792 'name':230 'new':452,576,700 'no':463,649 'not':43,99,226,299,378,450,540,709,722 'nothing':475 'obscene':506 'of':54,140,154,194,242,276,550,552,574,725,747,772 'offensive':494 'on':570 'one':159 'ones':168 'ongoing':39 'only':703 'operators':461 'or':183,381,420,496,507,516,521,533,679,728,740 'order':425 'other':512,744 'others':196 'otherwise':534 'our':55,342,428,527,777,797 'ourselves':757 'over':108 'own':186,330,705 'page':573 'park':22,343 'participation':259 'people':145,227,520 'permission':719 'person':491 'place':5,31,67,81,291,613 'please':9,173,228 'police':382 'post':102,238,486,504,531,567,639,648,667,702,710,723 'posted':468 'posting':677 'posts':453,665 'precise':544 'preview':451 'privacy':784 'private':524 'problem':353 'profile':670 'property':735 'protect':756 'provide':250 'provides':301 'public':7,21,70,582 'put':608 'radically':693 'rather':675,685 're':557 'reason':444 'reasonable':490 'reasoned':251 'related':781 'remember':222 'remove':435 'replies':319,651 'reply':390,697 'replying':182 'reserve':431 'resource':29 'respect':17,510,526 'respectful':139 'respond':211 'responding':235 'responsibility':464 'responsible':362 'right':433,612 'rights':780 'rudeness':481 'rules':47 's':219,239,335,338,405,733 'sabotages':476 'safe':596 'said':158 'same':16,641 'say':113 'search':585 'see':351,385 'service':748,773,790 'set':266 'sexually':508 'share':33,198 'shared':27 'sign':663 'site':460 'skills':34 'small':95 'so':322,367,614,626 'software':736 'some':92,153,175 'someone':716,732 'something':213 'spam':532 'special':358 'speech':498 'spend':174,618 'staff':801 'start':629 'starting':184 'stealing':731 'stuff':706 'sure':100 't':389,485,503,514,530,628,637,647,653,662 'take':462 'taken':417 'taking':687 'terms':542,746,771 'than':345,676,686 'that':169,218,254,285,297,303,488,615,713 'the':15,51,73,89,105,118,141,144,163,178,256,261,267,274,305,310,393,432,457,470,536,548,571,575,591,605,611,633,640,682 'their':523 'them':147 'these':41,58,325,538,553,588 'they':133,360 'thing':642 'things':554,609 'think':107 'this':1,11,62,78,277,287,364,579,789 'those':296 'through':38 'tidy':603 'time':176,406,447,620 'times':578 'to':32,50,60,87,104,112,123,129,135,161,210,212,223,236,281,292,307,327,340,426,434,607,673,715,727,782,787,794 'tone':240,268 'too':24,137,336 'tools':302,326 'topic':631,656,690,701 'topics':119,142,179,645 'tos':798 'treat':10 'try':115,339 'unfriendly':766 'unsure':558 'up':625 'us':76,124,272 'use':57,324,681,696,788 'user':440 'vandalize':535 'video':737 'want':111,127 'was':568 'wastes':403 'way':93,160,456 'we':23,126,263,346,616,754,768 'well':65 'what':109,155 'when':204,383 'who':197 'will':415 'wish':209 'with':14,152,216,370,543 'without':718 'working':86 'worst':313 'would':19,492,563 'wrong':634 'yes':749 'york':577 'you':18,97,110,128,136,150,188,205,207,350,369,384,556,562,707,720,761,791 'your':101,185,199,258,329,371,400,566,664,669,704,763,775 'yourself':560	This is a Civilized Place for Public Discussion Please treat this discussion forum with the same respect you would a public park We too are a shared community resource — a place to share skills knowledge and interests through ongoing conversation These are not hard and fast rules merely aids to the human judgment of our community Use these guidelines to keep this a clean well lighted place for civilized public discourse Improve the Discussion Help us make this a great place for discussion by always working to improve the discussion in some way however small If you are not sure your post adds to the conversation think over what you want to say and try again later The topics discussed here matter to us and we want you to act as if they matter to you too Be respectful of the topics and the people discussing them even if you disagree with some of what is being said One way to improve the discussion is by discovering ones that are already happening Please spend some time browsing the topics here before replying or starting your own and you ’ ll have a better chance of meeting others who share your interests Be Agreeable Even When You Disagree You may wish to respond to something by disagreeing with it That ’ s fine But remember to criticize ideas not people Please avoid Name calling Ad hominem attacks Responding to a post ’ s tone instead of its actual content Knee jerk contradiction Instead provide reasoned counter arguments that improve the conversation Your Participation Counts The conversations we have here set the tone for everyone Help us influence the future of this community by choosing to engage in discussions that make this forum an interesting place to be — and avoiding those that do not Discourse provides tools that enable the community to collectively identify the best and worst contributions favorites bookmarks likes flags replies edits and so forth Use these tools to improve your own experience and everyone else ’ s too Let ’ s try to leave our park better than we found it If You See a Problem Flag It Moderators have special authority they are responsible for this forum But so are you With your help moderators can be community facilitators not just janitors or police When you see bad behavior don ’ t reply It encourages the bad behavior by acknowledging it consumes your energy and wastes everyone ’ s time Just flag it If enough flags accrue action will be taken either automatically or by moderator intervention In order to maintain our community moderators reserve the right to remove any content and any user account for any reason at any time Moderators do not preview new posts in any way the moderators and site operators take no responsibility for any content posted by the community Always Be Civil Nothing sabotages a healthy conversation like rudeness Be civil Don ’ t post anything that a reasonable person would consider offensive abusive or hate speech Keep it clean Don ’ t post anything obscene or sexually explicit Respect each other Don ’ t harass or grief anyone impersonate people or expose their private information Respect our forum Don ’ t post spam or otherwise vandalize the forum These are not concrete terms with precise definitions — avoid even the appearance of any of these things If you ’ re unsure ask yourself how you would feel if your post was featured on the front page of the New York Times This is a public forum and search engines index these discussions Keep the language links and images safe for family and friends Keep It Tidy Make the effort to put things in the right place so that we can spend more time discussing and less cleaning up So Don ’ t start a topic in the wrong category Don ’ t cross post the same thing in multiple topics Don ’ t post no content replies Don ’ t divert a topic by changing it midstream Don ’ t sign your posts — every post has your profile information attached to it Rather than posting “ 1 ” or “ Agreed ” use the Like button Rather than taking an existing topic in a radically different direction use Reply as a New Topic Post Only Your Own Stuff You may not post anything digital that belongs to someone else without permission You may not post descriptions of links to or methods for stealing someone ’ s intellectual property software video audio images or for breaking any other law Terms of Service Yes legalese is boring but we must protect ourselves – and by extension you and your data – against unfriendly folks We have a Terms of Service describing your and our behavior and rights related to content privacy and laws To use this service you must agree to abide by our TOS FAQ Guidelines Staff 	zh_CN
8	'13':631,650 '2013':736 '31':735 '5':316 '90':300 'a':71,248,279,328,361 'about':220,386,607 'access':266 'account':363,369 'act':615,661 'activities':588 'address':51,63,87,96,112,206,290 'addresses':305 'advertising':543 'age':648 'aggregate':384 'agree':493 'all':292,623 'allow':347 'also':103,501 'an':68 'and':17,29,48,90,174,197,234,310,357,375,382,389,400,441,573,587,603,620,643,683 'any':126,448,605 'applies':675 'appropriate':510 'are':324,425,622,628,645 'as':490 'asked':43 'assist':414,476 'associate':364 'associated':306 'at':551,629 'based':170 'be':42,65,135,210,536 'behalf':435 'believe':507 'better':152,397,417 'browser':344,356 'business':444,484 'by':26,67,691,728 'can':395 'cc':727 'change':712 'changes':221,703,720 'children':610,656 'collect':5,7,131 'collected':432,679,687 'compile':383 'compliance':616 'comply':512 'computer':337 'conduct':440 'conducting':482 'confidential':498 'consent':690,696 'containing':70,287 'content':32,586 'continually':163 'contract':407 'control':83 'cookies':321,323,349,372 'coppa':655 'customer':182,194 'data':19,273,385 'days':301 'decide':710 'directed':624 'disclose':447 'discretion':553 'do':3,120,241,318,445,454,662 'document':725 'does':469 'drive':340 'e':49,61,85 'effectively':190 'effort':282 'email':69,205 'emails':203 'enable':350 'enforce':516 'enter':45,263 'evaluating':30 'every':114 'except':436 'experience':146 'experiences':399 'faith':281 'feedback':175,606 'files':326 'following':141 'for':125,379,541,584 'forum':25 'from':9,101,132,178 'future':380,404 'gather':18 'good':280 'hard':339 'have':360,571,579 'help':438 'helps':149,186 'here':34 'how':240 'however':54,529 'identifiable':466,532 'if':74,345,358,636,708 'implement':247 'improve':159,166,181,442 'in':23,137,225,402,416,478,640 'include':109,471,556 'independent':574 'individual':156 'information':2,8,124,129,148,173,185,215,245,260,269,431,449,467,497,504,534,678,686 'inquiries':233 'integrity':599 'interaction':391 'ip':95,111,289,304 'is':77,271,509,639,726 'it':365,730 'its':331 'keep':495 'know':80 'last':732 'law':515 'least':630 'liability':583 'link':73,76 'linked':591 'links':549 'logs':107,286 'long':489 'mail':50,62,86 'maintain':254 'make':278 'marketing':542 'may':41,53,104,134,209,406,500,535,555,734 'measures':252 'more':189,298,314 'name':47,230 'needs':157,199 'no':297,313,580 'non':530 'nonetheless':593 'not':426,455,470,663,684 'notifications':216 'occasionally':550 'of':113,127,139,250,257,291,589,600,649,654 'offer':396,558 'offerings':169 'offline':688 'old':633 'older':635 'on':14,37,171,433,564,721 'one':138 'online':612,658,667,672 'only':670,676 'operating':479 'or':224,235,238,265,330,458,485,520,523,527,544,557,562,582,634 'originated':100 'other':236,539,545 'others':524 'otherwise':459 'our':15,38,56,117,160,167,419,434,443,480,483,517,552,565,601,617,681,693,698,705,713 'ours':522 'outside':451,462 'page':723 'participate':22 'parties':452,463,474,492,540 'party':410,548,560,569 'people':626 'per':651 'periodic':202 'permitted':427 'personal':259,268 'personalize':144 'personally':465,531 'policies':519,576 'policy':275,669,674,702,707,715,738 'post':99,718 'posting':91 'posts':312 'preferences':378 'privacy':575,613,659,668,673,701,706,714,737 'products':561,619 'property':526 'protect':243,521,597 'protection':614,660 'provide':208 'provided':537 'provider':333 'providers':412,424 'questions':239 'reading':27 'receive':177 'recognize':354 'record':93 'register':13 'registered':89,308,362,368 'registering':36,59 'release':502,508 'request':115,219 'requests':196,237,293 'requirements':653 'respond':153,191,231 'response':226 'responsibility':581 'retain':105,284,302 'retention':274 'rights':525 's':338,611,657 'sa':729 'safety':256,528 'save':376 'security':251 'seek':595 'sell':456 'send':201,213 'separate':572 'server':106,118,285,296,638 'service':183,195,332,411,423 'services':563,621 'servicing':486 'shared':33 'site':16,39,57,161,168,329,352,387,390,398,420,481,518,566,602,618,666,682,694,700 'sites':570,592,609 'small':325 'so':392,488 'staff':739 'strive':164 'submit':264 'support':198 'than':299,315 'that':75,81,97,217,327,393 'the':24,31,84,94,98,110,128,140,172,204,255,288,303,351,403,430,514,585,598,641,647,652 'their':311 'therefore':578 'these':348,422,567,590,608 'third':409,473,547,559,568 'this':295,468,496,637,665,671,722,724 'those':491,719 'through':341,680 'to':44,116,143,151,154,158,165,180,188,192,200,212,222,227,232,253,283,294,335,353,373,413,428,437,450,461,494,511,538,596,625,677,685,697,704,711 'tools':401 'topics':223 'trade':457 'traffic':388 'transfer':460 'transfers':334 'trusted':472 'under':646 'understand':374 'understanding':418 'unique':72 'updated':733 'us':150,187,415,439,477 'usa':642 'use':122,320,371,429,664 'used':136,211 'user':229 'users':309 'uses':546 'using':692 'variety':249 'verified':66 'visit':55 'visited':78 'visitor':533 'visitors':421 'visits':381 'was':731 'ways':142 'we':4,6,79,92,102,121,130,162,176,242,246,276,319,370,394,405,446,453,499,506,554,577,594,709,716 'web':343,699 'welcome':604 'what':1,119,270 'when':11,20,35,88,261,505 'which':108 'who':475,627 'will':64,277,717 'with':307,366,408,513 'without':58 'writing':28 'years':317,632 'yes':322 'you':10,12,21,40,52,82,133,179,207,214,218,262,346,359,487,644,695 'your':46,60,123,145,147,155,184,193,228,244,258,267,272,336,342,355,367,377,464,503,689	What information do we collect We collect information from you when you register on our site and gather data when you participate in the forum by reading writing and evaluating the content shared here When registering on our site you may be asked to enter your name and e mail address You may however visit our site without registering Your e mail address will be verified by an email containing a unique link If that link is visited we know that you control the e mail address When registered and posting we record the IP address that the post originated from We also may retain server logs which include the IP address of every request to our server What do we use your information for Any of the information we collect from you may be used in one of the following ways To personalize your experience — your information helps us to better respond to your individual needs To improve our site — we continually strive to improve our site offerings based on the information and feedback we receive from you To improve customer service — your information helps us to more effectively respond to your customer service requests and support needs To send periodic emails — The email address you provide may be used to send you information notifications that you request about changes to topics or in response to your user name respond to inquiries and or other requests or questions How do we protect your information We implement a variety of security measures to maintain the safety of your personal information when you enter submit or access your personal information What is your data retention policy We will make a good faith effort to Retain server logs containing the IP address of all requests to this server no more than 90 days Retain the IP addresses associated with registered users and their posts no more than 5 years Do we use cookies Yes Cookies are small files that a site or its service provider transfers to your computer s hard drive through your Web browser if you allow These cookies enable the site to recognize your browser and if you have a registered account associate it with your registered account We use cookies to understand and save your preferences for future visits and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future We may contract with third party service providers to assist us in better understanding our site visitors These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business Do we disclose any information to outside parties We do not sell trade or otherwise transfer to outside parties your personally identifiable information This does not include trusted third parties who assist us in operating our site conducting our business or servicing you so long as those parties agree to keep this information confidential We may also release your information when we believe release is appropriate to comply with the law enforce our site policies or protect ours or others rights property or safety However non personally identifiable visitor information may be provided to other parties for marketing advertising or other uses Third party links Occasionally at our discretion we may include or offer third party products or services on our site These third party sites have separate and independent privacy policies We therefore have no responsibility or liability for the content and activities of these linked sites Nonetheless we seek to protect the integrity of our site and welcome any feedback about these sites Children s Online Privacy Protection Act Compliance Our site products and services are all directed to people who are at least 13 years old or older If this server is in the USA and you are under the age of 13 per the requirements of COPPA Children s Online Privacy Protection Act do not use this site Online Privacy Policy Only This online privacy policy applies only to information collected through our site and not to information collected offline Your Consent By using our site you consent to our web site privacy policy Changes to our Privacy Policy If we decide to change our privacy policy we will post those changes on this page This document is CC BY SA It was last updated May 31 2013 Privacy Policy Staff 	zh_CN
4	'0':693 '1':215 '10':1596 '11':1621 '12':1666,2029 '13':212,1761 '14':1841 '15':1941 '16':2068 '17':2177 '18':2231 '2':299 '2013':2589 '3':677,692 '31':2588 '4':787 '5':937 '6':982 '7':1172 '8':1309 '9':1468 'a':292,450,626,686,780,830,855,888,966,1241,1408,1428,1458,1618,1877,1918,2256,2275,2311,2374,2396,2488 'abide':976 'acceptable':2128 'acceptance':74,194,1716 'access':175,751,1411,1702,1768,2291 'accessing':129,135 'accordance':1367,2088,2387,2408 'account':220,225,238,251,264,972,1620,1802 'accurate':1045 'accurately':653 'act':1375 'action':2037,2440 'activities':246 'acts':279,296,551 'actually':1913 'ad':1614 'adapted':2591 'add':1136 'advertised':598 'advertisements':1597,1605 'against':2203 'agents':2200 'agree':145,161,813,974,2180 'agreement':122,126,156,170,1472,1685,1693,1714,1760,1796,1818,1966,2025,2099,2230,2234,2238,2289,2381,2446,2460,2500,2528,2553,2557 'agrees':2536 'all':7,16,78,87,163,245,454,477,995,1185,1383,1398,1490,1521,1770,1814,1860,2102,2132,2206 'allow':319 'also':1103,1723 'amendment':2258 'amounts':784,1462,2012 'an':189,224,365,806,1613,2261 'and':4,15,19,42,58,82,86,101,104,152,166,185,239,344,377,383,474,520,580,612,615,641,655,662,753,789,844,897,944,956,980,992,1006,1061,1070,1097,1118,1139,1182,1197,1205,1226,1228,1274,1283,1307,1312,1351,1413,1489,1493,1496,1520,1527,1557,1641,1652,1730,1742,1747,1756,1837,1853,1856,1880,1889,1939,2071,2075,2100,2105,2127,2130,2157,2183,2190,2193,2199,2202,2205,2208,2242,2249,2318,2339,2398,2425,2452,2477,2486,2535,2543,2563,2574 'annual':821,858,906 'another':637 'any':138,180,259,266,278,285,288,320,332,345,408,442,466,487,497,590,698,724,734,741,759,764,783,914,917,935,1147,1150,1163,1217,1292,1295,1461,1481,1589,1681,1710,1772,1778,1863,1892,1961,1968,1981,2011,2045,2110,2174,2204,2285,2290,2323,2331,2367,2376,2433,2439,2456,2494,2502,2506,2517,2530 'applicable':880,905,2066,2103,2133,2282 'apply':2060 'appointed':2406 'appropriate':1390,1420 'arbitral':2427 'arbitration':2391,2413 'arbitrators':2405 'are':187,209,230,241,337,636,683,865,1051,1264,1360,1539 'area':2123 'arising':2213,2325,2378 'as':291,452,553,558,566,604,861,911,913,1056,1088,1090,1269,1315,1387,1502,1633,1849 'asks':1318 'assign':2523,2548 'assigns':2576 'at':22,210,934,1673,1777,1935 'attorneys':2211,2453 'attribution':689,1622,1630,1643 'audio':366 'author':1640 'authorize':899 'authorized':2262 'automatic':868 'automatically':895 'available':21,204,326,374,434,800,1193 'b':2559 'basis':833 'be':108,275,799,827,932,948,1009,1044,1427,1566,1660,1751,1898,1906,1956,2085,2253,2299,2336,2364,2383,2430,2448,2469,2538 'become':147 'before':128,875 'begin':838 'believe':1336 'believes':1040 'benefit':2568 'between':1503,2239 'beyond':2052 'binding':2561 'blogs':611 'bond':2375 'boost':538 'bound':148,2539 'breach':2503,2519 'breaches':268 'brought':2365 'but':28,395,438,2222 'by':60,117,134,149,191,282,327,371,672,950,962,977,1019,1156,1165,1238,1344,1391,1635,1820,2018,2065,2255,2260,2268,2271,2301,2403,2490,2540,2581 'california':2308,2347,2420 'can':931 'cancel':887 'canceled':933 'cannot':993,1007,1183 'card':919 'carefully':127 'case':354,646,1446 'categorized':654 'cause':1783,2035 'cc':2580 'cess':1903 'changes':1667,1696,1711,1719 'charged':828 'check':1691 'circumstances':1421 'city':2119 'claims':2207,2350,2357 'code':652 'collect':902 'collectively':120 'com':13,34,39,46,97,219,1203,1211,1224,1245,1305,1347,1514,1518,1535,1638,1656,1801 'commercial':527 'commons':688 'community':102,2095 'company':640 'competent':2368 'complied':464 'comprehensive':2390 'computer':369,651,1000,1063,1190,1276 'concerning':2244 'condition':2497,2515,2555 'conditions':5,83,153,167,186,957,981,1140,1757,2544 'conduct':2126 'conflict':2314 'connection':1531,1561 'consents':2533 'consequential':1985 'considered':188 'constitutes':362,1715,2235 'construed':2470 'contain':494,523,575,1079,1104 'contained':84 'containing':1092 'content':17,335,342,350,359,373,387,436,460,473,491,508,510,528,569,594,621,648,679,725,1015,1075,1080,1091,1169,1173,1288,1608,1646,1929,2129 'contents':1234 'continued':1698 'continuous':1907 'contract':1969 'contractors':2189 'contributions':682 'contributors':302 'control':1218,2055 'copying':382,1128 'copyright':400,1310,1350,1374 'copyrights':1433 'corruption':2005 'cost':1989 'costs':2451 'country':2117,2144,2152 'county':2346 'court':2369,2434 'courts':2341 'cover':846 'create':223,420 'creative':687 'credit':918 'credits':1651 'damages':286,1986 'data':2007,2140 'day':836 'decision':2428 'delay':2048 'deny':750 'described':657 'designed':529 'destructive':507,1074,1287 'determined':1425 'digital':1372 'directors':2196 'disabling':1397 'disclaim':1859 'disclaimer':1842 'disclaimers':1835 'disclaims':1146,1291 'discontinue':1810 'discretion':719,771,1676,1938 'display':1604,1629 'dispute':2377 'disputes':2324 'dmca':1313,1376 'do':159,670 'document':2578 'does':492,521,573,581,1025,1214,1251,1473 'done':476 'download':1924 'downloading':381,1127,1164 'drive':531 'due':2049 'during':2026 'e':2560 'each':959 'effect':2487 'effective':1788 'effects':663,1018 'either':423,2491 'electronic':601 'email':609 'employees':2198 'employer':413,429,449 'encouraged':1361 'end':485,877 'endorses':1032,1258 'enforce':2444 'enforced':2431 'engine':541 'english':2423 'entire':2237 'entirely':338 'entitled':2449 'entity':762 'equitable':1977,2354 'error':1899 'errors':1099 'event':1947 'example':12,33,38,45,96,218,1202,1210,1223,1244,1304,1346,1513,1517,1534,1637,1655,1800 'exceed':2014 'except':2278,2348 'excluding':2312 'executive':2263 'expenses':2209 'exported':2141 'express':1865 'expressly':196 'extent':2063,2281 'failure':2046 'features':1732,1746 'federal':2340 'fee':910 'fees':823,864,2016,2212,2454 'file':367 'finally':2384 'fitness':1875 'following':2,1706 'font':1642 'footer':1647,1650 'for':232,244,277,340,763,854,928,958,965,1011,1053,1149,1232,1266,1294,1695,1876,1979,1992,1998,2010,2044,2322,2349,2351 'force':2485 'foregoing':2057 'forum':35,63,66,119,193,257,272,674,705,716,729,736,768,773,817,874,952,988,1024,1145,1213,1250,1290,1317,1365,1370,1379,1405,1441,1451,1467,1478,1483,1509,1511,1546,1549,1591,1599,1624,1669,1721,1764,1852,1885,1950,2022,2039,2092,2187,2241,2266,2273,2546 'forums':41 'francisco':2345,2419 'free':1615,1900 'from':110,348,427,447,1065,1153,1162,1278,1298,1476,1925,2142,2201,2592 'full':2484 'fully':242,463 'further':549 'future':1726 'general':791,2069 'generated':519 'getting':597 'govern':6 'governed':2300 'governmental':2122 'grants':1578 'graphics':364,1526,1556 'guidelines':103,2096 'harm':346,1151,1296 'harmful':505,743,1049,1072,1285 'harmless':2185 'has':414,706,989 'have':422,462,475,643,775,925,1179,1216,1453,1611,1805,2041 'held':2462 'here':1916 'hereby':1858 'herein':85 'hereof':2248 'hold':2184 'horses':502,1069,1282 'hosting':47,49,939,943,967 'i':424,720,1980,2078 'if':157,182,221,303,411,1334,1352,1418,1790,1803,1910,2284,2455 'ii':445,747,1987,2158 'iii':1997 'immediately':254,1789 'implied':1867 'imply':1029,1255 'in':360,456,625,644,714,727,740,766,1356,1366,1444,1495,1530,1560,1644,1724,1945,2086,2115,2145,2153,2343,2366,2386,2407,2417,2421,2432,2438,2483,2505 'inaccuracies':1094 'inc':2401 'incidental':1983 'incite':578 'includes':650 'including':27,92,284,394,437,999,1189,1386,1736,1829,1868,2107,2131,2210,2221 'incurred':290 'indecent':1084 'indemnification':2178 'indemnify':2182 'indemnity':1836 'indicated':824,862 'individual':760 'individuals':207 'infringe':390,2166 'infringement':1311,1882 'infringer':1430 'infringes':1114 'infringing':1394,1402 'injunctive':2352 'install':496 'instance':2508 'intellectual':417,1116,1323,1329,1436,1469,1487,2170,2359 'intent':2476 'interest':1494 'interruption':1999 'into':632 'inure':2565 'invalid':2463 'is':56,69,195,203,352,511,514,570,595,622,739,1082,1133,1229,1424,1687,1847,1850,2461,2579 'it':1031,1039,1257,1326,1686,2583 'itional':1137 'its':1322,1674,1854,1887,1952,2188,2191,2313,2541,2549 'iv':2009 'jams':2402 'judicial':2395 'kind':289,1864 'language':2424 'last':2585 'law':2067,2283,2316 'laws':2104,2112,2134,2303 'least':211 'legal':1975 'liability':1840,1944,1972,2043 'liable':276,1957 'license':680,695,1583 'licensed':684 'licenses':469 'licensors':1551,1857,1890,1955,2192 'limitation':94,1831,1870,1942,2109 'limitations':1838 'limited':30,197,397,440,2224 'limiting':697 'link':1207 'linked':1342 'linking':1239 'links':311,606,1204,1399,1631 'lists':610 'local':2111 'located':1339,2342 'logo':1519 'logos':1528,1558 'loss':2003 'ltd':64 'machine':516 'made':1192 'maintaining':233 'make':317,324,433 'makes':1891 'making':372 'malware':500 'manner':627 'marks':1525,1555 'material':306,325,334,564,998,1013,1034,1042,1105,1188,1338,1395,1403 'materials':666 'matter':1963,2247 'matters':2051 'may':107,173,798,947,1078,1102,1565,1658,1722,1765,1808,2251,2363,2429,2522,2547,2587 'means':328 'mechanism':923 'mediation':2399 'merchantability':1874 'messages':602 'methods':619 'millennium':1373 'misappropriate':2168 'miscellaneous':2232 'mislead':556 'misleads':629 'mistakes':1096 'modification':76 'modified':2254 'modify':1678 'month':2030 'monthly':819,856,908 'must':253 'my':61 'named':624 'nature':660,1822 'necessary':479,1057,1270 'negligence':1970 'neither':1883 'new':1728,1740,1745 'newsgroups':608 'no':776,1454,1580,1946,2042 'non':1048,1221,1242,1302,1881 'noncommercial':690 'nor':1886 'not':29,160,174,274,389,396,439,493,512,515,522,571,574,582,596,623,710,866,990,1026,1180,1215,1230,1252,1474,1659,2059,2165,2223,2510 'notice':1787 'notices':1385 'notify':255,872,1363 'objectionable':745,1087 'obligation':712,777,1455 'obtain':1928 'occur':248 'of':9,77,79,140,154,168,236,258,262,269,287,294,301,329,343,356,385,407,543,562,589,647,664,699,755,782,849,878,984,996,1122,1131,1158,1168,1186,1301,1332,1415,1431,1439,1447,1460,1544,1569,1575,1663,1683,1700,1709,1717,1739,1758,1774,1816,1839,1843,1862,1873,1943,1964,1990,2000,2006,2036,2081,2138,2161,2173,2215,2218,2228,2264,2274,2295,2304,2307,2315,2327,2332,2373,2393,2458,2493,2498,2569,2596,2599 'offensive':1083 'offer':190,1727 'offered':70 'officers':2197 'old':214 'omissions':281,298 'on':114,226,312,607,801,829,834,926,1175,1340,1606 'one':1806,2507 'online':2125 'only':205,2252 'operated':59 'operating':89,1020 'opinion':732 'optional':793,807,942 'or':23,130,136,178,265,280,297,315,318,368,403,432,444,457,495,503,506,517,525,537,547,555,577,586,639,656,675,702,722,738,744,746,749,761,796,810,820,842,852,857,890,907,920,969,1017,1028,1037,1047,1073,1085,1110,1113,1125,1129,1142,1161,1235,1247,1254,1261,1286,1341,1389,1396,1434,1442,1484,1536,1541,1547,1582,1586,1592,1617,1648,1679,1701,1731,1748,1771,1781,1785,1797,1866,1901,1908,1926,1930,1951,1954,1973,1976,1984,1995,2002,2004,2008,2047,2113,2120,2150,2167,2267,2293,2328,2353,2356,2441,2464,2496,2501,2514,2516 'original':2475 'originally':2590 'other':88,267,504,921,1071,1098,1119,1176,1284,1435,1522,1552,1570,1974,2121 'others':1319,1333,1443 'otherwise':316,676,1086,1587,1927,2287 'out':2214,2326 'over':1219 'own':1937 'owned':57 'ownership':1832 'paid':786,794,808,1464,2017 'part':139,1682,1773,2457,2467 'particular':1878 'parties':1124,1505,1572,2474,2571 'party':322,410,468,535,545,592,1486,1594,2176,2437,2492,2531 'pass':482 'patent':401 'pay':815,832 'payment':788,922 'payments':825 'period':860,882,2031 'periodically':1694 'permission':426 'permitted':2575 'person':638 'phishing':554 'place':2416 'please':123 'policies':91 'policy':100,737,1314,1377,2094 'pornographic':572 'portions':2480 'post':305,310,431 'posted':1002,1036,1171,1174 'posting':1708,2270,2372 'powered':1634 'pre':831 'precautions':1055,1268 'prevailing':2436 'previously':785,1463 'prior':2032 'privacy':99,585,1109,2093 'procedures':105 'proceeding':2442 'procurement':1991 'products':20,1994 'prohibited':2064 'promotional':618 'proper':2320 'property':418,1117,1324,1330,1437,1470,1488,1499,2171,2360 'proprietary':392,1120 'protect':1059,1272 'provide':779,1457 'provided':949,1848 'provides':2286 'provisions':1815,1833,2317 'publicity':587,1111 'published':109 'purchased':1612,1665 'purpose':1879 'question':361 'randomly':518 'rankings':542 'rbitration':2397 're':1912 'read':124 'readers':631 'reading':1914 'reason':765 'reasonable':731,2054 'received':425 'recipients':557 'record':927 'reflect':2472 'refund':781,1459 'refundable':867 'refuse':721 'regarding':2124,2135,2358 'regardless':355,1662 'registered':1542 'regulations':2106,2114 'relating':470,2329 'release':1738 'relief':2355 'remain':1501,2482 'remaining':2479 'remove':723 'removed':1661 'removing':1392 'renew':896 'renewal':790,869 'repeat':1429 'replace':1680 'represent':376,1027,1253,2074 'representation':2070 'representations':701 'reproduce':1585 'requested':668 'required':488,1388 'reserves':1600,1625,1670 'reside':2156 'resides':1355,2149 'resources':1743 'respect':1321,1959 'respective':2195 'respects':1327 'respond':1381 'responsibility':300,983,1148,1293,1689 'responsible':231,243,339,1010,1052,1231,1265 'result':293 'resulting':347,1152,1297 'review':994,1184 'reviewed':991,1181 'revised':2276 'right':708,1491,1581,1602,1627,1672 'rights':393,406,415,455,588,1112,1121,1325,1331,1438,2172,2361,2525,2550 'risk':1940 'rules':90,2392,2411 's':98,717,730,769,1014,1371,1410,1550,1917,2310 'sa':2582 'same':2334 'san':2344,2418 'search':540 'secret':405 'secured':446 'security':235,270 'service':48,809,841,851,889,961,1524,1554,2400,2597,2600 'services':18,181,795,938,941,946,971,1619,1729,1749,1931,1996 'settled':2385 'shall':1750,1826,2040,2058,2382,2414,2447 'sharealike':691 'should':1823 'signed':2259 'signing':963 'similar':616 'simply':1809 'site':116,143 'sites':536,546,614 'so':671 'software':36,370,443,1001,1191 'sole':718,770,1675 'solely':1506 'source':561 'spam':513,605 'special':1982 'spoofing':567 'staff':2601 'state':2118,2306,2338 'stated':1141 'strict':1971,2087 'subject':71,1134,1752,1962,2246 'subscription':822,859,881,893,909 'subscriptions':930 'subsequent':2518 'substitute':1993 'successfully':481 'successors':2573 'such':295,333,552,565,603,960,978,1041,1259,1384,1448,1498,1632,1744,2410,2512 'suppliers':1855,1888,1953 'support':40,940,945,968,970 'survive':1824,1827 'systems':1064,1277 'take':2415 'taken':50 'taking':1054,1267 'taxes':915 'technical':1093,2139 'term':2495,2513 'terminate':748,1407,1766,1794 'termination':1449,1762,1825,1828 'terms':3,81,151,165,184,200,489,792,955,979,1138,1755,2542,2595,2598 'text':363 'that':106,247,349,351,379,628,634,649,726,850,883,1012,1030,1038,1081,1106,1206,1256,1337,1894,1902,1922,2013,2077,2466,2532 'the':1,10,25,43,52,54,67,80,121,132,141,150,164,176,201,227,234,250,308,313,330,341,353,358,380,386,391,399,435,459,472,490,509,539,560,563,568,584,645,658,665,707,711,756,802,818,835,840,847,876,879,903,954,997,1004,1021,1033,1076,1100,1108,1115,1126,1154,1159,1187,1195,1328,1357,1393,1401,1416,1422,1432,1445,1504,1515,1537,1563,1567,1576,1601,1626,1653,1671,1704,1707,1725,1734,1737,1754,1775,1812,1845,1871,1895,1933,1988,2015,2027,2034,2056,2062,2082,2090,2136,2143,2151,2162,2169,2219,2236,2245,2269,2280,2296,2302,2305,2319,2333,2337,2371,2389,2394,2412,2422,2426,2435,2473,2478,2567,2570,2593 'their':1233,1236,1821,2053,2194,2572 'theme':1639 'then':171,904 'theory':1978 'there':1035,1170 'therefore':1008 'thereof':2504,2520 'thereto':1904 'these':183,199,863 'they':2250 'things':478 'thinking':633 'third':321,409,467,534,544,591,1123,1485,1571,1593,2175 'this':115,125,155,169,1353,1471,1684,1692,1713,1759,1795,1817,1915,1965,2024,2098,2147,2229,2233,2288,2380,2445,2459,2499,2527,2552,2556,2577 'those':700,1166,1220,1718 'though':709 'threats':576 'three':2404 'through':24,483,1194,1733,1932 'time':111,113,936,1779 'title':1492 'to':31,72,112,146,162,198,206,307,323,398,416,430,441,453,458,471,480,484,530,533,548,559,669,713,752,758,778,814,886,901,975,1003,1043,1058,1135,1199,1208,1240,1271,1320,1343,1362,1382,1400,1412,1426,1456,1465,1479,1497,1584,1603,1628,1677,1690,1703,1712,1753,1769,1793,1960,2020,2033,2050,2061,2181,2225,2279,2292,2330,2443,2450,2471,2529,2534,2537,2566 'together':51 'toolbar':1649,1657 'tools':1741 'trade':404 'trademark':402 'trademarks':1523,1540,1543,1553,1568,1595 'traffic':532 'transfer':1475 'transmission':2137 'treat':1919 'trojan':501,1068,1281 'twelve':2028 'type':659 'typographical':1095 'u':2309 'unauthorized':260 'unconfigured':62,65,118,192,256,271,673,704,715,728,735,767,772,816,873,951,987,1023,1144,1212,1249,1289,1316,1364,1369,1378,1404,1440,1450,1466,1477,1482,1508,1510,1545,1548,1590,1598,1623,1668,1720,1763,1851,1884,1949,2021,2038,2091,2186,2240,2265,2272,2545 'under':249,685,953,1419,1967,2023,2379,2526,2551 'understand':1921 'unenforceable':2465 'unethical':524 'uninterrupted':1909 'unlawful':550 'unless':870,1609 'unported':694 'unsolicited':617 'unstated':1143 'unwanted':526,600 'up':964 'updated':2586 'upgrade':811,843,853,891,1616 'upgrades':797,1664 'upon':2562 'us':900 'usa':1358 'use':8,179,384,754,848,1016,1130,1155,1237,1300,1414,1574,1588,1699,2001,2080,2160,2217,2294 'used':1529,1559 'useful':1046 'user':678,681 'users':486 'uses':261,661 'using':131,137,916,1811 'utilizing':805,839 'venue':2321 'version':2277 'via':599 'violate':583 'violates':733,1107,1348 'violation':2227 'violence':579 'viruses':498,1066,1279 'visitor':1409,1423 'visitors':986,1157,1167 'waive':2511 'waiver':451,2489 'want':885 'warrant':378,2076 'warranties':703,1844,1861,1872 'warranty':1834,1893,2072 'was':2584 'way':742 'we':924,1178 'web':142,613 'webpage':1248,1262 'webpages':1198,1227,1308 'website':14,26,53,55,68,133,177,202,228,309,314,331,757,803,985,1005,1022,1077,1101,1160,1246,1260,1354,1417,1538,1564,1577,1705,1735,1776,1813,1846,1896,1934,2083,2148,2163,2220,2297 'websites':1177,1196,1225,1306 'well':912,1089 'when':804 'whether':357,667 'which':1132,1200,1819,2146,2154,2362 'who':208 'will':273,388,774,826,845,894,1380,1406,1452,1500,1897,1905,1948,2084,2164,2298,2335,2468,2481,2509,2558,2564 'wish':1792 'with':465,1368,1507,1532,1562,1780,1784,1958,2089,2097,2101,2388,2409 'without':75,93,696,1782,1786,1830,1869,2108,2370,2554 'wordpress':2594 'worms':499,1067,1280 'written':2257 'www':11,32,37,44,95,217,1201,1209,1222,1243,1303,1345,1512,1516,1533,1636,1654,1799 'years':213 'you':144,158,172,222,229,240,252,283,304,336,375,419,421,461,635,642,812,837,871,884,898,929,973,1050,1263,1335,1359,1480,1579,1610,1791,1804,1807,1911,1920,1923,2019,2073,2155,2179,2243,2521 'your':73,216,237,263,412,428,448,593,620,630,892,1062,1275,1299,1349,1573,1607,1645,1688,1697,1767,1798,1936,2079,2116,2159,2216,2226,2524 'yourself':1060,1273	The following terms and conditions govern all use of the www example com website and all content services and products available at or through the website including but not limited to www example com Forum Software www example com Support Forums and the www example com Hosting service Hosting taken together the Website The Website is owned and operated by My Unconfigured Forum Ltd Unconfigured Forum The Website is offered subject to your acceptance without modification of all of the terms and conditions contained herein and all other operating rules policies including without limitation www example com ’ s Privacy Policy and Community Guidelines and procedures that may be published from time to time on this Site by Unconfigured Forum collectively the Agreement Please read this Agreement carefully before accessing or using the Website By accessing or using any part of the web site you agree to become bound by the terms and conditions of this agreement If you do not agree to all the terms and conditions of this agreement then you may not access the Website or use any services If these terms and conditions are considered an offer by Unconfigured Forum acceptance is expressly limited to these terms The Website is available only to individuals who are at least 13 years old 1 Your www example com Account If you create an account on the Website you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account You must immediately notify Unconfigured Forum of any unauthorized uses of your account or any other breaches of security Unconfigured Forum will not be liable for any acts or omissions by you including any damages of any kind incurred as a result of such acts or omissions 2 Responsibility of Contributors If you post material to the Website post links on the Website or otherwise make or allow any third party to make material available by means of the Website any such material Content You are entirely responsible for the content of and any harm resulting from that Content That is the case regardless of whether the Content in question constitutes text graphics an audio file or computer software By making Content available you represent and warrant that the downloading copying and use of the Content will not infringe the proprietary rights including but not limited to the copyright patent trademark or trade secret rights of any third party if your employer has rights to intellectual property you create you have either i received permission from your employer to post or make available the Content including but not limited to any software or ii secured from your employer a waiver as to all rights in or to the Content you have fully complied with any third party licenses relating to the Content and have done all things necessary to successfully pass through to end users any required terms the Content does not contain or install any viruses worms malware Trojan horses or other harmful or destructive content the Content is not spam is not machine or randomly generated and does not contain unethical or unwanted commercial content designed to drive traffic to third party sites or boost the search engine rankings of third party sites or to further unlawful acts such as phishing or mislead recipients as to the source of the material such as spoofing the Content is not pornographic does not contain threats or incite violence and does not violate the privacy or publicity rights of any third party your content is not getting advertised via unwanted electronic messages such as spam links on newsgroups email lists blogs and web sites and similar unsolicited promotional methods your content is not named in a manner that misleads your readers into thinking that you are another person or company and you have in the case of Content that includes computer code accurately categorized and or described the type nature uses and effects of the materials whether requested to do so by Unconfigured Forum or otherwise 3 User Content License User contributions are licensed under a Creative Commons Attribution NonCommercial ShareAlike 3 0 Unported License Without limiting any of those representations or warranties Unconfigured Forum has the right though not the obligation to in Unconfigured Forum ’ s sole discretion i refuse or remove any content that in Unconfigured Forum ’ s reasonable opinion violates any Unconfigured Forum policy or is in any way harmful or objectionable or ii terminate or deny access to and use of the Website to any individual or entity for any reason in Unconfigured Forum ’ s sole discretion Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid 4 Payment and Renewal General Terms Optional paid services or upgrades may be available on the Website When utilizing an optional paid service or upgrade you agree to pay Unconfigured Forum the monthly or annual subscription fees indicated Payments will be charged on a pre pay basis on the day you begin utilizing the service or upgrade and will cover the use of that service or upgrade for a monthly or annual subscription period as indicated These fees are not refundable Automatic Renewal Unless you notify Unconfigured Forum before the end of the applicable subscription period that you want to cancel a service or upgrade your subscription will automatically renew and you authorize us to collect the then applicable annual or monthly subscription fee as well as any taxes using any credit card or other payment mechanism we have on record for you Subscriptions can be canceled at any time 5 Services Hosting Support Services Optional Hosting and Support services may be provided by Unconfigured Forum under the terms and conditions for each such service By signing up for a Hosting Support or Support services account you agree to abide by such terms and conditions 6 Responsibility of Website Visitors Unconfigured Forum has not reviewed and cannot review all of the material including computer software posted to the Website and cannot therefore be responsible for that material ’ s content use or effects By operating the Website Unconfigured Forum does not represent or imply that it endorses the material there posted or that it believes such material to be accurate useful or non harmful You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses worms Trojan horses and other harmful or destructive content The Website may contain content that is offensive indecent or otherwise objectionable as well as content containing technical inaccuracies typographical mistakes and other errors The Website may also contain material that violates the privacy or publicity rights or infringes the intellectual property and other proprietary rights of third parties or the downloading copying or use of which is subject to add itional terms and conditions stated or unstated Unconfigured Forum disclaims any responsibility for any harm resulting from the use by visitors of the Website or from any downloading by those visitors of content there posted 7 Content Posted on Other Websites We have not reviewed and cannot review all of the material including computer software made available through the websites and webpages to which www example com links and that link to www example com Unconfigured Forum does not have any control over those non www example com websites and webpages and is not responsible for their contents or their use By linking to a non www example com website or webpage Unconfigured Forum does not represent or imply that it endorses such website or webpage You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses worms Trojan horses and other harmful or destructive content Unconfigured Forum disclaims any responsibility for any harm resulting from your use of non www example com websites and webpages 8 Copyright Infringement and DMCA Policy As Unconfigured Forum asks others to respect its intellectual property rights it respects the intellectual property rights of others If you believe that material located on or linked to by www example com violates your copyright and if this website resides in the USA you are encouraged to notify Unconfigured Forum in accordance with Unconfigured Forum ’ s Digital Millennium Copyright Act DMCA Policy Unconfigured Forum will respond to all such notices including as required or appropriate by removing the infringing material or disabling all links to the infringing material Unconfigured Forum will terminate a visitor ’ s access to and use of the Website if under appropriate circumstances the visitor is determined to be a repeat infringer of the copyrights or other intellectual property rights of Unconfigured Forum or others In the case of such termination Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid to Unconfigured Forum 9 Intellectual Property This Agreement does not transfer from Unconfigured Forum to you any Unconfigured Forum or third party intellectual property and all right title and interest in and to such property will remain as between the parties solely with Unconfigured Forum Unconfigured Forum www example com the www example com logo and all other trademarks service marks graphics and logos used in connection with www example com or the Website are trademarks or registered trademarks of Unconfigured Forum or Unconfigured Forum ’ s licensors Other trademarks service marks graphics and logos used in connection with the Website may be the trademarks of other third parties Your use of the Website grants you no right or license to reproduce or otherwise use any Unconfigured Forum or third party trademarks 10 Advertisements Unconfigured Forum reserves the right to display advertisements on your content unless you have purchased an Ad free Upgrade or a Services account 11 Attribution Unconfigured Forum reserves the right to display attribution links such as ‘ Powered by www example com ’ theme author and font attribution in your content footer or toolbar Footer credits and the www example com toolbar may not be removed regardless of upgrades purchased 12 Changes Unconfigured Forum reserves the right at its sole discretion to modify or replace any part of this Agreement It is your responsibility to check this Agreement periodically for changes Your continued use of or access to the Website following the posting of any changes to this Agreement constitutes acceptance of those changes Unconfigured Forum may also in the future offer new services and or features through the Website including the release of new tools and resources Such new features and or services shall be subject to the terms and conditions of this Agreement 13 Termination Unconfigured Forum may terminate your access to all or any part of the Website at any time with or without cause with or without notice effective immediately If you wish to terminate this Agreement or your www example com account if you have one you may simply discontinue using the Website All provisions of this Agreement which by their nature should survive termination shall survive termination including without limitation ownership provisions warranty disclaimers indemnity and limitations of liability 14 Disclaimer of Warranties The Website is provided as is Unconfigured Forum and its suppliers and licensors hereby disclaim all warranties of any kind express or implied including without limitation the warranties of merchantability fitness for a particular purpose and non infringement Neither Unconfigured Forum nor its suppliers and licensors makes any warranty that the Website will be error free or that cess thereto will be continuous or uninterrupted If you ’ re actually reading this here ’ s a treat You understand that you download from or otherwise obtain content or services through the Website at your own discretion and risk 15 Limitation of Liability In no event will Unconfigured Forum or its suppliers or licensors be liable with respect to any subject matter of this agreement under any contract negligence strict liability or other legal or equitable theory for i any special incidental or consequential damages ii the cost of procurement for substitute products or services iii for interruption of use or loss or corruption of data or iv for any amounts that exceed the fees paid by you to Unconfigured Forum under this agreement during the twelve 12 month period prior to the cause of action Unconfigured Forum shall have no liability for any failure or delay due to matters beyond their reasonable control The foregoing shall not apply to the extent prohibited by applicable law 16 General Representation and Warranty You represent and warrant that i your use of the Website will be in strict accordance with the Unconfigured Forum Privacy Policy Community Guidelines with this Agreement and with all applicable laws and regulations including without limitation any local laws or regulations in your country state city or other governmental area regarding online conduct and acceptable content and including all applicable laws regarding the transmission of technical data exported from the country in which this website resides or the country in which you reside and ii your use of the Website will not infringe or misappropriate the intellectual property rights of any third party 17 Indemnification You agree to indemnify and hold harmless Unconfigured Forum its contractors and its licensors and their respective directors officers employees and agents from and against any and all claims and expenses including attorneys ’ fees arising out of your use of the Website including but not limited to your violation of this Agreement 18 Miscellaneous This Agreement constitutes the entire agreement between Unconfigured Forum and you concerning the subject matter hereof and they may only be modified by a written amendment signed by an authorized executive of Unconfigured Forum or by the posting by Unconfigured Forum of a revised version Except to the extent applicable law if any provides otherwise this Agreement any access to or use of the Website will be governed by the laws of the state of California U S A excluding its conflict of law provisions and the proper venue for any disputes arising out of or relating to any of the same will be the state and federal courts located in San Francisco County California Except for claims for injunctive or equitable relief or claims regarding intellectual property rights which may be brought in any competent court without the posting of a bond any dispute arising under this Agreement shall be finally settled in accordance with the Comprehensive Arbitration Rules of the Judicial A rbitration and Mediation Service Inc “ JAMS ” by three arbitrators appointed in accordance with such Rules The arbitration shall take place in San Francisco California in the English language and the arbitral decision may be enforced in any court The prevailing party in any action or proceeding to enforce this Agreement shall be entitled to costs and attorneys ’ fees If any part of this Agreement is held invalid or unenforceable that part will be construed to reflect the parties ’ original intent and the remaining portions will remain in full force and effect A waiver by either party of any term or condition of this Agreement or any breach thereof in any one instance will not waive such term or condition or any subsequent breach thereof You may assign your rights under this Agreement to any party that consents to and agrees to be bound by its terms and conditions Unconfigured Forum may assign its rights under this Agreement without condition This Agreement will b e binding upon and will inure to the benefit of the parties their successors and permitted assigns This document is CC BY SA It was last updated May 31 2013 Originally adapted from the WordPress Terms of Service Terms of Service Staff 	zh_CN
13	'0':1401,1427,1645 '1':712,1050,1403,1498,1544 '15':1501 '1gb':1788 '2':1405,1434,1464 '20px':234 '3':1134,1407,1632,1644 '4':1409 'a':159,170,197,235,241,242,249,250,257,258,265,266,274,275,282,364,371,683,703,721,758,779,793,827,830,853,972,995,1010,1032,1046,1092,1127,1199,1260,1271,1363,1417,1467,1472,1687,1722,1797,1943 'abilities':337,1379 'about':247,248,711,1119,1236,1454,1500 'access':46 'account':469 'accounts':425 'action':1471 'active':1399 'actual':1450 'add':322,430,1161,1198 'address':492,496 'adequate':1297 'adjusted':1558 'admin':20,24,35,39,42,56,343,485,834,1023,1069,1867,1949 'admins':301,1142 'advanced':1772 'advice':1719 'ahead':100 'all':85,316,621,768,802,805,962,1188,1411,1521,1531,1835 'allowed':1611 'already':402 'also':45,179,448,787,1770 'always':750,1160,1587,1595 'am':661 'amazon':1328 'an':23,490,706,1234,1845 'and':83,101,110,142,183,306,318,423,471,500,585,681,804,869,980,1102,1135,1143,1164,1251,1325,1336,1377,1481,1528,1593,1624,1701,1708,1779,1787,1834,1892,1925 'anonymous':632 'any':326,536,1043,1437 'anybody':1630 'anything':305,308 'appear':608 'approve':380,1530 'are':3,58,289,296,664,970,1355,1505,1518,1559,1815,1853 'area':367,1343,1758,1765 'aren':533,748 'arrive':1353 'as':22,692,1152,1178,1801 'asked':1016 'assets':125 'assist':1381 'assistance':1922 'assumes':361 'assuming':1183 'at':41,613,740,836,1082,1131,1209,1664,1720,1750 'attachments':1441 'audience':1157 'author':1622,1623 'automatic':1879 'back':203 'backups':1881 'banner':794,796,814,831,1690 'basic':897,1283,1404,1798 'bbpress':1915 'be':396,545,1243,1257,1264,1309,1345,1510,1670,1678 'because':650 'before':1676 'beginning':1192 'belongs':1279 'below':1026 'better':1172 'beyond':1311 'blog':269,272,273 'bottom':742,841,1752 'box':1291,1577 'brief':684 'broken':98 'browser':637 'build':456,941 'building':1667,1672,1721 'built':966 'bulk':1166,1777 'bunch':973,1261 'but':320,1487,1507 'button':344,1749 'buttons':356 'by':112,815,848,891,1641 'can':44,178,303,314,416,447,544,669,727,761,786,809,883,1154,1159,1214,1225,1368,1474,1493,1536,1546,1713,1743 'cannot':321,1430 'categories':323,889,912,914,923,1110,1115,1151,1163,1203 'category':399,406,777,1200,1208,1218,1230,1232,1238,1250,1270 'certain':1221 'change':325,374,884,901,1896 'chick':17,19 'choose':762 'civilized':12,957 'class':225 'clear':1273 'click':341,501,1206,1863 'clicking':816 'closely':514 'collaboratively':1100 'color':172 'colors':111,176 'com':239,246,254,262,271,280 'commit':1698 'common':194 'commonly':1557 'commons':953,1582,1640 'communities':569,871,1395,1673 'community':294,688,968,1005,1093,1360,1376,1385,1669,1683,1706,1724,1800,1803 'configure':307,412 'configured':481 'configuring':1924 'congratulations':1 'conservative':1512 'construction':14 'container':226,1820 'content':1572,1605,1615,1884,1909 'control':28 'controls':739 'copyright':1589 'corner':822 'correctly':482 'cpu':1786,1811 'create':169,1009,1147,1207 'creative':952,1581,1639 'css':168,182,217 'custom':181,184 'customize':108,175,190,216 'd':572,1302,1320 'daily':1880 'dashboard':21,40 'data':1895 'day':881 'dealing':999 'dedicated':551 'default':113,594,849,905,939,1114,1540,1636 'defaults':1392,1504,1579 'define':1681 'deliverability':519,543 'delivery':1885 'describe':699 'description':1253,1274 'design':129 'designed':1388 'detailed':997 'didn':522 'differently':723 'discourse':13,31,96,120,158,360,599,725,958,963,1361,1386,1578,1635,1723,1799,1840,1852,1901,1928,1932 'discussion':366,1118,1342,1694 'discussions':666 'disk':1298 'dismiss':811 'distinctive':160 'div':221,284 'do':102,304,339,977,1744 'docker':1819 'domain':1898 'don':1145,1488 'drupal':1914 'earn':1371 'easily':1165 'easy':1832,1861 'edit':165,315,398,677,1653,1662 'editable':1041,1101 'editing':892 'either':541 'elevator':694,707 'email':463,464,475,486,491,495,504,509,513,518,527,542,552,580,1741,1846,1890 'emails':540 'enable':575 'enabled':634 'enough':784,1600 'enter':71,84,489,1255 'entry':1081 'especially':1482 'establish':285 'etc':1916 'even':455,1396 'eventually':1874 'every':880,1087,1105,1231,1470 'everyone':754,1422,1538 'everywhere':1707 'example':211,238,245,253,261,270,279 'exercise':33 'export':1893 'extra':444 'facebook':435 'fancy':445 'faq':944,948,998,1018,1064,1079,1094 'far':926,930 'field':499,1456 'fields':88,94 'figure':1174 'file':1281,1316,1440 'files':1307,1326 'find':671,1714 'fine':566,1287 'first':654,1948 'flag':1445 'floating':813 'floats':798 'follow':131,1330 'footers':187 'for':69,123,126,353,467,567,590,620,667,753,867,1095,1129,1393,1421,1479,1484,1513,1554,1796,1920 'forever':752 'forum':1619,1629,1929 'forums':278,281 'free':562 'frequently':1015 'from':903,924,1076,1104,1190,1838,1910 'functions':57 'further':189 'gain':1378 'general':1117 'generally':59 'generous':561 'get':115,443,524,1186,1730,1844 'getting':535,875 'github':437 'give':156,1267 'globally':604,766 'go':74,99,1180 'good':1272 'google':431 'got':506 'governing':1383 'grant':333,355,1596 'great':510 'groups':1222,1783 'grows':1804 'guarantees':1831 'guide':1941,1952 'guidelines':969 'had':710 'hamburger':50,1078 'hard':546,1675 'has':516,1233,1362 'hatching':16,18 'have':26,403,734,1091,1112,1296,1449,1934 'having':163 'header':199,220 'headers':186 'height':233 'help':1919 'here':208,672,1006 'hide':728 'higher':1052,1136 'hint':1193 'home':240 'homepage':611,847,851,866,886,940 'hopefully':1813 'how':641,696,1008 'however':988 'howto':583,1332 'href':236,243,251,259,267,276 'html':185,212,218 'http':237,244,252,260,268,277 'https':1882 'hyperlinks':1435 'i':662,670,675 'icon':66,1025 'id':222,228 'if':368,386,439,570,778,989,1300,1318,1340,1516,1646 'image':147,1284 'images':1313,1324,1438,1562 'import':1891,1907 'important':517,649,1125 'improve':1937 'in':52,119,215,410,418,493,635,724,818,895,967,1067,1228,1259,1382,1416,1452,1466,1499,1686,1817 'include':1603 'includes':1771 'incognito':629 'individual':1548 'initial':1150,1235 'initially':1356 'inprivate':630 'install':1821 'installs':964 'instance':32,1858 'instances':1902 'instructions':133 'interesting':1696 'into':149,792,1062,1782 'introduction':685 'invitations':1726 'invite':384,1738,1748,1757,1764 'invites':1778 'inviting':1780 'is':97,196,209,409,465,480,587,596,602,648,652,852,921,937,949,1039,1099,1344,1387,1476,1526,1610,1633,1674,1736,1793 'isn':781 'it':47,411,479,515,606,640,651,691,765,773,902,1031,1123,1170,1187,1710,1715,1822,1830 'item':936 'its':776 'itself':1122 'just':1312 'kinds':298 'kit':15 'later':1169 'latest':858,907,915 'launching':1677 'leader':1410 'left':931 'leftmost':933 'level':1048,1133,1426,1497,1542 'licensing':1573,1583 'like':554,573,1303 'limited':1478 'link':1663,1704 'linked':1103 'links':231,1073,1451,1570 'list':619,855,890 'lists':770 'little':722 'll':106,1185 'local':421 'locally':1293 'log':417 'login':376,382,413,459 'logins':432,434,436,438 'logo':121,152 'logos':109,138 'look':68,122,161,192,352 'lots':876 'lounge':1126 'mailgun':556 'mailjet':558 'maintenance':1784 'make':477,824,1030 'mandrill':555 'manually':1534 'many':1149 'marked':60 'max':1561,1564,1569 'may':330,427,1509,1806 'me':1455,1947 'means':529,1036 'medium':870 'member':1406 'members':288 'memory':1790,1809 'mention':1461 'menu':51,894,935,1080 'messages':1444 'meta':1012,1116,1931 'method':460 'methods':414,1774 'might':1873 'minimum':1795 'minute':713 'minutes':1502 'mode':633 'moderation':1400 'moderators':312,1144 'modify':1314 'more':996,1162,1432,1462,1718,1808,1918,1921 'most':568 'move':922 'multiple':1900 'must':379 'name':1460,1899 'navbar':224,230 'navigation':198 'nc':1642 'need':1807,1917 'network':1886 'new':171,468,622,642,878,908,916,1011,1269,1333,1350,1402,1412,1428,1485,1491,1532,1549,1849 'news':255,256 'newuser':1555,1560,1563,1568 'no':1398 'not':1649 'note':716,1053 'notification':539,1847 'notifications':472 'now':4,104,946,1040,1089 'number':1631 'of':8,79,292,299,392,592,616,690,743,801,842,856,877,906,956,974,1003,1049,1086,1223,1248,1262,1289,1306,1374,1457,1575,1627,1656,1753,1775,1789,1851 'offer':560,1390 'official':290 'officially':1828 'often':984 'old':1908 'on':309,347,453,609,705,730,799,1107,1327,1590,1606,1617,1759,1766,1903,1923 'once':732 'one':193,373,404,591,789,1727,1785,1826,1862 'ones':1556 'only':385,388,774,1139,1220,1620,1825 'open':1346 'optimizations':1837 'or':166,324,358,454,538,557,631,771,825,829,840,1019,1051,1439,1447,1523,1689,1810,1938 'org':1933 'organization':1177 'other':334,1304,1870 'our':1818,1860 'out':1175,1288,1415,1574 'over':29,1369 'overwhelm':1155 'own':11,458,943 'owner':7,1599,1626 'page':350,1088,1106,1204,1762,1769 'pages':807 'parent':206 'participating':1702 'parts':391 'password':424 'paste':144,1059 'paths':148 'patient':1671 'penciled':118 'people':1276,1712,1731 'per':1217,1566 'perk':1128 'permanently':810 'permissions':400 'phpbb':1912 'pin':757,764,772,780,828 'pinned':603,751,1244,1688 'pinning':718 'pins':729 'pitch':695 'places':975,1263 'plans':563 'please':976 'post':1028,1034,1038,1431,1436,1468 'posted':1616 'posts':317,859,1446,1592 'pre':1519 'prefer':370 'primary':806 'private':357,372,397,405,1443,1527 'probably':532 'process':1865 'products':263,264 'profile':1459,1761,1768 'promote':1709 'proud':6 'provide':960 'provided':1294 'public':359,365,1349,1394 'pull':1944 'purpose':1685 'put':214 'questions':1017 'quick':1950 'quickly':155 'rate':1477 'rather':1181,1321 'read':511,735,1946 'really':986 'recategorize':1167 'recommend':549,862 'recommended':1836 'refer':981 'referenced':971 'regular':1408 'regularly':1703 'relax':1547 'released':1854 'remove':826 'replies':1565 'reply':1888 'replying':576 'representatives':291 'republish':1613 'request':195,1945 'required':72,77,87,93,151,383,466 'resources':1812 'restrictions':1420,1551 'retain':1588 'right':55,612,821,839,927,945,1085,1189,1212 'rights':1601 'rules':955 'running':1816,1926 's':1007,1124,1171,1423,1539,1638,1648,1684,1717,1823 's3':1329 'sa':1643 'safe':1391,1506 'safety':1424,1480 'same':951,1905 'sandbox':1335,1418 'scheme':173 'search':1552 'security':1216 'see':581,639,659,1226,1930 'seed':1692 'send':502,1442 'sending':1725,1776 'server':1906 'service':1657 'services':553 'set':91,449,845,993,1215,1537,1877 'setting':1066 'settings':73,82,153,328,378,487,900,1071,1317,1553 'setup':898 'should':674,1843 'sign':452 'signup':537 'signups':470 'similar':1020 'simple':854 'single':451,790 'site':81,128,207,311,327,377,394,589,627,701,899,1070,1097,1109,1121,1515,1525,1598,1608,1735 'small':868 'so':67,340,605,746,1219,1275,1483,1711 'some':210,390,1869 'sorts':1305 'space':1299 'span':227,283 'specifics':1002 'specify':180 'staff':286,287,300,336,1137,1141,1773,1953 'standard':117 'starred':910,918 'start':874,1414,1951 'sticking':863 'store':1322 'stored':1292 'stranger':704 'strangers':1357 'strongly':548,861 'style':232 'submit':1942 'suggestions':1935 'superpowers':36 'support':1829,1883,1887 'sure':478,1265,1679 'swap':1792 'system':1339,1365 't':523,534,749,782,1146,1196,1489 'tab':78 'take':1475 'takes':201 'talk':715 'taste':1659 'team':1841 'terms':1655 'test':461,473,498,503,508,526 'than':1182,1433,1463 'that':70,103,140,200,512,564,717,920,932,1057,1060,1098,1229,1354,1637,1647 'the':5,38,49,53,62,76,80,86,116,124,127,132,145,150,191,205,342,354,484,494,507,525,593,610,614,617,653,738,741,744,795,817,819,833,837,843,846,857,885,888,896,904,925,929,950,1001,1022,1027,1037,1054,1063,1068,1077,1083,1108,1120,1176,1191,1202,1210,1246,1249,1252,1290,1315,1337,1348,1359,1372,1375,1453,1576,1597,1607,1614,1621,1625,1634,1654,1661,1665,1693,1747,1751,1754,1756,1763,1794,1824,1839,1897,1904 'their':348,1384,1458,1591,1604 'them':736,979,983,1739 'then':143,351,488,1205 'there':134,295,1280,1716 'these':92,375,665,965,1503 'they':733,747,985,1508 'thing':655 'things':1871 'think':689 'this':30,293,310,407,528,582,588,600,700,812,865,1035,1072,1237,1240,1331,1618,1628,1745,1940 'three':1113 'time':1370 'tips':520 'titled':1014 'to':75,135,139,154,164,188,204,213,332,338,395,429,442,476,497,574,577,598,638,686,702,714,763,767,823,887,913,928,961,982,992,1029,1042,1056,1140,1173,1197,1245,1266,1308,1347,1358,1380,1389,1495,1543,1580,1602,1612,1658,1680,1699,1729,1732,1737,1855,1876,1936 'too':1148,1511 'top':223,229,615,800,838,893,911,919,934,1084,1247,1666 'topic':130,141,408,601,618,647,680,745,759,769,791,797,844,1013,1058,1075,1239,1241,1567,1691,1755 'topics':578,595,719,731,803,879,1168,1227,1448,1697 'total':27 'traditional':420 'transition':1494 'trust':1047,1132,1338,1364,1373,1425,1496,1541 'try':624 'turn':788 'twitter':433 'two':297 'under':219 'understand':167,1277 'universal':954 'unread':909,917 'until':89,872 'up':450,994,1878 'update':1856,1939 'updates':1833 'upgrade':1864,1868 'upload':136 'uploaded':146,1310 'uploads':1282,1285 'upper':54,820,1211 'url':1055,1061,1065 'use':832,978,1021 'used':1258 'user':349,1044,1334,1473,1550,1571 'username':422 'users':319,335,381,415,531,623,643,726,808,1130,1224,1367,1413,1429,1465,1486,1492,1522,1533,1585,1781 'using':550 'vanilla':1913 'vbulletin':1911 'versions':1850 'very':10 'vetting':1520 'via':37,48,174,579,737,1660,1740,1746,1859,1889 'viewing':625 'virtually':1469 'visible':783,1138 'visit':483,676,1201,1733,1866 'visiting':1700 'visitors':657,1351 'wait':107 'want':331,363,389,428,441,991,1652,1875 'way':1728 'we':105,547,860,959,1827 'welcome':597,646,679 'what':584,668,1278,1650 'when':708,755,1848 'where':660,1366 'which':559 'who':302,313,586,663,1609 'why':673 'wiki':1033 'will':607,644,658,1242,1256,1352,1586,1594 'with':61,419,628,864,1000,1045,1397,1419,1695,1791 'within':775 'without':162 'won':1195 'work':565,987,1286 'works':720 'worry':1490 'would':697 'wrench':63,64,65,345,346,835,1024 'write':682 'you':2,25,43,90,114,177,202,329,362,369,387,401,426,440,446,505,521,571,656,698,709,756,760,785,873,882,990,1090,1111,1153,1158,1179,1184,1194,1213,1254,1295,1301,1319,1517,1529,1535,1545,1651,1742,1805,1814,1842,1872 'your':9,34,95,137,157,393,457,462,474,530,626,636,645,678,687,693,850,938,942,947,1004,1074,1096,1156,1268,1323,1341,1514,1524,1584,1668,1682,1705,1734,1760,1767,1802,1857,1894,1927	Congratulations you are now the proud owner of your very own Civilized Discourse Construction Kit hatching chick hatching chick Admin Dashboard As an admin you have total control over this Discourse instance Exercise your admin superpowers via the admin dashboard at admin You can also access it via the hamburger ☰ menu in the upper right Admin functions are generally marked with the wrench wrench wrench icon so look for that Enter Required Settings Go to the Required tab of the site settings and enter all the required fields Until you set these required fields your Discourse is broken Go ahead and do that now We ll wait Customize Logos and Colors By default you get the standard penciled in Discourse logo Look for the assets for the site design topic follow the instructions there to upload your logos to that topic and then paste the uploaded image paths into the required logo settings To quickly give your Discourse a distinctive look without having to edit or understand CSS create a new color scheme via Customize Colors You can also specify custom CSS and custom HTML headers footers to further customize the look One common request is a navigation header that takes you back to the parent site Here is some example HTML to put in Customize CSS HTML under Header div id top navbar class container span id top navbar links style height 20px a href http example com Home a a href http example com about About a a href http example com news News a a href http example com products Products a a href http blog example com blog Blog a a href http forums example com Forums a span div Establish Staff Staff members are official representatives of this community There are two kinds of Staff Admins who can do anything and configure anything on this site Moderators who can edit all posts and users but cannot add categories or change any site settings You may want to grant other users staff abilities – to do so click the admin button wrench wrench on their user page then look for the grant buttons Private or Public Discourse assumes you want a public discussion area If you prefer a private one change these login site settings must approve users login required invite only If you only want some parts of your site to be private edit category permissions You already have one private category this topic is in it Configure Login Methods Users can log in with traditional local username and password accounts You may want to add Google logins Twitter logins Facebook logins GitHub logins If you want to get extra fancy you can also set up single sign on or even build your own login method Test Your Email Email is required for new account signups and notifications Test your email to make sure it is configured correctly Visit the admin email settings then enter an email address in the email address to test field and click send test email You got the test email Great Read that email closely it has important email deliverability tips You didn t get the test email This means your users probably aren t getting any signup or notification emails either Email deliverability can be hard We strongly recommend using dedicated email services like Mandrill MailGun or MailJet which offer generous free plans that work fine for most communities If you d like to enable replying to topics via email see this howto What and Who is this site for One of the default topics is Welcome to Discourse This topic is pinned globally so it will appear on the homepage right at the top of the topic list for all new users Try viewing your site with incognito inprivate or anonymous mode enabled in your browser to see it how new users will Your welcome topic is important because it is the first thing you visitors will see Where am I Who are these discussions for What can I find here Why should I visit Edit your welcome topic and write a brief introduction to your community Think of it as your elevator pitch – how would you describe this site to a stranger on an elevator when you had about 1 minute to talk Note that pinning topics works a little differently in Discourse Users can hide pins on topics once they have read them via the controls at the bottom of the topic so they aren t always pinned forever for everyone When you pin a topic you can choose to pin it globally to all topic lists or pin it only within its category If a pin isn t visible enough you can also turn one single topic into a banner The banner topic floats on top of all topics and all primary pages Users can permanently dismiss this floating banner by clicking the × in the upper right corner To make or remove a pin or a banner use the admin wrench at the top right or bottom of the topic Set the Homepage By default your homepage is a simple list of the latest posts We strongly recommend sticking with this homepage for small and medium communities until you start getting lots of new topics every day You can change the homepage to the Categories list by editing top menu in the Basic Setup site settings Change it from the default of latest new unread starred top categories to categories latest new unread starred top That is move categories from the far right to the far left that leftmost top menu item is your default homepage Build Your Own FAQ Right now your FAQ is the same Creative Commons universal rules of civilized discourse we provide to all Discourse installs These built in community guidelines are referenced a bunch of places please do use them and refer to them often – they really work However if you want to set up a more detailed FAQ dealing with the specifics of your community here s how Create a new meta topic titled Frequently Asked Questions FAQ or similar Use the admin wrench icon below the post to make it a wiki post This means the post is now editable to any user with a trust level of 1 or higher Note the URL to that topic Paste that URL into the faq url setting in the admin site settings This links your topic from the hamburger FAQ menu entry at the top right of every page Now you have a community FAQ for your site that is collaboratively editable and linked from every page on the site Categories You have three default categories Meta – general discussion about the site itself It s important Lounge – a perk for users at trust level 3 and higher Staff – visible only to staff admins and moderators Don t create too many initial categories as you can overwhelm your audience You can always add more categories and easily bulk recategorize topics later It s better to figure out the organization as you go rather than assuming you ll get it all right from the beginning hint you won t To add a category visit the categories page then click Create Category at the upper right You can set security per category so only certain groups of users can see topics in that category Every category has an initial About this category topic This topic will be pinned to the top of the category and the description you enter will be used in a bunch of places Be sure to give your new category a good clear description so people understand what belongs there File Uploads Basic image uploads work fine out of the box stored locally provided you have adequate disk space If you d like other sorts of files to be uploaded beyond just images modify the file settings If you d rather store your images and files on Amazon S3 follow this howto New User Sandbox and the Trust System If your discussion area is be open to the public new visitors will arrive that are initially strangers to the community Discourse has a trust system where users can over time earn the trust of the community and gain abilities to assist in governing their community Discourse is designed to offer safe defaults for public communities even with no active moderation 0 new → 1 basic → 2 member → 3 regular → 4 leader All new users start out in a sandbox with restrictions for everyone s safety Trust level 0 new users cannot … post more than 2 hyperlinks post any images or file attachments send private messages flag posts or topics have actual links in the about me field of their profile name mention more than 2 users in a post Virtually every action a user can take is rate limited for safety and especially so for new users But don t worry new users can transition to trust level 1 in about 15 minutes These defaults are safe but they may be too conservative for your site If you are pre vetting all users or your site is private and you approve all new users manually you can set everyone s default trust level to 1 You can relax individual new user restrictions Search settings for newuser Ones commonly adjusted are newuser max images newuser max replies per topic newuser max links User Content Licensing Out of the box Discourse defaults to Creative Commons licensing Your users will always retain copyright on their posts and will always grant the site owner enough rights to include their content on the site Who is allowed to republish the content posted on this forum Only the author Author and the owner of this forum Anybody Number 3 is the Discourse default – that s Creative Commons BY NC SA 3 0 If that s not what you want edit the Terms of Service to taste via the edit link at the top Building Your Community Be patient Building communities is hard Before launching be sure to Define your community s purpose in a pinned or banner topic Seed the discussion with interesting topics Commit to visiting and participating regularly Link your community everywhere and promote it so people can find it There s more advice at Building a Discourse Community Sending Invitations One way to get people to visit your site is to invite them via email You can do this via The Invite button at the bottom of the topic The Invite area on your profile page The invite area on your profile page also includes advanced Staff methods of sending bulk invites and inviting users into groups Maintenance One CPU and 1GB of memory with swap is the minimum for a basic Discourse community As your community grows you may need more memory or CPU resources Hopefully you are running in our Docker container install it s the only one we officially support It guarantees easy updates and all recommended optimizations from the Discourse team You should get an email notification when new versions of Discourse are released To update your instance via our easy one click upgrade process visit admin upgrade Some other things you might eventually want to set up Automatic daily backups HTTPS support Content Delivery Network support Reply via Email Import and Export your data Change the domain name Multiple Discourse instances on the same server Import old content from vBulletin PHPbb Vanilla Drupal BBPress etc Need more Help For more assistance on configuring and running your Discourse forum see meta discourse org Have suggestions to improve or update this guide Submit a pull request READ ME FIRST Admin Quick Start Guide Staff 	zh_CN
12	'3':20,57 'a':46,63 'access':45 'all':37 'an':82 'and':58 'any':28,34 'at':54 'automatic':41 'ball':3,5 'be':74 'being':81 'can':8,22 'category':32,49 'change':30 'community':87 'confetti':2,4 'congratulations':1 'continue':103 'current':69 'edit':24 'fellow':72 'flag':65 'followed':40 'for':80,88 'have':36 'here':66 'hi':78 'hide':60 'higher':59 'if':6 'important':83 'information':90 'is':43 'level':19,56 'levels':93 'links':39 'list':70 'lounge':48,116,117 'meet':105 'members':101 'more':89 'nofollow':42 'note':98 'now':23 'of':27,33,71,85 'on':91 'only':50,100 'over':108 'part':84 'please':97 'private':47 'promoted':15 'recently':14 'regular':17 'regulars':73,112 'remain':111 'removed':44 'requirements':107 's':67 'say':77 'see':9,94 'single':64 'spam':61 'sure':75 'thanks':79 'that':99 'the':25,31,68,106,115 'this':10,86,95 'time':109 'title':26 'to':16,52,76,104,114 'topic':11,29,35,96 'trust':18,55,92 'users':53 'visible':51 'welcome':113 'were':13 'who':102 'will':110 'with':62 'you':7,12,21 'your':38	Congratulations confetti ball confetti ball If you can see this topic you were recently promoted to regular trust level 3 You can now … Edit the title of any topic Change the category of any topic Have all your links followed automatic nofollow is removed Access a private Lounge category only visible to users at trust level 3 and higher Hide spam with a single flag Here s the current list of fellow regulars Be sure to say hi Thanks for being an important part of this community For more information on trust levels see this topic Please note that only members who continue to meet the requirements over time will remain regulars Welcome to the Lounge Lounge 	zh_CN
16	'200':27 '一个':41 '一段':2,12,54 '下':68 '不同':98 '不要':25 '个':28 '中':50,56 '为什么':83 '主题':42,89 '么':103 '了':33,40 '事情':77 '人们':84 '什么':82,97 '信息':62 '关于':117 '其他':93 '内容':14,72 '再次':37 '出现':18,46 '分离':112 '分类':7,20,38,44,48,58,67,79,87,91,95,102,108,116,118 '列表':49 '创建':39 '包含':65 '区域':22 '可以':63 '合并':109 '后':43 '吗':110 '和':92,106 '在':19,47,51 '在此':66 '在这里':64 '字符':29 '寻找':88 '导向':73 '将':17 '尽量':24 '已有':94,107 '并':8 '应该':105 '当':30 '您':31 '成':113 '我们':99,104 '或者':36 '所以':23 '才会':45 '接下':52 '描述':6,61 '文字':16,35,55 '更多':114 '替换':9 '有':96 '来做':81 '来的':53 '活动':119,120 '用':1,80 '的':4,13,59,70,115 '第':11 '等等':74 '简短':3 '编辑':32 '考虑':75 '规则':71 '讨论':69 '话':5 '详细':60 '超过':26 '输入':57 '还是':111 '这':10 '这个':78,86,90,101 '这些':76 '这段':15,34 '选择':21,85 '需要':100	用 一段 简短 的 话 描述 分类 ， 并 替换 这 第 一段 的 内容 。 这段 文字 将 出现 在 分类 选择 区域 ， 所以 尽量 不要 超过 200 个 字符 。 当 您 编辑 了 这段 文字 或者 再次 分类 创建 了 一个 主题 后 ， 分类 才会 出现 在 分类 列表 中 。 在 接下 来的 一段 文字 中 输入 分类 的 详细 描述 信息 ， 可以 在这里 包含 在此 分类 下 讨论 的 规则 、 内容 导向 等等 。 考虑 这些 事情 ： 这个 分类 用 来做 什么 ？ 为什么 人们 选择 这个 分类 寻找 主题 ？ 这个 分类 和 其他 已有 分类 有 什么 不同 ？ 我们 需要 这个 分类 么 ？ 我们 应该 和 已有 分类 合并 吗 ？ 还是 分离 成 更多 的 分类 ？ 关于 分类 ： 活动 活动 	zh_CN
1	'3':9 'a':1 'about':12 'and':10 'category':2,15 'exclusive':3 'higher':11 'level':8 'lounge':14,16 'members':5 'the':13 'to':4 'trust':7 'with':6	A category exclusive to members with trust level 3 and higher About the Lounge category Lounge 	zh_CN
2	'about':2,16 'and':10 'can':13 'category':19 'discussion':1 'how':7,11 'improve':14 'it':8,15 'its':5 'meta':18,20 'organization':6 'site':4 'the':17 'this':3 'we':12 'works':9	Discussion about this site its organization how it works and how we can improve it About the Meta category Meta 	zh_CN
11	'a':12,28 'admin':65 'all':16 'an':81 'and':71 'announcement':82 'as':11 'at':67 'be':9 'bottom':72 'brief':29 'can':39,49 'close':60 'come':46 'community':33 'description':30 'discourse':85 'don':76 'edit':25 'etc':55 'find':41 'first':2 'for':37 'here':42,47 'homepage':21 'important':24 'into':27 'is':35 'it':22,36 'links':53 'may':57 'message':14 'more':52 'new':17 'of':4,31 'on':19,80 'paragraph':3 'pile':78 'pinned':6 'read':51 'replies':75 'resources':54 'right':70 's':23 'should':44 'so':73 't':77 'that':74 'the':1,64,68 'they':40,45,50 'this':5,26,61 'to':15,59,84 'topic':7,62 'uncategorized':86 'up':79 'upper':69 'via':63 'visible':10 'visitors':18 'want':58 'welcome':13,83 'what':38 'where':48 'who':34 'why':43 'will':8 'wrench':66 'you':56 'your':20,32	The first paragraph of this pinned topic will be visible as a welcome message to all new visitors on your homepage It s important Edit this into a brief description of your community Who is it for What can they find here Why should they come here Where can they read more links resources etc You may want to close this topic via the admin wrench at the upper right and bottom so that replies don t pile up on an announcement Welcome to Discourse Uncategorized 	zh_CN
10	'a':3 'all':32 'and':13,42,57,93 'assets':127 'authorized':121 'basic':109 'click':69,85 'copy':100 'delete':22 'design':19,131 'different':116 'don':20 'drag':56 'drop':58 'edit':87,90,120 'editor':54 'enable':115 'extensions':122 'favicons':41 'file':117,125 'files':14 'for':10,39,128 'forth':44 'get':77 'here':24,45 'how':26 'icon':50,88 'if':111 'image':102,106 'images':12,34,61,71,83,99 'in':16,51,72,123 'into':108 'is':2 'it':23,67 'logos':40 'need':113 'new':74 'only':7 'or':55,59,84 'paste':60,104 'path':79,96 'paths':103,107 'permanent':4 'post':53,66,75,92 'reply':27,64 'retrieve':94 'right':68 's':25 'settings':110,126 'site':18,130 'so':43 'staff':9,132 'storing':11 'submit':62 't':21 'the':17,33,47,52,70,78,81,86,95,98,101,124,129 'this':1,29 'those':105 'to':8,28,37,65,76,80,89,97,114 'toolbar':49 'topic':5,30 'type':118 'upload':31,48 'uploaded':82 'uploads':119 'use':38,46 'used':15 'visible':6 'wish':36 'you':35,112 'your':63,73,91	This is a permanent topic visible only to staff for storing images and files used in the site design Don t delete it Here s how Reply to this topic Upload all the images you wish to use for logos favicons and so forth here Use the upload toolbar icon in the post editor or drag and drop or paste images Submit your reply to post it Right click the images in your new post to get the path to the uploaded images or click the edit icon to edit your post and retrieve the path to the images Copy the image paths Paste those image paths into basic settings If you need to enable different file type uploads edit authorized extensions in the file settings Assets for the site design Staff 	zh_CN
17	'00':14 '08':1639 '09':363 '1':39,624 '10':195 '11':9,1638 '14':11,1637 '141108':1634 '15':27 '18':13 '2':84,744 '2014':8,194,362 '3':313,882 '30':12 '34':184 '4':386,991 '5':36,610,1240 '6':619 '702':23 '8':10 'app':655,857,901,1029,1173,1270,1546 'apps':1093 'askforhelp':179 'blog':191,359 'bookfriend':839,844,1604 'books':1571 'bottle':1555 'cn':177 'com':141,1582,1595,1602,1609,1616,1623,1631 'cpyug':1632 'dm34':196 'gdg':353 'git':1539 'gitcafe':324,1589,1594,1601,1608,1615,1622 'greenteapress':1581 'gui':923,955 'guider':365 'happy':996 'happyhelp':1618 'helper':997 'housekeeper':629,1597 'how2ask':197 'http':139,173,190,358,1567,1579,1628 'https':1593,1600,1607,1614,1621 'issue':327 'jnu':1635 'km4gdg':364 'learnpythonthehardway':1572 'm':1243 'mailpop':887,1611 'markdown':137,142,1537 'me':1340 'moin':178 'mread':1245 'net':1569 'org':176,193,361 'paper':1570 'pdf':1585 'pop':1536 'pop3':906,918,931 'ppt':1262,1511 'ps':830,1327 'python':218,1560,1566,1578 'pythonicamp':1596,1603,1610,1617,1624,1633 'qiniudn':1630 'qpython':1549 'quick':749,834 'quiet':30 'review':462 'sebug':1568 'start':1636 'take':1339 'takemeup':1625 'thinkcspy':1584 'thinkpython':1583 'txt':1257 'ui':1368,1379,1387 'up':1341 'ux':1121 'w1':1164 'w2':1175 'w3':1184 'w4':1199 'w5':1206 'wiki':174,325,336 'wink':456,457 'woodpecker':175 'wowubuntu':140 'www':1580 'zhgdg':192,360 'zoom':29 'zoomq':1629 '一个':427,574,730,1226 '一些':62,160,636,804,1074 '一周':469,664,922,1058,1376,1504 '一定':149 '一是':1356 '一样':1576 '一次':395 '一生':576 '一直':1462 '一种':1439,1451 '一系列':1432 '一组':832,1329 '一起':117,1022 '三':563 '三大':322 '上':708,713,1100 '上周':463 '上手':1482 '上扬':283 '上述':87 '上面':1313 '下去':275 '下面':31 '不':229,649,1255 '不仅':1508 '不同':371,524 '不够':83,252 '不大':216 '不太':1102,1319 '不应':987 '不应该':704 '不懂':243 '不断':278,297 '不是':810,1324,1492 '不熟悉':80,203 '不能':1480 '不要':158 '不适应':652 '不需':1114 '与':71,96,127,622 '专业':46 '专注':1207 '且':1094 '世界':188,588 '世界上':1449 '业务':1127 '东':942 '东西':561 '严':681 '个':37 '个人':511 '中':333,1125 '中会':57 '中最':485 '中的':803 '为':973,1129,1457 '为人':1420 '主要':63,334 '之间':67,92 '乐':994,1612 '也':644,1159 '也不':697 '也可':1260 '也可以':1020,1515 '也是':583 '习惯':406,1435 '书':837,842,1562,1598 '书籍':855 '了':416,431,490,514,557,691,1431 '事儿':513 '事情':124,638,1007 '二':470,1361 '五':596 '产品':1117 '人':258,551,1009 '人之':1418 '人员':25 '人的':584,1352 '什么':1140 '介绍':332,621 '从':223 '从而':309 '仓库':1590 '代码':495,957 '以':335,729,767,894,971,1225,1452,1510 '以为':558 '以及':1527 '以看':1261 '任务':291,439,467,474,1130,1132,1134,1145,1193 '优先':769 '会':565 '会对':411 '但':806 '但是':958,1436 '体验':1123,1202 '何':683 '作品':35,625,745,840,883,992,1241,1330,1335,1499,1507 '你':305,554 '你们的':1116 '你就':272 '使用':376,723,1201,1219,1426,1487,1557 '信':725,1111,1221 '值得':1556 '做到':277,1496 '健':1285,1399 '像':1573 '元素':1052,1076 '克':1287,1401 '全':519 '全程':1413 '八十':953 '公众':731,1227 '公开':396,602 '共享':854 '关键':425,1118,1326 '关闭':1135 '兴趣':266 '其中':61,423 '其他':1051,1075 '其它':542,550 '其它的':983 '具体':607 '养成':405 '兼容':1203 '内务':641 '内容':1254 '再':1157 '几个':765 '出':1521 '出来':350,899 '出现':304 '函数':571 '分享':1142 '分头':522 '分工':521,656,782,862,908,1044,1275,1367 '切实':285,799 '列表':403 '则':1101 '创意':962,969 '到':287 '到底':312 '制作':665 '前':909 '办法':816,821,1564 '功能':706,740,863,936,980,985,1154,1236,1267,1318,1358,1370,1382,1391 '加':1073 '加些':1050 '加入':673,1070,1265 '动':1053 '动物':1423 '包含':489,1430 '区':21 '升级':1214 '半小时':615 '协议':907,917,928,948 '卓':1078 '南':17 '卢':938,1289,1403 '印证':499 '即':452 '厌烦':414 '原则':771 '原型':1174,1533 '去':1025 '去的':53 '参与':24 '参考':136,169,180,351 '友':838,843,1599 '反复强调':1407,1414 '发':1046,1062 '发布':1131,1194,1208 '发明':1425,1465 '发现问题':598 '取名':572 '只是':700 '只有':547 '只能':1489 '只要':234,267,965 '可':1170,1188 '可以':273,714,963,1107,1212,1500,1509 '可感知':1139 '可用':1138 '可直接':1250 '可能':951 '可行':504 '号的':732,1228 '吃饭':1023 '各':1587 '各种':1346 '各自':612 '合理':237,1486 '同一':224 '同学':543 '同时':47,417,643,1019 '同样':720,1151,1216 '同等':650 '名称':626,746,841,884,993,1242,1336 '后':409 '后台':726,1222 '后期':814 '向':400 '听书':1266 '呈现':340,898 '周':468,562,594,668,672,925,930,1061,1066,1384,1389 '周六':601 '周报':393,412 '周日':460 '和':42,207,586,1381,1538 '哪':506 '唯一':1450 '嘉':793,877 '四周':595,677,933,1072,1394 '回答':90 '回馈':1048,1067 '因为':217,366,1104 '因此':819 '团队':66,91,100,382,446 '图形':895 '在':51,144,298,328,528,705,711,756,1311 '在下':1463 '地':238,279,294,342,761,800 '地做':286 '地域':648 '地点':15 '坚持':274,311 '基础':76,199,206 '增长':434 '处理':634,707 '复杂':950 '多快好省':533 '多的':616 '大':698,1641 '大众':1106 '大妈':33,85,212,253,314,458,1406 '大学':18,802 '大家':222,755 '大量':737,1233,1531 '太多':231 '头脑':617 '好':367,1378 '好处':422 '如':1010 '如下':65 '如何':185 '如果':1091 '姓名':41 '婆':628,1592 '子':687 '存在':1438 '学':1565 '学习':1559 '学员':26,70,95,126,148,611 '学期':758 '学生':850 '学起':227 '它':271 '宇':685,940 '安排':639 '完全可以':699 '完善':1395 '完成':288,465,1185,1190,1196 '定义':1165 '实现':967,1360,1372,1386,1390 '实践':523 '实际':443,494 '实际上':1429 '实际问题':692 '实验':491 '客':748 '宿舍':635 '寄信':1018 '对':86,260,370,445,475,1477 '对于':204,1545,1550 '导师':28,72,97,247 '将':449 '小':935 '小工':1491 '小成':302 '小的':265 '尝试':964,1548 '就':103,303,310 '就不':410,509 '就会':306 '就可以':249 '就是':220,428,981,1259,1421 '就用':534 '就要':284 '尽量':154,1495 '展示':349 '工作':408,442,1434,1443 '工作量':743,1239 '工具':316,368,372,1408,1415,1427,1428,1440,1471,1479,1534,1544 '工程':695 '工程师':1493 '已':835,1038,1331 '希':1084 '帐户':1364 '帖':1047,1063 '帮':1011,1014,1017 '帮助':754,1002 '帮帮':995,1613 '常见':984 '平台':374 '平安':682 '并':599 '并不':1437 '并且':156,269 '应该':517,710,1411,1547 '廖':795,879 '建立':1209 '建议':459,722,1161,1218 '开':3,813,1644 '开发':320,484,693,742,989,1238,1305 '开始':226 '弄清楚':118 '式':977,1553 '张':686 '录音':1627 '形式':135,339,654,733,773,856,897,900,1028,1229,1269,1513,1519 '形成':430 '彩':659,674 '往后':329 '很':1325 '很多':420 '得':153,492 '得好':1306 '微':724,1110,1220 '心理':415 '必要':1320 '志愿':766,768 '快':747 '快递':1013 '快速':540,760,1213,1481 '怎么':545 '思想':585 '思考':1577 '情况':608,1205 '想':1473 '想法':502 '意外':1204 '感知':436 '慢慢':293 '成功':829,982 '成本':1180 '我吧':1334,1338,1620 '或':264 '或大':263 '或是':369 '所':43,464 '所以':228,507,1419,1472 '所在':1455 '所有':1442 '所需':1307 '手':1516 '手机':1293,1312 '才可':378 '才对':187 '才是':482,1147 '才能':498,552 '打':1015 '找不着':1351 '找人':1021 '承诺':448 '技术':776,858,902,1030,1095,1177,1271,1354 '把':113,280,343,715,1126 '折腾':546 '抢':762,807,827 '抽出':239 '担心':81,250 '拿':1012 '持续':380 '指南':357 '振':684 '换成':836,1332 '掌握':556,559,1542 '探索':1176 '接下':52 '接收':1133 '推荐':1558 '提供':734,1230 '提出':34 '提醒':657,670 '提问':88,165,170,186 '提高':381,1200 '操作':1524 '收发':916,927 '改为':1039 '改造':479 '放在':718,1097,1120 '放置':701 '效率':385,444 '教':22 '教会':549 '教授':541 '数据处理':712 '整体':866 '文档':326,337 '新':1478 '方便':852 '方案':526,1178 '方面':78,201,209 '无法':578 '无用':1160 '日报':398 '时':108,147,530,590 '时间':7,240,605,1004,1137,1143,1309 '明白':544 '明确':1166 '星':939 '是':110,518,1092,1141,1362,1448,1490 '是一':510 '是以':132 '是否':503,826 '是要':1540 '显':167 '晋':1290,1404 '智慧':172 '暂':678,783,787,860,871,1273,1276,1280 '暨':16,1640 '更':851 '更加':307 '更好':341 '最':424,1148 '最后':719 '最大':568 '最好':109,131,157 '最小':1181 '最有':968 '最终':527,823 '有':262,413,419,961,1005,1530 '有兴趣':268 '有帮助':189 '有趣':960 '有限':1301 '服务':727,735,779,1167,1223,1231,1554 '未定':679,784,788,861,872,1274,1277,1281 '本周':473 '本身':219 '机制':1211 '李':1080,1283,1397 '来':241,539,728,1224 '来到':255 '杨':1082 '构思':471,481,488 '查阅':979 '校':20 '校园':1347 '核心':592,1186 '根本':986 '格式':1258,1263 '框架':1380 '桌面':774 '楚':1088 '概述':6 '模块':1371,1392 '欣':794,878,945 '死力':1464 '段':910,944 '毅力':82,251 '每个':757 '每个人':121 '每周':119,394,1497 '每天':120,235,289,811 '每次':102 '比':1422 '比如':1502,1535 '比赛':1348 '比较':949 '永远':1488 '汤':1087 '沟通':69,74,94,99,107,112,130,384,589 '没有':815,820,1153 '泡':886,1606 '洁':1079 '活动':56,1647 '流程':38,390,1168,1187,1198 '测试':597,818 '消灭':1453 '涉及':905 '渠道':373 '游戏':1049 '湳':797,881 '漂亮':1158 '演示':397,603,604,786,870,920,1056,1171,1279,1374,1501,1505,1514,1520 '漫':1054 '潘':790,874 '激情':282 '炜':1291,1405 '点评':623,689,798,946,1090,1292 '热爱':270,308 '然后':292,536 '特别是':1444 '特定':1003,1006 '玩':1026 '现实':587,1103 '珠':181 '珠海':19,352 '琦':791,875 '琳':1086 '生活上':646 '用':1109 '用户':912,1122,1363 '用来':461 '由于':647 '界面':867,913,1033,1045,1059,1099,1156 '白':116 '百分之':952 '的':45,59,68,73,79,93,98,123,129,134,163,171,182,202,210,232,244,257,290,317,330,338,345,375,383,426,435,441,447,466,477,496,501,505,512,516,525,560,567,580,591,632,651,694,702,721,738,741,752,780,833,847,853,890,896,956,970,975,1000,1008,1035,1042,1069,1144,1150,1152,1155,1172,1182,1192,1197,1217,1234,1237,1248,1253,1294,1297,1308,1316,1322,1344,1359,1365,1409,1416,1459,1470,1506,1512,1518,1523,1532,1543,1561 '目前':1037 '目标':1458 '直接':1108 '相似':438 '省去':736,1232 '看到':295,300 '真实':1189 '真的':555 '真诚':168 '着':1485 '着手':1385 '矛盾':593 '知识':355 '知道':437 '社区':354 '科':1284,1398 '科学家':1575 '移动':1528 '程序':1034,1041 '程序员':575,1447,1461 '程序设计':865 '站':1552 '笨':1563 '第':663,676,921,932,1057,1071,1375,1393,1503 '第一':1136 '第三':671,929,1065,1388 '第二':667,924,1060,1383 '等':348,640,1027,1112,1264,1268 '简化':1128 '简单':162 '简称':32 '管家':627,1591 '管理':356,1366 '精确':451 '系统':809,1146,1215 '纪要':5,1646 '线索':974 '组':520,1333,1337,1349,1619 '组员':680,789,873,937,1077,1282,1396 '组团':613,1024 '终极':581 '经典':1191 '绘':1517 '给':570 '给出':404,1169 '编程':77,200,208,261,564 '编辑':1251 '网':1551 '老师':128 '而':125,1113 '而定':609 '而是':709 '而要':276 '聊天':976,1032,1098,1357 '肖':1286,1400 '能':379,548,759,966,1424,1466 '能力':433 '脑力':1468 '自个儿':440,500 '自动化':1469 '自助':778 '自学':242 '自己':49,296,472 '自己的':281,301 '自我介绍':40 '自然':429,515 '自白':183 '自身':432,1454 '节省时间':1467 '营':2,4,55,389,402,1643,1645 '蛋':660,675 '蛮':959 '蟒':1,54,388,1642 '蠎':401 '行业':1456,1460,1476 '表格':658,666,716 '要':166,630,750,845,888,904,998,1119,1246,1304,1342,1484,1494 '要做':122 '要命':1149 '要把':150 '要有':230 '要用':1115 '要素':323 '视':606 '解决':579,631,645,690,751,801,846,889,999,1247,1321,1343 '解决问题':600 '计划':392,662 '计算机':1445,1574 '认为':50,213,254,480 '认领':1195 '让':221,849,892 '讲明':115 '讲述':315,387 '设定':781,934,1036,1043,1064 '设置':669,764,1314 '设计':717,864,868,911,914,1369,1377 '证明':553,822 '话':114 '该是':988 '详细':155 '语法':138 '说出':48 '说是':1412 '请教':246 '读':44 '课':763,808,828 '谁':538 '谁的':532,535 '谱':454 '豪':688 '财务':637 '起来':455 '起点':225 '越来越':450 '软件':319,775,825,1296,1303,1522 '较长':1310 '辅助':739,1235 '辞行':1441 '过于':161 '过程':1124,1526 '过程中':321 '运算':1298 '运营':1210 '运行':497 '这':214,831,1328 '这一':1475 '这个':824 '这也':418 '这时':508 '这是':573 '这样':1105,1315 '这里':256 '进一步':478 '进入':407,1474 '进度':346 '进步':299 '进行':106,143,614,772,817,1525 '连带':421 '迭代':391,661,785,869,919,1055,1162,1278,1373 '选定':1179 '选课':770 '逐个':89 '通知':1040 '通讯录':972 '通过':493 '遇到':566 '那个':537 '那么':248 '那种':1183 '邮':885,1605 '邮件':133,893,915,926,947,978 '部分':487,1068 '郭':941 '都':236,399,577 '都会':812 '都是':259,954 '都有':1498 '配合':377 '重点':703,990,1541 '重要性':318,1410,1417 '重要的':486 '量':696 '量等':1299 '锐':943 '问':145,159 '问题':60,64,105,146,151,164,211,215,245,347,569,582,633,642,653,753,805,848,891,1001,1096,1249,1323,1345,1353 '间':101 '间里':531 '阅':1244 '阅读':1252,1295,1302,1317 '阐述':152 '队':1350 '附录':1586,1626 '限定':529,1256 '难题':777,859,903,1031,1272,1355 '雅':1083,1288,1402 '雯':1089 '零':75,198,205 '露':1081 '非常':1300 '靠':453 '面临':58 '面对面地':111 '项目':104,331,344,476,483,620,1588 '顺序':1163 '顾虑':233 '领域':1446,1529 '领悟':1483 '颖':796,880 '风暴':618 '饭':1016 '高':1085 '高效':1433 '黄':792,876	蟒 营 开 营 纪要 概述 时间 2014 11 8 14 30 18 00 地点 暨 南 大学 珠海 校 区 教 702 参与 人员 学员 15 导师 Zoom Quiet 下面 简称 大妈 提出 作品 5 个 流程 1 自我介绍 姓名 和 所 读 的 专业 同时 说出 自己 认为 在 接下 去的 蟒 营 活动 中会 面临 的 问题 其中 一些 主要 问题 如下 团队 之间 的 沟通 、 学员 与 导师 的 沟通 零 基础 编程 方面 的 不熟悉 担心 毅力 不够 2 大妈 对 上述 提问 逐个 回答 团队 之间 的 沟通 、 学员 与 导师 的 沟通 团队 间 每次 就 项目 问题 进行 沟通 时 最好 是 面对面地 沟通 把 话 讲明 白 一起 弄清楚 每周 、 每天 、 每个人 要做 的 事情 而 学员 与 老师 的 沟通 最好 是以 邮件 的 形式 参考 markdown 语法 http wowubuntu com markdown 进行 在 问 问题 时 学员 一定 要把 问题 阐述 得 尽量 详细 并且 最好 不要 问 一些 过于 简单 的 问题 提问 要 显 真诚 参考 提问 的 智慧 http wiki woodpecker org cn moin AskForHelp 参考 珠 的 自白 34 如何 提问 才对 世界 有帮助 http blog zhgdg org 2014 10 dm34 how2ask 零 基础 编程 方面 的 不熟悉 对于 零 基础 和 编程 方面 的 问题 ， 大妈 认为 这 问题 不大 因为 Python 本身 就是 让 大家 从 同一 起点 开始 学起 ， 所以 不 要有 太多 的 顾虑 ， 只要 每天 都 合理 地 抽出 时间 来 自学 ， 不懂 的 问题 请教 导师 ， 那么 就可以 担心 毅力 不够 大妈 认为 来到 这里 的 人 都是 对 编程 有 或大 或 小的 兴趣 只要 有兴趣 并且 热爱 它 你就 可以 坚持 下去 而要 做到 不断 地 把 自己的 激情 上扬 就要 切实 地做 到 完成 每天 的 任务 然后 慢慢 地 看到 自己 不断 在 进步 看到 自己的 小成 就 出现 你 就会 更加 热爱 从而 就 坚持 到底 3 大妈 讲述 工具 的 重要性 软件 开发 过程中 三大 要素 gitcafe 、 wiki 文档 、 issue 在 往后 的 项目 介绍 中 ， 主要 以 wiki 文档 的 形式 呈现 ， 更好 地 把 项目 的 进度 、 问题 等 展示 出来 参考 珠海 GDG 社区 知识 管理 指南 http blog zhgdg org 2014 09 km4gdg guider 因为 好 工具 或是 对 不同 工具 渠道 平台 的 使用 配合 才可 能 持续 提高 团队 的 沟通 效率 4 讲述 蟒 营 流程 迭代 计划 周报 每周 一次 公开 演示 日报 都 向 蠎 营 列表 给出 养成 习惯 进入 工作 后 就不 会对 周报 有 厌烦 心理 了 同时 这也 有 很多 连带 好处 其中 最 关键 的 一个 就是 自然 形成 了 自身 能力 增长 的 感知 知道 相似 任务 自个儿 的 工作 实际 效率 对 团队 的 承诺 将 越来越 精确 即 靠 谱 起来 wink wink 大妈 建议 周日 用来 review 上周 所 完成 的 任务 周 一周 二 构思 自己 本周 任务 、 对 项目 的 进一步 改造 认为 构思 才是 项目 开发 中最 重要的 部分 构思 包含 了 实验 得 通过 实际 代码 的 运行 才能 印证 自个儿 的 想法 是否 可行 的 哪 所以 这时 就不 是一 个人 的 事儿 了 自然 的 应该 是 全 组 分工 分头 实践 不同 的 方案 最终 在 限定 时 间里 谁的 多快好省 就用 谁的 然后 那个 谁 来 快速 教授 其它 同学 明白 怎么 折腾 只有 能 教会 其它 人 才能 证明 你 真的 掌握 了 以为 掌握 的 东西 周 三 编程 会 遇到 的 最大 问题 ： 给 函数 取名 这是 一个 程序员 一生 都 无法 解决 的 终极 问题 也是 人的 思想 和 现实 世界 沟通 时 的 核心 矛盾 周 四周 五 测试 发现问题 并 解决问题 周六 公开 演示 演示 时间 视 具体 情况 而定 5 学员 各自 组团 进行 半小时 多的 头脑 风暴 6 项目 介绍 与 点评 1 作品 名称 管家 婆 housekeeper 要 解决 的 问题 处理 宿舍 一些 财务 、 事情 安排 等 内务 问题 同时 也 解决 生活上 由于 地域 不 同等 的 不适应 问题 形式 ： app 分工 ： 提醒 表格 彩 蛋 迭代 计划 ： 第 一周 制作 表格 第二 周 设置 提醒 第三 周 加入 彩 蛋 第 四周 暂 未定 组员 严 平安 何 振 宇 张 子 豪 点评 解决 了 实际问题 开发 的 工程 量 也不 大 完全可以 只是 放置 的 重点 不应该 在 功能 处理 上 而是 应该 在 数据处理 上 可以 把 表格 设计 放在 最后 同样 的 建议 使用 微 信 后台 服务 来 以 一个 公众 号的 形式 提供 服务 省去 大量 的 辅助 功能 的 开发 工作量 2 作品 名称 快 客 Quick 要 解决 的 问题 帮助 大家 在 每个 学期 能 快速 地 抢 课 设置 几个 志愿 以 志愿 优先 选课 原则 进行 形式 桌面 软件 技术 难题 自助 服务 的 设定 分工 暂 未定 迭代 演示 暂 未定 组员 潘 琦 黄 嘉 欣 廖 颖 湳 点评 ： 切实 地 解决 大学 中的 一些 问题 但 抢 课 系统 不是 每天 都会 开 后期 没有 办法 进行 测试 因此 没有 办法 证明 最终 这个 软件 是否 抢 课 成功 PS 这 一组 的 Quick 已 换成 书 友 Bookfriend 作品 名称 书 友 Bookfriend 要 解决 的 问题 让 学生 更 方便 的 共享 书籍 形式 app 技术 难题 暂 未定 分工 功能 设计 、 程序设计 、 整体 界面 设计 迭代 演示 暂 未定 组员 潘 琦 黄 嘉 欣 廖 颖 湳 3 作品 名称 邮 泡 mailpop 要 解决 的 问题 让 邮件 以 图形 的 形式 呈现 出来 形式 app 技术 难题 ： 要 涉及 Pop3 协议 分工 前 段 设计 （ 用户 界面 设计 、 邮件 收发 协议 ） pop3 迭代 演示 ： 第 一周 GUI 第二 周 邮件 收发 协议 第三 周 pop3 第 四周 设定 小 功能 组员 ： 卢 星 宇 郭 东 锐 段 欣 点评 ： 邮件 协议 比较 复杂 可能 百分之 八十 都是 GUI 的 代码 但是 蛮 有趣 有 创意 可以 尝试 只要 能 实现 最有 创意 的 以 通讯录 为 线索 的 聊天 式 邮件 查阅 功能 就是 成功 其它的 常见 功能 根本 不应 该是 开发 重点 4 作品 名称 乐 帮帮 happy helper 要 解决 的 问题 帮助 特定 时间 有 特定 事情 的 人 如 帮 拿 快递 帮 打 饭 帮 寄信 同时 也可以 找人 一起 吃饭 组团 去 玩 等 形式 app 技术 难题 聊天 界面 程序 的 设定 （ 目前 已 改为 通知 程序 的 设定 ） 分工 ： 界面 发 帖 回馈 （ 游戏 ） 加些 其他 元素 （ 动 漫 ） 迭代 演示 ： 第 一周 界面 第二 周 发 帖 设定 第三 周 回馈 部分 的 加入 第 四周 加 一些 其他 元素 组员 ： 卓 洁 李 露 杨 雅 希 高 琳 汤 楚 雯 点评 ： 如果 是 apps 且 技术 问题 放在 聊天 界面 上 ， 则 不太 现实 ， 因为 这样 大众 可以 直接 用 微 信 等 而 不需 要用 你们的 产品 关键 要 放在 ux 用户 体验 过程 中 把 业务 简化 为 任务 发布 、 任务 接收 、 任务 关闭 。 第一 时间 可用 可感知 什么 是 分享 时间 的 任务 系统 才是 最 要命 的 同样 的 没有 功能 的 界面 再 漂亮 也 无用 建议 迭代 顺序 w1 定义 明确 服务 流程 给出 可 演示 的 app 原型 w2 探索 技术 方案 选定 成本 最小 的 那种 w3 完成 核心 流程 可 真实 完成 经典 的 任务 发布 认领 完成 的 流程 w4 提高 使用 体验 兼容 意外 情况 w5 专注 发布 建立 运营 机制 可以 快速 升级 系统 同样 的 建议 使用 微 信 后台 服务 来 以 一个 公众 号的 形式 提供 服务 省去 大量 的 辅助 功能 的 开发 工作量 5 作品 名称 m 阅 mread 要 解决 的 问题 可直接 编辑 阅读 的 内容 不 限定 txt 格式 就是 也可 以看 ppt 格式 等 加入 听书 功能 等 形式 app 技术 难题 暂 未定 分工 暂 未定 迭代 演示 暂 未定 组员 李 科 健 肖 克 雅 卢 晋 炜 点评 手机 的 阅读 软件 的 运算 量等 非常 有限 阅读 软件 要 开发 得好 所需 的 时间 较长 在 手机 上面 设置 这样 的 阅读 功能 不太 必要 解决 的 问题 不是 很 关键 PS 这 一组 作品 已 换成 组 我吧 作品 名称 ： 组 我吧 （ Take me up ） 要 解决 的 问题 各种 校园 比赛 组 队 找不着 人的 问题 。 技术 难题 一是 聊天 功能 的 实现 ， 二 是 用户 帐户 的 管理 分工 UI 设计 功能 模块 实现 迭代 演示 第 一周 设计 好 UI 框架 和 功能 第二 周 着手 实现 UI 第三 周 实现 功能 模块 第 四周 完善 组员 李 科 健 肖 克 雅 卢 晋 炜 大妈 反复强调 工具 的 重要性 应该 说是 全程 反复强调 工具 的 重要性 人之 所以 为人 就是 比 动物 能 发明 使用 工具 工具 实际上 包含 了 一系列 高效 工作 习惯 但是 并不 存在 一种 工具 辞行 所有 工作 特别是 计算机 领域 程序员 是 世界上 唯一 一种 以 消灭 自身 所在 行业 为 目标 的 行业 程序员 一直 在下 死力 发明 能 节省时间 脑力 自动化 的 工具 所以 想 进入 这一 行业 对 新 工具 不能 快速 上手 领悟 要 着 合理 使用 永远 只能 是 小工 不是 工程师 要 尽量 做到 每周 都有 作品 可以 演示 ， 比如 第 一周 演示 的 作品 不仅 可以 以 PPT 的 形式 演示 ， 也可以 手 绘 的 形式 演示 出 软件 的 操作 进行 过程 以及 移动 领域 有 大量 的 原型 工具 比如 POP markdown 和 git 是要 重点 掌握 的 工具 对于 app 应该 尝试 QPython 对于 网 站 式 服务 bottle 值得 使用 推荐 学习 Python 的 书 笨 办法 学 Python http sebug net paper books LearnPythonTheHardWay 像 计算机 科学家 一样 思考 Python http www greenteapress com thinkpython thinkCSpy pdf 附录 各 项目 gitcafe 仓库 管家 婆 https gitcafe com PythoniCamp housekeeper 书 友 https gitcafe com PythoniCamp Bookfriend 邮 泡 https gitcafe com PythoniCamp Mailpop 乐 帮帮 https gitcafe com PythoniCamp happyhelp 组 我吧 https gitcafe com PythoniCamp Takemeup 附录 录音 http zoomq qiniudn com CPyUG PythoniCamp 141108 jnu start 14 11 08 暨 大 蟒 营 开 营 纪要 活动 	zh_CN
18	'2014':7 'gdg':72 'jdc':1,4,25,29,35,66,90 'mm':32,83 'to':89 'uncategorized':91 'welcome':88 '一个':43 '一群':19 '为主':56 '主要':27,68 '也可以':48 '产品':59 '以及':14 '公司':12 '分':55 '分为':30 '分类':28 '区':18 '半年':9 '发起':50 '同学':23 '周':74,85 '和':34 '四个':62 '大':16 '学习':80 '完成':42 '小组':38,53 '工作':65 '带领':76 '年下':8 '当然':47 '形式':40 '成':5 '成员':33,36 '成立':3 '支持':13 '方面':63 '暨':15 '来':41 '每个':52 '汇报':86 '活动':69,81,87 '测试':58 '爱好':20 '特定':44 '现有':67 '珠':17 '珠海':71 '琦':75 '由':10,70 '的':2,22,26,39,45,64,77,84 '移动':11,31,82 '程':57 '立于':6 '组成':24 '编程':21 '美工':61 '自己':49 '营':79 '蟒':78 '设计':60 '负责人':73 '都':54 '都以':37 '项目':46,51	JDC 的 成立 JDC 成 立于 2014 年下 半年 由 移动 公司 支持 以及 暨 大 珠 区 一群 爱好 编程 的 同学 组成 JDC 的 主要 分类 JDC 分为 移动 MM 成员 和 JDC 成员 都以 小组 的 形式 来 完成 一个 特定 的 项目 当然 也可以 自己 发起 项目 每个 小组 都 分 为主 程 测试 产品 设计 美工 四个 方面 的 工作 JDC 现有 主要 活动 由 珠海 GDG 负责人 周 琦 带领 的 蟒 营 学习 活动 移动 MM 的 周 汇报 活动 Welcome to JDC Uncategorized 	zh_CN
20	'08':207,222 '1':311,460,526 '11':206,221 '14':205,220,223 '2':494,522,531 '2014':188 '3':306 '6':248 'code':238,240 'com':218,230,242,255,263,332,367,397,427,433,443,534 'dengzuoheng':330,395,444 'developer':217,364,431 'discourse':459,529 'doc':445 'dveloper':426 'gdg':194,257,260 'gitcafe':227,229 'github':442 'gmail':331,396 'google':237,241 'googlegroups':254,262,366,432 'http':215,527,532 'https':228,239,441 'jdc':32,33,45,131,446 'jnu':216,363,425,430 'kcpycamp':244 'ksc':43,47 'markdown':521 'markdown28':535 'meta':542 'mm':287 'org21':530 'p':243 'pythonicamp':231,232,246,253 'subscribe':365 't':219 'tm':247 'wiki':226,233,236,245 'wowubuntu':533 'www':528 'zhuhai':261 '一下':479 '一个':64 '一些':137 '一期':199 '一样':49 '一群':15 '一起':67,99 '下一代':456 '不':103 '不予':174 '不能':273 '不过':264 '与':46,192,281,467 '与你':98 '个':307,312,495 '中':116 '中国':282 '中的':128 '为':31 '主':321 '主题':496 '之前':476 '之外':278 '也':145 '也可':398 '了':197 '于':51 '产品':302,325 '仔细':157 '以及':483 '任何人':73,147 '会':121,135,501 '会员':404 '但是':152 '作为':290 '作品':334 '你':92,110,113 '你对':81 '信息':55 '俱乐部':42 '先':477 '先进':454 '关注':272 '其中':511 '具有':463 '内容':513,519 '出发':504 '出示':333 '列表':127,252,259,353,429,440 '删':180 '判断':163 '到':362 '前':155,493 '前身':35 '功能':466 '加入':75,274,341,356 '务必':413 '动弹':503 '区':452,486 '半年':190 '南':13,38 '即可':335,354,368 '参阅':204 '及时':375 '发':148,153,164,447,516 '发布':136 '发表':474,492,515 '发送':359 '只能':271 '只要':80 '只需':346 '可':203 '可以':93,111 '可发':379 '合作':195,284 '同时':144 '后再':514 '否则':418 '和':125,141,310 '回复':498 '团委':57 '团队':309,314 '困难':119 '在':87,105,490 '在于':62 '在校生':339 '在这里':130 '地址':417 '基地':289 '填写':414 '处理':123 '大':4,8,27,53,77,89,107,185,209,292,316,338,343,349,384,539 '大学':14,39 '大家':66 '如何':340 '如果':161,371 '子':296 '学习':114 '学生会':58 '学院':56 '孵化':288 '完成':369 '官方':434 '定期':122 '将':25,173 '崇尚':84 '已经':304 '希望':507 '帖':149,154,165,181,448,505,517 '常年':319 '平台':72,301 '年下':189 '库':436 '建议':471 '开':212 '开办':196 '开发':70,299,308 '开发者':5,9,28,78,90,108,186,293,317,344,350,385,540 '开源':20,85,438 '归路':104 '形式':268 '很多':464 '志同道合':95 '您':491,508 '您在':472 '情况':390 '意者':328 '感兴趣':83 '成为':402 '成功':421 '成立':285 '我们':23,59,120,134,191,279 '或':179,497 '所以':410,470 '托管':50 '找到':94 '技术':16,21,142,151,387,393 '折腾':68 '招收':320 '指导':506 '控制':524 '提供':63 '提出':112 '提问':129 '搭建':461 '支持':520 '文档':435 '文章':143 '新':465,468 '新的':198 '方式':358 '无法':419 '旨在':298 '时':412,499 '时期':48 '是':36 '是由':11 '暨':3,7,12,26,37,52,76,88,106,184,208,291,315,337,342,348,383,538 '更':374 '有':167,305,327 '朋友':97 '未':168 '本':400,450,484 '来到':2,537 '格式':525 '欢迎':1,146,536 '正式开始':473 '注册':399,405,411,420 '活动':138,377 '测试':323 '激活':409 '熟悉':478 '爱好者':17 '特性':469 '环境':482 '珠海':193,256 '电子邮件':408 '电气':54 '的':19,34,60,71,96,118,183,267,295,376,392,455,481,487,512,518 '目前':44,182,270,303,391 '目标':61 '直接':176 '相关':488 '真实':415 '社区':6,10,22,29,79,91,109,132,187,294,297,318,345,351,386,422,541 '禁':177 '私人':380 '移动':283,286,300 '程':322 '程序':458 '空':360 '简称':30 '管理员':162 '精神':86 '系统':500 '纪要':139,214 '组成':18 '编程':69,82,101,115 '置':159,170 '美术':313,324 '者':166 '而成':462 '联系':329 '自':502 '至':382 '获得':373 '营':201,211,213,225,235,250,266,277 '蟒':200,210,224,234,249,265,276 '要求':336 '视为':355 '言':178 '警告':175 '订阅':347,357,370 '认真':509 '讨论':150,451,485 '让':65 '论坛':124,133,401,403,424,457 '设计':326 '话题':475 '详情':202 '语法':523 '说明':389,489 '请':156 '负责人':388,394 '资源':423 '走上':100 '软件':41 '还':280 '这条':102 '这里':480 '迹象':172 '通常':24 '通知':140,378 '通过':407 '遇到':117 '邮件':126,251,258,352,361,381,416,428 '都可以':74 '采用':453 '金山':40 '阅读':158,169,510 '附':437 '限制':269 '除了':275 '需要':372,406 '顶':160 '顶的':171 '项目':439 '须知':449	欢迎 来到 暨 大 开发者 社区 暨 大 开发者 社区 是由 暨 南 大学 一群 技术 爱好者 组成 的 开源 技术 社区 我们 通常 将 暨 大 开发者 社区 简称 为 JDC JDC 的 前身 是 暨 南 大学 金山 软件 俱乐部 KSC 目前 JDC 与 KSC 时期 一样 托管 于 暨 大 电气 信息 学院 团委 学生会 我们 的 目标 在于 提供 一个 让 大家 一起 折腾 编程 开发 的 平台 任何人 都可以 加入 暨 大 开发者 社区 只要 你对 编程 感兴趣 崇尚 开源 精神 在 暨 大 开发者 社区 你 可以 找到 志同道合 的 朋友 与你 一起 走上 编程 这条 不 归路 在 暨 大 开发者 社区 你 可以 提出 你 学习 编程 中 遇到 的 困难 我们 会 定期 处理 论坛 和 邮件 列表 中的 提问 在这里 JDC 社区 论坛 我们 会 发布 一些 活动 纪要 通知 和 技术 文章 同时 也 欢迎 任何人 发 帖 讨论 技术 但是 发 帖 前 请 仔细 阅读 置 顶 如果 管理员 判断 发 帖 者 有 未 阅读 置 顶的 迹象 将 不予 警告 直接 禁 言 或 删 帖 目前 的 暨 大 开发者 社区 2014 年下 半年 我们 与 珠海 GDG 合作 开办 了 新的 一期 蟒 营 详情 可 参阅 14 11 08 暨 大 蟒 营 开 营 纪要 http jnu developer com t 14 11 08 14 蟒 营 wiki GitCafe https gitcafe com PythoniCamp PythoniCamp wiki 蟒 营 wiki Google Code https code google com p kcpycamp wiki PythoniCamp tm 6 蟒 营 邮件 列表 pythonicamp googlegroups com 珠海 GDG 邮件 列表 gdg zhuhai googlegroups com 不过 蟒 营 的 形式 限制 目前 只能 关注 不能 加入 除了 蟒 营 之外 我们 还 与 中国 移动 合作 成立 移动 MM 孵化 基地 作为 暨 大 开发者 社区 的 子 社区 旨在 开发 移动 平台 产品 目前 已经 有 3 个 开发 团队 和 1 个 美术 团队 暨 大 开发者 社区 常年 招收 主 程 测试 美术 产品 设计 有 意者 联系 dengzuoheng gmail com 出示 作品 即可 要求 暨 大 在校生 如何 加入 暨 大 开发者 社区 只需 订阅 暨 大 开发者 社区 邮件 列表 即可 视为 加入 订阅 方式 发送 空 邮件 到 jnu developer subscribe googlegroups com 即可 完成 订阅 如果 需要 获得 更 及时 的 活动 通知 可发 私人 邮件 至 暨 大 开发者 社区 技术 负责人 说明 情况 目前 的 技术 负责人 dengzuoheng gmail com 也可 注册 本 论坛 成为 论坛 会员 注册 需要 通过 电子邮件 激活 所以 注册 时 务必 填写 真实 邮件 地址 否则 无法 注册 成功 社区 资源 论坛 jnu dveloper com 邮件 列表 jnu developer googlegroups com 官方 文档 库 附 开源 项目 列表 https github com DengZuoheng doc jdc 发 帖 须知 本 讨论 区 采用 先进 的 下一代 论坛 程序 Discourse 1 搭建 而成 ， 具有 很多 新 功能 与 新 特性 ， 所以 建议 您在 正式开始 发表 话题 之前 ， 先 熟悉 一下 这里 的 环境 ， 以及 本 讨论 区 的 相关 说明 。 在 您 发表 前 2 个 主题 或 回复 时 ， 系统 会 自 动弹 出发 帖 指导 ， 希望 您 认真 阅读 其中 的 内容 后再 发表 。 发 帖 的 内容 支持 Markdown 2 语法 控制 格式 1 http www discourse org21 2 http wowubuntu com markdown28 欢迎 来到 暨 大 开发者 社区 Meta 	zh_CN
21	'meta':36 '主题':2 '全局':4 '分类':13 '取消':27 '可由':16 '在':10 '大':33 '始终':8 '它':11 '它将':7 '对':18 '已':3 '开发者':34 '或者':23 '所属':12 '所有人':19 '显示':9 '暨':32 '本':1 '来到':31 '欢迎':30 '用户':25 '由':24 '的':14 '社区':35 '置':5,21,28 '职员':17 '自己':26 '解除':20 '顶':6,22,29 '顶部':15	本 主题 已 全局 置 顶 ， 它将 始终 显示 在 它 所属 分类 的 顶部 。 可由 职员 对 所有人 解除 置 顶 ， 或者 由 用户 自己 取消 置 顶 。 欢迎 来到 暨 大 开发者 社区 Meta 	zh_CN
19	'11':53 '14':52 '30':54 'bian':30 'com':36,45 'dengzuoheng':46 'doc':47 'github':41,44 'https':43 'jdc':5,26,48 'logo':7,51,59 'master':50 'sina':35 'tree':49 'yinnjiuu':34 '两周':2 '务':62 '发布':10,60 '和':23,39 '图标':13,16,18 '地址':42 '地球':28 '地球仪':24 '大':12,56 '如下':11 '定稿':8 '实现':40 '将':27 '小':17 '开发者':57 '意在':25 '感谢':33 '搬':29 '是':20 '显示器':22 '暨':55 '构图':19 '现':9 '电脑':21,32 '的':3,6,37 '社区':58 '站':15,61 '经过':1 '网':14 '设计':4,38 '进':31	经过 两周 的 设计 JDC 的 logo 定稿 现 发布 如下 大 图标 网 站 图标 小 图标 构图 是 电脑 显示器 和 地球仪 意在 JDC 将 地球 搬 bian 进 电脑 感谢 yinnjiuu sina com 的 设计 和 实现 github 地址 https github com DengZuoheng doc jdc tree master logo 14 11 30 暨 大 开发者 社区 logo 发布 站 务 	zh_CN
22	'00':14,16 '1':39,182,183 '11':8,520 '14':519 '141116':516 '15':13 '16':10,521 '18':15 '2':74,362 '20':31 '3':197,251 '3669':181 '4':228,337 '409':25 '5':299,438 '6':483 'app':315,329 'bookfriend':419 'com':179,513 'cpyug':514 'happyhelper':298 'html':184 'http':176,510 'jnu':517 'mail':335 'me':360 'oyonyou':178 'pop':336 'python':270,321,326,346,355,391 'pythonicamp':515 'qiniudn':512 'quiet':34 'sae':366 'smart':445 'take':359 'thread':180 'token':383 'up':361 'vs':126,130,134 'w1':5,518,526 'web':398 'www':177 'xml':400 'zoom':33 'zoomq':511 '一':193 '一个':102 '一些':161 '一部分':341 '上周':213,238,253,258,301,309,339,347,364,380,420,427 '下午':12 '下周':55,225,245,276,324,352,389,432,502 '不做':189,191 '不好':222 '不知道':312 '不错':190 '不高':351 '两':77 '两方面':287 '为':458,492 '之间':146 '乐':296 '书':417 '了':62 '争取':327,409,448 '事项':49 '交出':328 '交流':160 '产品':50 '人':125,128,237,252,300,338,363 '人员':27 '什么':54,57,212,217,218,221,227,240,241,247,501,504 '介绍':47 '代码':342,457,491 '以':151 '以下':35 '仪':60 '任何':111 '任务':462 '但':87,97 '依据':460,496 '依照':285 '信':369,393 '信息':263 '修改':289 '做':56,194,211,216,246,500,503 '做了':53,239 '做得好':219 '做错':188 '公众':370,394 '公司':132 '内容':204,231 '再次':166 '写':437 '准备':98,105 '几':236 '出现':61 '分工':273,443 '分配':461,466 '创业':127 '初步':410 '功能':279,303,408,415,422 '加强':144 '加紧':320 '区':23 '南':19 '原则':446 '原型':343 '去做':288 '参':135 '参与':26,80 '参考':172 '友':418 '发':449 '发言':41,203 '变成':316 '只':101 '只要':283 '可验证':447 '台上':104 '号':371 '同学':471 '名称':51 '否则':142 '员工':139 '周报':435,499 '呼吁':67 '命令行':475 '和':122,423 '哪':234 '回复':405 '团队':141,145,442,497 '困难':244,506 '图书馆':472 '在':103,157,208 '在此之前':58 '地方':224 '地点':17 '坚持':441,444 '基本':95 '基础':476 '多做':187 '大妈':37,40,66,108,129,439,488 '大学':20 '大的':243 '如何':313 '婆':93,250 '存储':261 '存在':280 '学习':269,323,325,345,354,390 '学了':494 '学会':117,149,467 '学员':30,68,131,201 '完成':403,456 '完整':71 '完毕':107 '实现':277,411 '客观':459 '寻':468 '导师':32,470 '就':195 '工作':164 '已完成':254,302,340,365,421 '已经':387 '帮帮':297 '平台':395 '年会':133 '并':376 '开会':150 '开发':396 '开发者':378 '引发':65 '强调':167 '录音':509 '形式':112,156 '微':368,392 '思考':120 '性':290 '性格':464 '总结':440 '成功':96 '我':207,493 '我们':214 '我吧':82,358,373,413 '我是':205 '或':153 '所要':46 '把':314 '投入':451 '投影':59 '投资':124 '按':284 '换':118 '提出':110,489 '提示':286 '提问':168,173,484,487 '提高':163 '效率':165 '教':24 '教程':397 '数据库':477,480 '文':478 '文档':154,272 '方案':267,319 '方面':169,294 '无人':486 '无效':143 '无法':385 '日':11 '日报':450 '时间':7 '是什么':507 '是最':242 '智慧':175 '暂':430,433 '暨':18 '更易':455 '最大':259,310,348,381,428,505 '月':9 '有':220 '未':436 '未成功':91 '未知':431,434 '本周':43 '本当':479 '权限':292 '来':473 '校':22 '核心':414 '根据':463 '框架':399 '概述':6 '模型':331 '模式':379 '正式':229 '每个':200 '沟通':148 '泡':334 '活动':528 '流程':38 '消息':407 '清':233 '演示':4,45,75,99,114,230,525 '环节':485 '珠海':21 '用户':262,274,406 '由此':64,109 '申请':367 '界面':275,306,424 '略':481 '的':48,72,100,113,138,147,155,170,174,223,256,264,281,304,307,322,330,425,495 '相关':401 '知识':402 '确定':305,426 '积极性':350 '简称':36 '管家':92,249 '精力':452 '纪要':527 '组':78,81,209,215,235,357,372,412 '组员':158 '终会':192 '继续':268,353 '维系':140 '编辑':271 '网':88 '网络':85 '能力':465 '自动':404 '获得':70 '营':2,29,523 '蟒':1,28,522 '要':69,116 '要以':490 '要做':226 '要有':498 '角色':119 '解决':266,318,388 '解决问题':123,474 '让':453 '记':186 '记忆':278 '讲明':42 '设定':257 '设置':265,293 '设计':308,344 '访':198 '试图':83 '说':232 '请':136 '谁':52,206 '调试':76,94,106 '谈':199 '谨':185 '财务管理':255 '资源':137 '软件':317 '较弱':291 '过慢':90 '进行':79,86,202 '迭代':3,44,524 '途径':469 '通过':84,374,386 '通过了':377 '速':89 '邮':333 '邮件':152 '都可以':115 '里':210 '错':196 '问题':63,121,162,171,260,282,311,349,382,429 '间':159 '附录':508 '项目':248,295,332,356,416,454 '验证':375,384 '高等教育':73 '麻烦':482	蟒 营 迭代 演示 W1 概述 时间 ： 11 月 16 日 下午 15 00 18 00 地点 ： 暨 南 大学 珠海 校 区 教 409 参与 人员 ： 蟒 营 学员 ： 20 导师 ： Zoom Quiet 以下 简称 “ 大妈 ” 流程 1 大妈 发言 ， 讲明 本周 迭代 演示 所要 介绍 的 事项 产品 名称 谁 做了 什么 下周 做 什么 在此之前 ， 投影 仪 出现 了 问题 ， 由此 引发 大妈 呼吁 学员 要 获得 完整 的 高等教育 。 2 演示 调试 （ 两 组 进行 参与 ） 组 我吧 ： 试图 通过 网络 进行 但 网 速 过慢 未成功 管家 婆 ： 调试 基本 成功 。 （ 但 准备 演示 的 只 一个 在 台上 准备 ） 调试 完毕 ， 大妈 由此 提出 ： 任何 形式 的 演示 都可以 要 学会 换 角色 思考 问题 和 解决问题 投资 人 vs 创业 人 大妈 vs 学员 公司 年会 vs 参 请 资源 的 员工 维系 团队 ， 否则 无效 。 加强 团队 之间 的 沟通 ， 学会 开会 ， 以 邮件 或 文档 的 形式 在 组员 间 交流 一些 问题 ， 提高 工作 效率 再次 强调 提问 方面 的 问题 。 参考 《 提问 的 智慧 》 http www oyonyou com thread 3669 1 1 html 谨 记 ： 多做 做错 ， 不做 不错 ， 不做 终会 ， 一 做 就 错 3 访 谈 每个 学员 进行 发言 内容 ： 我是 谁 ？ 我 在 组 里 做 什么 ？ 上周 我们 组 做 什么 ？ 什么 做得好 ？ 有 什么 不好 的 地方 ？ 下周 要做 什么 ？ 4 正式 演示 内容 ： 说 清 哪 组 几 人 上周 做了 什么 什么 是最 大的 困难 下周 做 什么 项目 ： 管家 婆 （ 3 人 ） 上周 已完成 ： 财务管理 的 设定 上周 最大 问题 ： 存储 用户 信息 的 设置 解决 方案 ： 继续 学习 Python ， 编辑 文档 分工 ： 用户 界面 下周 ： 实现 记忆 功能 存在 的 问题 ： 只要 按 依照 、 提示 两方面 去做 修改 性 较弱 权限 设置 方面 项目 ： 乐 帮帮 happyhelper （ 5 人 ） 上周 已完成 功能 的 确定 、 界面 的 设计 上周 最大 问题 ： 不知道 如何 把 app 变成 软件 解决 方案 ： 加紧 Python 的 学习 下周 ： 学习 Python 、 争取 交出 app 的 模型 项目 ： 邮 泡 （ mail pop （ 4 人 ） 上周 已完成 ： 一部分 代码 、 原型 设计 、 学习 Python 上周 最大 问题 ： 积极性 不高 下周 ： 继续 学习 Python 项目 ： 组 我吧 （ Take me up ） （ 2 人 ） 上周 已完成 ： SAE 申请 ， 微 信 公众 号 “ 组 我吧 ” 通过 验证 ， 并 通过了 开发者 模式 上周 最大 问题 ： Token 验证 无法 通过 （ 已经 解决 ） 下周 ： 学习 Python 微 信 公众 平台 开发 教程 （ Web 框架 ， XML 相关 知识 ） 完成 自动 回复 用户 消息 功能 争取 初步 实现 “ 组 我吧 ” 核心 功能 项目 ： 书 友 （ bookfriend ） 上周 已完成 ： 功能 和 界面 的 确定 上周 最大 问题 ： 暂 未知 下周 ： 暂 未知 （ 周报 未 写 ） 5 大妈 总结 坚持 团队 分工 坚持 smart 原则 可验证 争取 发 日报 投入 精力 让 项目 更易 完成 代码 为 客观 依据 分配 任务 根据 性格 、 能力 分配 学会 寻 途径 导师 同学 图书馆 来 解决问题 命令行 、 基础 、 数据库 （ 文 本当 数据库 略 麻烦 ） 6 提问 环节 无人 提问 大妈 提出 要以 代码 为 我 学了 的 依据 团队 要有 周报 做 什么 、 下周 做 什么 、 最大 困难 是什么 附录 录音 http zoomq qiniudn com CPyUG PythoniCamp 141116 jnu w1 14 11 16 蟒 营 迭代 演示 w1 纪要 活动 	zh_CN
23	'00':14,42 '1':35,39 '10':31 '11':8,440 '14':439 '141101':432 '141122':434 '15':13,41,43,259,261,269 '17':15,271 '2':33,52,257 '22':10,441 '3':227,263 '30':16,272 '4':115,317 '40':44,260 '5':149 '50':262,270 '702':25 'cli':134 'com':429 'cpyug':430 'gui':129,136,251 'happyhelper':148 'html':438 'http':426 'index':437 'jnu':433,435 'mailpop':114 'me':50 'python':172 'pythonicamp':431 'qiniudn':428 'qq':292 'quiet':37 'take':49 'up':51 'w2':5,436,446 'zoom':36 'zoomq':427 '一个':307,421 '一周':178 '一定':175 '一组':46 '上':208 '上周':54,117,151,229 '下午':12 '下周':72,133,156,244 '下来':202 '不':290 '不一致':213 '不了':294 '不可能':184 '不同':206 '不祥':407 '不详':373,377,381,397,400,404 '与':135,265 '东':351 '严':361 '个':413 '为':298 '主要':282 '之间':137 '乐':146 '了':56,63,203 '事儿':95 '互':192 '互动':196 '交谈':268 '人':53,116,150,228 '人员':27 '什么':109 '代码':297 '以':306,332 '以上':181 '以及':128 '们':420 '任何':98 '休息':258 '伟':356,379 '何':370 '作到':108 '作品':105 '依据':300 '依旧':278 '信':58 '健':360 '共同':189 '关于':246 '关键':215 '再次':217 '分工':275 '到':174 '到底':106 '到达':339,367 '功能':71,80,127,162,182,234 '加强':195 '区':23 '卓':353 '南':19 '卢':343,394 '原因':330 '去使':285 '参与':26 '发布':157 '发送':124 '可用':308 '号':61 '同伴':419 '同学们':409 '同时':77 '吧':415 '呈现':336 '命令行':314 '响应':219 '哪':185,410,423 '嘉':325 '四组':224 '回家':393 '团队':274 '困难':82 '在':167,205 '地点':17 '坚持':273 '基本':70,126,131,161,183 '基础':315 '备注':337 '外出':389 '多个':74 '大妈':34,84,165,214,264,405 '大学':20 '大家':103 '大致':68 '婆':226 '子':375 '字典':236 '存储':239 '存在':280 '学习':190,245 '学会':284 '学员':30,266 '宇':345,372 '完成':73,118,180 '实体':310 '实现':164,230,238 '客观':299 '密码':242 '察看':142 '将会':331 '嵘':399 '工具':287 '希':384 '希望':304 '帐号':241 '帮助':102 '帮帮':147 '平安':362 '库':288 '应该':411 '廖':327 '开通':55 '式':220 '张':374 '当面':191 '录音':425 '形式':335 '得':417 '微':57 '怎么样':199 '情况':212 '想':107,179 '成员':168,321,341,369 '我吧':48 '所有':406 '手机':207 '振':371 '接收':121 '措施':198 '提升':171 '搜寻':231 '操作系统':311 '教':24,193 '数据库':255,316 '文':364 '新建':123 '方面':143,248 '旁听':32 '日':11 '时':177 '时候':303 '时间':7 '星':344 '是':279 '显示':155,209 '晋':395 '暨':18 '曾':398 '最大':81 '月':9 '有':342,385 '未':366 '本周':318 '本次':338 '李':348,358 '来':101,312 '杨':382,401 '杰':357,380 '林':355 '校':22 '根本':89 '框架':222 '楚':391 '概述':6 '欣':326,347 '段':346,363 '水平':176 '汤':390 '沟通':277 '没有':90,97,169 '泡':113 '注册':60,64,158 '洁':354 '活动':448 '流程':38 '涛':365 '湳':329 '演示':4,40,88,301,445 '潘':322 '炜':396 '点评':85,166 '现场':86,92,186 '珠海':21 '理解':104 '琦':323 '琳':388 '用':235,286 '用户':240 '界面':152,211 '登录':159 '的':59,69,76,94,120,130,138,153,163,188,197,200,210,249,281,302,309,320,334,340,368,408 '直觉':99 '科':359 '空口':96 '第':45,223 '第三':144 '第二':110 '等':67,125,160,243,252,296 '等等':194 '管家':225 '管理':237 '纪要':447 '组':47,111,145 '组团':66,79 '给':418 '给出':187,218 '统一':170 '编程':250 '缴费':232 '缺乏':276 '网络':93,247 '考虑到':91 '而':289 '肖':378 '能力':173 '能够':305 '至少':416 '营':2,29,443 '蟒':1,28,442 '补':412 '要用':291 '解决':293 '计划':201 '记录':233 '设置':62,154 '设计':132,221 '词':216 '说明':100,414 '说法':422 '读取':122 '课':386 '调试':83 '豪':376 '账号':65 '进行':78,313 '连接':139 '迭代':3,444 '退出':319 '邮':112 '邮件':119,141,333 '郭':350 '锐':352 '问题':87,253,256,283,295 '附录':424 '难题':140,204,254 '雅':383 '雯':392 '霏':403 '霖':402 '露':349 '面对面':267 '项目':75 '颖':328 '高':387 '黄':324	蟒 营 迭代 演示 W2 概述 时间 ： 11 月 22 日 下午 15 00 17 30 地点 ： 暨 南 大学 珠海 校 区 教 702 参与 人员 ： 蟒 营 学员 ： 10 旁听 2 大妈 1 Zoom Quiet 流程 1 演示 （ 15 00 15 40 ） 第 一组 组 我吧 Take me up 2 人 上周 开通 了 微 信 的 注册 号 设置 了 注册 账号 、 组团 等 大致 的 基本 功能 下周 ： 完成 多个 项目 的 同时 进行 组团 功能 最大 困难 调试 大妈 点评 现场 问题 演示 根本 没有 考虑到 现场 网络 的 事儿 空口 没有 任何 直觉 说明 来 帮助 大家 理解 作品 到底 想 作到 什么 第二 组 邮 泡 mailpop 4 人 上周 ： 完成 邮件 的 接收 ， 读取 ， 新建 ， 发送 等 基本 功能 ， 以及 GUI 的 基本 设计 下周 ： CLI 与 GUI 之间 的 连接 难题 ： 邮件 察看 方面 第三 组 ： 乐 帮帮 （ happyhelper ） 5 人 上周 ： 界面 的 设置 显示 下周 ： 发布 、 注册 、 登录 等 基本 功能 的 实现 大妈 点评 在 成员 没有 统一 提升 Python 能力 到 一定 水平 时 一周 想 完成 以上 功能 基本 不可能 哪 现场 给出 的 共同 学习 当面 互 教 等等 加强 互动 的 措施 怎么样 的 计划 下来 了 难题 ： 在 不同 手机 上 显示 的 界面 情况 不一致 大妈 关键 词 再次 给出 响应 式 设计 框架 第 四组 ： 管家 婆 3 人 上周 ： 实现 搜寻 缴费 记录 功能 ， 用 字典 管理 实现 存储 用户 帐号 密码 等 下周 ： 学习 关于 网络 方面 的 编程 、 GUI 等 问题 难题 ： 数据库 问题 2 休息 （ 15 40 15 50 ） 3 大妈 与 学员 面对面 交谈 （ 15 50 17 30 ） 坚持 团队 分工 缺乏 沟通 依旧 是 存在 的 主要 问题 学会 去使 用 工具 库 而 不 要用 QQ 解决 不了 问题 等 代码 为 客观 依据 演示 的 时候 希望 能够 以 一个 可用 的 实体 操作系统 来 进行 命令行 、 基础 、 数据库 4 本周 退出 的 成员 潘 琦 、 黄 嘉 欣 、 廖 颖 湳 原因 将会 以 邮件 的 形式 呈现 备注 本次 到达 的 成员 有 卢 星 宇 段 欣 李 露 郭 东 锐 卓 洁 林 伟 杰 李 科 健 严 平安 段 文 涛 未 到达 的 成员 何 振 宇 （ 不详 ） 张 子 豪 （ 不详 ） 肖 伟 杰 （ 不详 ） 杨 雅 希 （ 有 课 ） 高 琳 （ 外出 ） 汤 楚 雯 （ 回家 ） 卢 晋 炜 （ 不详 ） 曾 嵘 （ 不详 ） 杨 霖 霏 （ 不详 ） 大妈 所有 不祥 的 同学们 哪 应该 补 个 说明 吧 至少 得 给 同伴 们 一个 说法 哪 附录 录音 http zoomq qiniudn com CPyUG PythoniCamp 141101 jnu 141122 jnu w2 index html 14 11 22 蟒 营 迭代 演示 w2 纪要 活动 	zh_CN
24	'emoji':218 'end':121 'home':119 'smile':225 '一个':243,262,268,295,438,453 '一些':13 '一次':80 '一段时间':361 '一页':26 '上':117,325 '下':25 '下一个':74 '下方':383 '不用':308 '两天':339 '中':172,205,273 '为':165 '为什么':413 '主题':66,88,95,129,167,369,389 '之间':157 '也':272 '也可以':393 '了':12,359,429,452 '了解情况':258 '事':417 '交谈':278 '享受':477 '什么':174,228 '他人':311 '他们':275 '他们的':235 '以':249,260,380 '以在':270 '任何':65,182 '会':45,327,432,459 '会在':368 '传统':222 '但是':154 '你在':478 '使用':59,78,110,130,141,195,214,237,288,304 '保持':22,155 '信任':436,456 '先':219 '出现':299 '分享':261 '分类':396 '创建':355 '别人':231,315 '到':292 '功能':189 '加入':2 '加载':42 '包含':11 '原因':423 '参与':349,428,465 '另一个':152 '只要':426 '只需':33 '可以':14 '右上':60,302 '右下':104 '右侧':162 '合数':376 '名字':370 '后':43,69 '向下':36 '吧':482 '和':83,120,319 '哪一个':331 '哪儿':50 '喜欢':234 '回到':101 '回复':125,127,134,137,145,164,171,183,204,281,313,316,352 '因为':420 '图标':63 '在':49,93,169,300,323 '地':251 '大':4,486 '好好':476 '如果':147,240 '始终':470 '字':377 '它':305 '它们':44,253 '安全':422 '完成':210 '完整':111 '定义':408 '对话':341 '导入':199 '导向':151 '导航':112 '将':363,445 '将会':211,297 '小于':338 '工具栏':197 '帖子':41,77,84,99,140,143,161,186,194,236,244,263,269,283,286,318,382,403 '帮助':466 '并且':7,346,442 '底部':91 '开发者':5,487 '开始':18 '引导':71 '引用':173,177,192,200,274,284 '弹出':212 '当':39,92,279,314,450 '很长':360 '得到':433,460 '心':344 '快速':17 '怎么':124 '您':16,72,233,241,348,401,427 '您不':322 '您可':259,379 '您将':326,367,431,458 '您想':148 '您的':54,170,203,282,285,293,317,410 '情况':336 '想要':176 '感谢':1 '成为':437 '成员':441 '我':48,123 '我不':414 '我们':255,469 '我还':226 '或':90,221,357,406 '或使':114 '或者':28,57,254,287 '或者是':266 '户名':290 '所有':337,347 '技巧':20 '把':149 '担心':309 '指示':378 '按钮':27,64,135,146,184,190,201,239,248 '控制':113,385 '提到':206 '提及':291 '提示':21 '提醒':330 '搜索':52 '收到':328 '收藏':267 '改变':387,400 '数字':296 '数量':85 '整个':128,193 '文字':179,217 '文明':472 '新':333,375,418 '新的':40,407 '方向':153 '方式':405 '时':96,321 '时候':294 '时光':481 '时间':82 '是':332,343 '显示':47 '暨':3,485 '更多':32 '最下方':187 '最后':79 '最底下':132 '有':188 '有人':280 '有问题':245 '未读':75 '权力':463 '条':109 '来':464 '来到':484 '某些':416,421 '某人':207 '查看':306 '标准':215 '标记':247 '标题':67,100 '欢迎':8,483 '每一个':185,388,395 '没有':24 '活动':81 '滚动':23,37 '点击':68,98,103,181 '然后':180 '特定':138 '状态':392,398 '用':115,289 '用户':55,271,411,419 '的':19,62,76,106,118,133,139,144,158,163,178,198,256,264,312,340,345,350,354,356,362,374,384,390,397,404,435,440,455,462,473,480 '相信':471 '真正':439 '知道':232 '社会':474 '社区':6,488 '社群':434,467 '私下':250 '私信':10,320 '移':448 '立即':298 '站点':324 '符':224 '等级':457 '管理':468 '绘':216 '继续':35 '绿色':107 '编辑器':196 '职员':257 '联系':159 '联结':166 '能做':227,415 '自动':46,209,364,446 '至':73,87 '若想':168 '菜单':58 '蓝色':373 '行为':475 '表情':223 '被':365,424,447 '被认为':342 '要':30,34,51,126,136,191,213,229,399 '要在':202 '见到':372 '觉得':242 '角':61,105,303 '讨论':150,156,334,351,430 '让':15,230,252 '论坛':479 '设置':394,412 '访问':53 '详见':409 '请使用':160,246 '谁在':276 '赞':238 '足够':454,461 '跟我':277 '跟踪':402 '跳':86 '达到':451 '过':353 '这些':443 '这条':9 '进度':108 '追踪':366 '选择':175 '选项':386 '通知':307,391 '通过':97,381 '那个':142 '邮件':329 '都将':70 '链接':265 '错过':310 '键':122 '键入':208,220 '键盘':116 '阅读':31,94,358 '附近':371 '限制':425,444 '除':449 '页码':29 '页面':38,56,131,301 '顶部':89,102 '默认':335	感谢 加入 暨 大 开发者 社区 ， 并且 欢迎 ！ 这条 私信 包含 了 一些 可以 让 您 快速 开始 的 技巧 提示 ： 保持 滚动 没有 下 一页 按钮 或者 页码 — — 要 阅读 更多 ， 只需 要 继续 向下 滚动 页面 ！ 当 新的 帖子 加载 后 ， 它们 会 自动 显示 。 我 在 哪儿 ？ 要 搜索 ， 访问 您的 用户 页面 或者 菜单 ， 使用 右上 角 的 图标 ☰ 按钮 。 任何 主题 标题 点击 后 都将 引导 您 至 下一个 未读 的 帖子 。 使用 最后 一次 活动 时间 和 帖子 数量 跳 至 主题 顶部 或 底部 。 当 在 阅读 主题 时 ， 通过 点击 帖子 标题 回到 顶部 ↑ 。 点击 右下 角 的 绿色 进度 条 使用 完整 导航 控制 ， 或使 用 键盘 上 的 home 和 end 键 。 我 怎么 回复 ？ 要 回复 整个 主题 ， 使用 页面 最底下 的 回复 按钮 。 要 回复 特定 的 帖子 ， 使用 那个 帖子 的 回复 按钮 。 如果 您想 把 讨论 导向 另一个 方向 ， 但是 保持 讨论 之间 的 联系 ， 请使用 帖子 右侧 的 “ 回复 为 联结 主题 ” 。 若想 在 您的 回复 中 引用 什么 ， 选择 想要 引用 的 文字 ， 然后 点击 任何 回复 按钮 。 每一个 帖子 最下方 有 功能 按钮 。 （ 要 引用 整个 帖子 ， 使用 编辑器 工具栏 的 导入 引用 按钮 。 ） 要在 您的 回复 中 提到 某人 ， 键入 ， 自动 完成 将会 弹出 。 要 使用 标准 绘 文字 （ Emoji ） ， 先 键入 或 传统 表情 符 smile 我还 能做 什么 ？ 要 让 别人 知道 您 喜欢 他们的 帖子 ， 使用 赞 按钮 。 如果 您 觉得 一个 帖子 有问题 ， 请使用 标记 按钮 以 私下 地 让 它们 或者 我们 的 职员 了解情况 。 您可 以 分享 一个 帖子 的 链接 ， 或者是 收藏 一个 帖子 以在 用户 也 中 引用 他们 。 谁在 跟我 交谈 ？ 当 有人 回复 您的 帖子 ， 引用 您的 帖子 或者 使用 用 户名 提及 到 您的 时候 ， 一个 数字 将会 立即 出现 在 页面 右上 角 。 使用 它 查看 通知 。 不用 担心 错过 他人 的 回复 — — 当 别人 回复 您的 帖子 （ 和 私信 ） 时 您不 在 站点 上 ， 您将 会 收到 邮件 提醒 。 哪一个 是 新 讨论 ？ 默认 情况 ， 所有 小于 两天 的 对话 被认为 是 心 的 ， 并且 所有 您 参与 的 讨论 （ 回复 过 的 、 创建 的 或 阅读 了 很长 一段时间 的 ） 将 自动 被 追踪 。 您将 会在 主题 名字 附近 见到 蓝色 的 新 合数 字 指示 ： 您可 以 通过 帖子 下方 的 控制 选项 改变 每一个 主题 的 通知 状态 （ 也可以 设置 每一个 分类 的 状态 ） 。 要 改变 您 跟踪 帖子 的 方式 ， 或 新的 定义 ， 详见 您的 用户 设置 。 为什么 我不 能做 某些 事 ？ 新 用户 因为 某些 安全 原因 被 限制 。 只要 您 参与 了 讨论 ， 您将 会 得到 社群 的 信任 ， 成为 一个 真正 的 成员 ， 并且 这些 限制 将 自动 被 移 除 。 当 达到 了 一个 足够 的 信任 等级 ， 您将 会 得到 足够 的 权力 来 参与 帮助 社群 管理 。 我们 始终 相信 文明 的 社会 行为 。 好好 享受 你在 论坛 的 时光 吧 ！ 欢迎 来到 暨 大 开发者 社区 ！ 	zh_CN
\.


--
-- TOC entry 3147 (class 0 OID 16949)
-- Dependencies: 187
-- Data for Name: post_timings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_timings (topic_id, post_number, user_id, msecs) FROM stdin;
1	1	-1	5000
2	1	-1	5000
3	1	-1	5000
4	1	-1	5000
4	2	-1	5000
5	1	-1	5000
5	2	-1	5000
6	1	-1	5000
6	2	-1	5000
7	1	-1	5000
8	1	-1	5000
9	1	-1	5000
10	1	-1	5000
17	2	1	40060
8	1	1	970614
11	1	1	125692
17	1	1	263420
15	1	1	355157
14	1	1	114978
18	1	1	1038398
16	1	1	107526
19	1	1	134160
20	1	1	5000
13	1	1	130846
19	1	6	14038
\.


--
-- TOC entry 3211 (class 0 OID 18342)
-- Dependencies: 251
-- Data for Name: post_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_uploads (id, post_id, upload_id) FROM stdin;
4	19	4
5	19	5
6	19	6
\.


--
-- TOC entry 3396 (class 0 OID 0)
-- Dependencies: 250
-- Name: post_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_uploads_id_seq', 6, true);


--
-- TOC entry 3136 (class 0 OID 16742)
-- Dependencies: 176
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts (id, user_id, topic_id, post_number, raw, cooked, created_at, updated_at, reply_to_post_number, reply_count, quote_count, deleted_at, off_topic_count, like_count, incoming_link_count, bookmark_count, avg_time, score, reads, post_type, vote_count, sort_order, last_editor_id, hidden, hidden_reason_id, notify_moderators_count, spam_count, illegal_count, inappropriate_count, last_version_at, user_deleted, reply_to_user_id, percent_rank, notify_user_count, like_score, deleted_by_id, edit_reason, word_count, version, cook_method, wiki, baked_at, baked_version, hidden_at, self_edits, reply_quoted, via_email, raw_email, public_version) FROM stdin;
1	-1	1	1	A category exclusive to members with trust level 3 and higher.	<p>A category exclusive to members with trust level 3 and higher.</p>	2014-11-01 07:31:03.483706	2014-11-01 07:31:03.483706	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:03.613868	f	\N	0	0	0	\N	\N	11	1	1	f	2014-11-01 07:31:03.48354	1	\N	0	f	f	\N	1
3	-1	3	1	Private category for staff discussions. Topics are only visible to admins and moderators.	<p>Private category for staff discussions. Topics are only visible to admins and moderators.</p>	2014-11-01 07:31:04.08238	2014-11-01 07:31:04.08238	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:04.086055	f	\N	0	0	0	\N	\N	13	1	1	f	2014-11-01 07:31:04.082263	1	\N	0	f	f	\N	1
11	-1	8	1	The first paragraph of this pinned topic will be visible as a welcome message to all new visitors on your homepage. It's important!\n\n**Edit this** into a brief description of your community:\n\n- Who is it for?\n- What can they find here?\n- Why should they come here?\n- Where can they read more (links, resources, etc)?\n\nYou may want to close this topic via the admin wrench (at the upper right and bottom), so that replies don't pile up on an announcement.	<p>The first paragraph of this pinned topic will be visible as a welcome message to all new visitors on your homepage. It's important!</p>\n\n<p><strong>Edit this</strong> into a brief description of your community:</p>\n\n<ul>\n<li>Who is it for?</li>\n<li>What can they find here?</li>\n<li>Why should they come here?</li>\n<li>Where can they read more (links, resources, etc)?</li>\n</ul>\n\n<p>You may want to close this topic via the admin wrench (at the upper right and bottom), so that replies don't pile up on an announcement.</p>	2014-11-01 07:31:05.967307	2014-11-01 07:31:05.967307	\N	0	0	2014-11-30 14:42:50.963922	0	0	0	0	971	48.9500000000000028	2	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.972312	f	\N	0	0	0	1	\N	82	1	1	f	2014-11-01 07:31:05.967209	1	\N	0	f	f	\N	1
2	-1	2	1	Discussion about this site, its organization, how it works, and how we can improve it.	<p>Discussion about this site, its organization, how it works, and how we can improve it.</p>	2014-11-01 07:31:03.770675	2014-11-01 07:31:03.770675	\N	0	0	\N	0	0	2	0	\N	10.1999999999999993	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:03.775716	f	\N	0	0	0	\N	\N	15	1	1	f	2014-11-01 07:31:03.770518	1	\N	0	f	f	\N	1
5	-1	4	2	Edit the first post in this topic to change the contents of the Terms of Service page.	<p>Edit the first post in this topic to change the contents of the Terms of Service page.</p>	2014-11-01 07:31:05.006787	2014-11-01 07:31:05.006787	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	2	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.014685	f	\N	0	0	0	\N	\N	17	1	1	f	2014-11-01 07:31:05.006689	1	\N	0	f	f	\N	1
7	-1	5	2	Edit the first post in this topic to change the contents of the FAQ/Guidelines page.	<p>Edit the first post in this topic to change the contents of the FAQ/Guidelines page.</p>	2014-11-01 07:31:05.501277	2014-11-01 07:31:05.501277	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	2	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.507246	f	\N	0	0	0	\N	\N	16	1	1	f	2014-11-01 07:31:05.501164	1	\N	0	f	f	\N	1
9	-1	6	2	Edit the first post in this topic to change the contents of the Privacy Policy page.	<p>Edit the first post in this topic to change the contents of the Privacy Policy page.</p>	2014-11-01 07:31:05.775228	2014-11-01 07:31:05.775228	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	2	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.780853	f	\N	0	0	0	\N	\N	16	1	1	f	2014-11-01 07:31:05.775116	1	\N	0	f	f	\N	1
6	-1	5	1	<a name="civilized"></a>\n\n## [This is a Civilized Place for Public Discussion](#civilized)\n\nPlease treat this discussion forum with the same respect you would a public park.  We, too, are a shared community resource &mdash; a place to share skills, knowledge and interests through ongoing conversation.\n\nThese are not hard and fast rules, merely aids to the human judgment of our community. Use these guidelines to keep this a clean, well-lighted place for civilized public discourse.\n\n<a name="improve"></a>\n\n## [Improve the Discussion](#improve)\n\nHelp us make this a great place for discussion by always working to improve the discussion in some way, however small. If you are not sure your post adds to the conversation, think over what you want to say and try again later.\n\nThe topics discussed here matter to us, and we want you to act as if they matter to you, too. Be respectful of the topics and the people discussing them, even if you disagree with some of what is being said.\n\nOne way to improve the discussion is by discovering ones that are already happening. Please spend some time browsing the topics here before replying or starting your own, and you’ll have a better chance of meeting others who share your interests.\n\n<a name="agreeable"></a>\n\n## [Be Agreeable, Even When You Disagree](#agreeable)\n\nYou may wish to respond to something by disagreeing with it. That’s fine. But, remember to _criticize ideas, not people_. Please avoid:\n\n*   Name-calling.\n*   Ad hominem attacks.\n*   Responding to a post’s tone instead of its actual content.\n*   Knee-jerk contradiction.\n\nInstead, provide reasoned counter-arguments that improve the conversation.\n\n<a name="participate"></a>\n\n## [Your Participation Counts](#participate)\n\nThe conversations we have here set the tone for everyone. Help us influence the future of this community by choosing to engage in discussions that make this forum an interesting place to be &mdash; and avoiding those that do not.\n\nDiscourse provides tools that enable the community to collectively identify the best (and worst) contributions: favorites, bookmarks, likes, flags, replies, edits, and so forth. Use these tools to improve your own experience, and everyone else’s, too.\n\nLet’s try to leave our park better than we found it.\n\n<a name="flag-problems"></a>\n\n## [If You See a Problem, Flag It](#flag-problems)\n\nModerators have special authority; they are responsible for this forum. But so are you. With your help, moderators can be community facilitators, not just janitors or police.\n\nWhen you see bad behavior, don’t reply. It encourages the bad behavior by acknowledging it, consumes your energy, and wastes everyone’s time. _Just flag it_. If enough flags accrue, action will be taken, either automatically or by moderator intervention.\n\nIn order to maintain our community, moderators reserve the right to remove any content and any user account for any reason at any time. Moderators do not preview new posts in any way; the moderators and site operators take no responsibility for any content posted by the community.\n\n<a name="be-civil"></a>\n\n## [Always Be Civil](#be-civil)\n\nNothing sabotages a healthy conversation like rudeness:\n\n*   Be civil. Don’t post anything that a reasonable person would consider offensive, abusive, or hate speech.\n*   Keep it clean. Don’t post anything obscene or sexually explicit.\n*   Respect each other. Don’t harass or grief anyone, impersonate people, or expose their private information.\n*   Respect our forum. Don’t post spam or otherwise vandalize the forum.\n\nThese are not concrete terms with precise definitions &mdash; avoid even the _appearance_ of any of these things. If you’re unsure, ask yourself how you would feel if your post was featured on the front page of the New York Times.\n\nThis is a public forum, and search engines index these discussions. Keep the language, links, and images safe for family and friends.\n\n<a name="keep-tidy"></a>\n\n## [Keep It Tidy](#keep-tidy)\n\nMake the effort to put things in the right place, so that we can spend more time discussing and less cleaning up. So:\n\n*   Don’t start a topic in the wrong category.\n*   Don’t cross-post the same thing in multiple topics.\n*   Don’t post no-content replies.\n*   Don’t divert a topic by changing it midstream.\n*   Don’t sign your posts &mdash; every post has your profile information attached to it.\n\nRather than posting “+1” or “Agreed”, use the Like button. Rather than taking an existing topic in a radically different direction, use Reply as a New Topic.\n\n<a name="stealing"></a>\n\n## [Post Only Your Own Stuff](#stealing)\n\nYou may not post anything digital that belongs to someone else without permission. You may not post descriptions of, links to, or methods for stealing someone’s intellectual property (software, video, audio, images), or for breaking any other law.\n\n<a name="tos"></a>\n\n## [Terms of Service](#tos)\n\nYes, legalese is boring, but we must protect ourselves &ndash; and by extension, you and your data &ndash; against unfriendly folks. We have a [Terms of Service](/tos) describing your (and our) behavior and rights related to content, privacy, and laws. To use this service, you must agree to abide by our [TOS](/tos).	<p><a name="civilized"></a></p>\n\n<h2><a href="#civilized">This is a Civilized Place for Public Discussion</a></h2>\n\n<p>Please treat this discussion forum with the same respect you would a public park.  We, too, are a shared community resource — a place to share skills, knowledge and interests through ongoing conversation.</p>\n\n<p>These are not hard and fast rules, merely aids to the human judgment of our community. Use these guidelines to keep this a clean, well-lighted place for civilized public discourse.</p>\n\n<p><a name="improve"></a></p>\n\n<h2><a href="#improve">Improve the Discussion</a></h2>\n\n<p>Help us make this a great place for discussion by always working to improve the discussion in some way, however small. If you are not sure your post adds to the conversation, think over what you want to say and try again later.</p>\n\n<p>The topics discussed here matter to us, and we want you to act as if they matter to you, too. Be respectful of the topics and the people discussing them, even if you disagree with some of what is being said.</p>\n\n<p>One way to improve the discussion is by discovering ones that are already happening. Please spend some time browsing the topics here before replying or starting your own, and you’ll have a better chance of meeting others who share your interests.</p>\n\n<p><a name="agreeable"></a></p>\n\n<h2><a href="#agreeable">Be Agreeable, Even When You Disagree</a></h2>\n\n<p>You may wish to respond to something by disagreeing with it. That’s fine. But, remember to <em>criticize ideas, not people</em>. Please avoid:</p>\n\n<ul>\n<li>Name-calling.</li>\n<li>Ad hominem attacks.</li>\n<li>Responding to a post’s tone instead of its actual content.</li>\n<li>Knee-jerk contradiction.</li>\n</ul>\n\n<p>Instead, provide reasoned counter-arguments that improve the conversation.</p>\n\n<p><a name="participate"></a></p>\n\n<h2><a href="#participate">Your Participation Counts</a></h2>\n\n<p>The conversations we have here set the tone for everyone. Help us influence the future of this community by choosing to engage in discussions that make this forum an interesting place to be — and avoiding those that do not.</p>\n\n<p>Discourse provides tools that enable the community to collectively identify the best (and worst) contributions: favorites, bookmarks, likes, flags, replies, edits, and so forth. Use these tools to improve your own experience, and everyone else’s, too.</p>\n\n<p>Let’s try to leave our park better than we found it.</p>\n\n<p><a name="flag-problems"></a></p>\n\n<h2><a href="#flag-problems">If You See a Problem, Flag It</a></h2>\n\n<p>Moderators have special authority; they are responsible for this forum. But so are you. With your help, moderators can be community facilitators, not just janitors or police.</p>\n\n<p>When you see bad behavior, don’t reply. It encourages the bad behavior by acknowledging it, consumes your energy, and wastes everyone’s time. <em>Just flag it</em>. If enough flags accrue, action will be taken, either automatically or by moderator intervention.</p>\n\n<p>In order to maintain our community, moderators reserve the right to remove any content and any user account for any reason at any time. Moderators do not preview new posts in any way; the moderators and site operators take no responsibility for any content posted by the community.</p>\n\n<p><a name="be-civil"></a></p>\n\n<h2><a href="#be-civil">Always Be Civil</a></h2>\n\n<p>Nothing sabotages a healthy conversation like rudeness:</p>\n\n<ul>\n<li>Be civil. Don’t post anything that a reasonable person would consider offensive, abusive, or hate speech.</li>\n<li>Keep it clean. Don’t post anything obscene or sexually explicit.</li>\n<li>Respect each other. Don’t harass or grief anyone, impersonate people, or expose their private information.</li>\n<li>Respect our forum. Don’t post spam or otherwise vandalize the forum.</li>\n</ul>\n\n<p>These are not concrete terms with precise definitions — avoid even the <em>appearance</em> of any of these things. If you’re unsure, ask yourself how you would feel if your post was featured on the front page of the New York Times.</p>\n\n<p>This is a public forum, and search engines index these discussions. Keep the language, links, and images safe for family and friends.</p>\n\n<p><a name="keep-tidy"></a></p>\n\n<h2><a href="#keep-tidy">Keep It Tidy</a></h2>\n\n<p>Make the effort to put things in the right place, so that we can spend more time discussing and less cleaning up. So:</p>\n\n<ul>\n<li>Don’t start a topic in the wrong category.</li>\n<li>Don’t cross-post the same thing in multiple topics.</li>\n<li>Don’t post no-content replies.</li>\n<li>Don’t divert a topic by changing it midstream.</li>\n<li>Don’t sign your posts — every post has your profile information attached to it.</li>\n</ul>\n\n<p>Rather than posting “+1” or “Agreed”, use the Like button. Rather than taking an existing topic in a radically different direction, use Reply as a New Topic.</p>\n\n<p><a name="stealing"></a></p>\n\n<h2><a href="#stealing">Post Only Your Own Stuff</a></h2>\n\n<p>You may not post anything digital that belongs to someone else without permission. You may not post descriptions of, links to, or methods for stealing someone’s intellectual property (software, video, audio, images), or for breaking any other law.</p>\n\n<p><a name="tos"></a></p>\n\n<h2><a href="#tos">Terms of Service</a></h2>\n\n<p>Yes, legalese is boring, but we must protect ourselves – and by extension, you and your data – against unfriendly folks. We have a <a href="/tos">Terms of Service</a> describing your (and our) behavior and rights related to content, privacy, and laws. To use this service, you must agree to abide by our <a href="/tos">TOS</a>.</p>	2014-11-01 07:31:05.127737	2014-11-01 07:31:05.127737	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.141012	f	\N	0	0	0	\N	\N	857	1	1	f	2014-11-01 07:31:05.12763	1	\N	0	f	f	\N	1
8	-1	6	1	<a name="collect"></a>\n\n## [What information do we collect?](#collect)\n\nWe collect information from you when you register on our site and gather data when you participate in the forum by reading, writing, and evaluating the content shared here.\n\nWhen registering on our site, you may be asked to enter your name and e-mail address. You may, however, visit our site without registering. Your e-mail address will be verified by an email containing a unique link. If that link is visited, we know that you control the e-mail address.\n\nWhen registered and posting, we record the IP address that the post originated from. We also may retain server logs which include the IP address of every request to our server.\n\n<a name="use"></a>\n\n## [What do we use your information for?](#use)\n\nAny of the information we collect from you may be used in one of the following ways:\n\n*   To personalize your experience &mdash; your information helps us to better respond to your individual needs.\n*   To improve our site &mdash; we continually strive to improve our site offerings based on the information and feedback we receive from you.\n*   To improve customer service &mdash; your information helps us to more effectively respond to your customer service requests and support needs.\n*   To send periodic emails &mdash; The email address you provide may be used to send you information, notifications that you request about changes to topics or in response to your user name, respond to inquiries, and/or other requests or questions.\n\n<a name="protect"></a>\n\n## [How do we protect your information?](#protect)\n\nWe implement a variety of security measures to maintain the safety of your personal information when you enter, submit, or access your personal information.\n\n<a name="data-retention"></a>\n\n## [What is your data retention policy?](#data-retention)\n\nWe will make a good faith effort to:\n\n*   Retain server logs containing the IP address of all requests to this server no more than 90 days.\n*   Retain the IP addresses associated with registered users and their posts no more than 5 years.\n\n<a name="cookies"></a>\n\n## [Do we use cookies?](#cookies)\n\nYes. Cookies are small files that a site or its service provider transfers to your computer's hard drive through your Web browser (if you allow). These cookies enable the site to recognize your browser and, if you have a registered account, associate it with your registered account.\n\nWe use cookies to understand and save your preferences for future visits and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\n\n<a name="disclose"></a>\n\n## [Do we disclose any information to outside parties?](#disclose)\n\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our site, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\n\n<a name="third-party"></a>\n\n## [Third party links](#third-party)\n\nOccasionally, at our discretion, we may include or offer third party products or services on our site. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\n\n<a name="coppa"></a>\n\n## [Children's Online Privacy Protection Act Compliance](#coppa)\n\nOur site, products and services are all directed to people who are at least 13 years old or older. If this server is in the USA, and you are under the age of 13, per the requirements of COPPA ([Children's Online Privacy Protection Act](http://en.wikipedia.org/wiki/Children)), do not use this site.\n\n<a name="online"></a>\n\n## [Online Privacy Policy Only](#online)\n\nThis online privacy policy applies only to information collected through our site and not to information collected offline.\n\n<a name="consent"></a>\n\n## [Your Consent](#consent)\n\nBy using our site, you consent to our web site privacy policy.\n\n<a name="changes"></a>\n\n## [Changes to our Privacy Policy](#changes)\n\nIf we decide to change our privacy policy, we will post those changes on this page.\n\nThis document is CC-BY-SA. It was last updated May 31, 2013.	<p><a name="collect"></a></p>\n\n<h2><a href="#collect">What information do we collect?</a></h2>\n\n<p>We collect information from you when you register on our site and gather data when you participate in the forum by reading, writing, and evaluating the content shared here.</p>\n\n<p>When registering on our site, you may be asked to enter your name and e-mail address. You may, however, visit our site without registering. Your e-mail address will be verified by an email containing a unique link. If that link is visited, we know that you control the e-mail address.</p>\n\n<p>When registered and posting, we record the IP address that the post originated from. We also may retain server logs which include the IP address of every request to our server.</p>\n\n<p><a name="use"></a></p>\n\n<h2><a href="#use">What do we use your information for?</a></h2>\n\n<p>Any of the information we collect from you may be used in one of the following ways:</p>\n\n<ul>\n<li>To personalize your experience — your information helps us to better respond to your individual needs.</li>\n<li>To improve our site — we continually strive to improve our site offerings based on the information and feedback we receive from you.</li>\n<li>To improve customer service — your information helps us to more effectively respond to your customer service requests and support needs.</li>\n<li>To send periodic emails — The email address you provide may be used to send you information, notifications that you request about changes to topics or in response to your user name, respond to inquiries, and/or other requests or questions.</li>\n</ul>\n\n<p><a name="protect"></a></p>\n\n<h2><a href="#protect">How do we protect your information?</a></h2>\n\n<p>We implement a variety of security measures to maintain the safety of your personal information when you enter, submit, or access your personal information.</p>\n\n<p><a name="data-retention"></a></p>\n\n<h2><a href="#data-retention">What is your data retention policy?</a></h2>\n\n<p>We will make a good faith effort to:</p>\n\n<ul>\n<li>Retain server logs containing the IP address of all requests to this server no more than 90 days.</li>\n<li>Retain the IP addresses associated with registered users and their posts no more than 5 years.</li>\n</ul>\n\n<p><a name="cookies"></a></p>\n\n<h2><a href="#cookies">Do we use cookies?</a></h2>\n\n<p>Yes. Cookies are small files that a site or its service provider transfers to your computer's hard drive through your Web browser (if you allow). These cookies enable the site to recognize your browser and, if you have a registered account, associate it with your registered account.</p>\n\n<p>We use cookies to understand and save your preferences for future visits and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.</p>\n\n<p><a name="disclose"></a></p>\n\n<h2><a href="#disclose">Do we disclose any information to outside parties?</a></h2>\n\n<p>We do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our site, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.</p>\n\n<p><a name="third-party"></a></p>\n\n<h2><a href="#third-party">Third party links</a></h2>\n\n<p>Occasionally, at our discretion, we may include or offer third party products or services on our site. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.</p>\n\n<p><a name="coppa"></a></p>\n\n<h2><a href="#coppa">Children's Online Privacy Protection Act Compliance</a></h2>\n\n<p>Our site, products and services are all directed to people who are at least 13 years old or older. If this server is in the USA, and you are under the age of 13, per the requirements of COPPA (<a href="http://en.wikipedia.org/wiki/Children">Children's Online Privacy Protection Act</a>), do not use this site.</p>\n\n<p><a name="online"></a></p>\n\n<h2><a href="#online">Online Privacy Policy Only</a></h2>\n\n<p>This online privacy policy applies only to information collected through our site and not to information collected offline.</p>\n\n<p><a name="consent"></a></p>\n\n<h2><a href="#consent">Your Consent</a></h2>\n\n<p>By using our site, you consent to our web site privacy policy.</p>\n\n<p><a name="changes"></a></p>\n\n<h2><a href="#changes">Changes to our Privacy Policy</a></h2>\n\n<p>If we decide to change our privacy policy, we will post those changes on this page.</p>\n\n<p>This document is CC-BY-SA. It was last updated May 31, 2013.</p>	2014-11-01 07:31:05.598248	2014-11-01 07:31:05.598248	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.610033	f	\N	0	0	0	\N	\N	805	1	1	f	2014-11-01 07:31:05.598145	1	\N	0	f	f	\N	1
4	-1	4	1	The following terms and conditions govern all use of the www.example.com website and all content, services and products available at or through the website, including, but not limited to, www.example.com Forum Software, www.example.com Support Forums and the www.example.com Hosting service ("Hosting"), (taken together, the Website). The Website is owned and operated by My Unconfigured Forum Ltd. ("Unconfigured Forum"). The Website is offered subject to your acceptance without modification of all of the terms and conditions contained herein and all other operating rules, policies (including, without limitation, www.example.com’s [Privacy Policy](/privacy) and [Community Guidelines](/faq)) and procedures that may be published from time to time on this Site by Unconfigured Forum (collectively, the "Agreement").\n\nPlease read this Agreement carefully before accessing or using the Website. By accessing or using any part of the web site, you agree to become bound by the terms and conditions of this agreement. If you do not agree to all the terms and conditions of this agreement, then you may not access the Website or use any services. If these terms and conditions are considered an offer by Unconfigured Forum, acceptance is expressly limited to these terms. The Website is available only to individuals who are at least 13 years old.\n\n<a name="1"></a>\n\n## [1. Your www.example.com Account](#1)\n\nIf you create an account on the Website, you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account. You must immediately notify Unconfigured Forum of any unauthorized uses of your account or any other breaches of security. Unconfigured Forum will not be liable for any acts or omissions by you, including any damages of any kind incurred as a result of such acts or omissions.\n\n<a name="2"></a>\n\n## [2. Responsibility of Contributors](#2)\n\nIf you post material to the Website, post links on the Website, or otherwise make (or allow any third party to make) material available by means of the Website (any such material, "Content"), You are entirely responsible for the content of, and any harm resulting from, that Content. That is the case regardless of whether the Content in question constitutes text, graphics, an audio file, or computer software. By making Content available, you represent and warrant that:\n\n*   the downloading, copying and use of the Content will not infringe the proprietary rights, including but not limited to the copyright, patent, trademark or trade secret rights, of any third party;\n*   if your employer has rights to intellectual property you create, you have either (i) received permission from your employer to post or make available the Content, including but not limited to any software, or (ii) secured from your employer a waiver as to all rights in or to the Content;\n*   you have fully complied with any third-party licenses relating to the Content, and have done all things necessary to successfully pass through to end users any required terms;\n*   the Content does not contain or install any viruses, worms, malware, Trojan horses or other harmful or destructive content;\n*   the Content is not spam, is not machine- or randomly-generated, and does not contain unethical or unwanted commercial content designed to drive traffic to third party sites or boost the search engine rankings of third party sites, or to further unlawful acts (such as phishing) or mislead recipients as to the source of the material (such as spoofing);\n*   the Content is not pornographic, does not contain threats or incite violence, and does not violate the privacy or publicity rights of any third party;\n*   your content is not getting advertised via unwanted electronic messages such as spam links on newsgroups, email lists, blogs and web sites, and similar unsolicited promotional methods;\n*   your content is not named in a manner that misleads your readers into thinking that you are another person or company; and\n*   you have, in the case of Content that includes computer code, accurately categorized and/or described the type, nature, uses and effects of the materials, whether requested to do so by Unconfigured Forum or otherwise.\n\n<a name="3"></a>\n\n## [3. User Content License](#3)\n\nUser contributions are licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US). Without limiting any of those representations or warranties, Unconfigured Forum has the right (though not the obligation) to, in Unconfigured Forum’s sole discretion (i) refuse or remove any content that, in Unconfigured Forum’s reasonable opinion, violates any Unconfigured Forum policy or is in any way harmful or objectionable, or (ii) terminate or deny access to and use of the Website to any individual or entity for any reason, in Unconfigured Forum’s sole discretion. Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid.\n\n\n<a name="4"></a>\n\n## [4. Payment and Renewal](#4)\n\n### General Terms\n\nOptional paid services or upgrades may be available on the Website. When utilizing an optional paid service or upgrade, you agree to pay Unconfigured Forum the monthly or annual subscription fees indicated. Payments will be charged on a pre-pay basis on the day you begin utilizing the service or upgrade and will cover the use of that service or upgrade for a monthly or annual subscription period as indicated. These fees are not refundable.\n\n### Automatic Renewal\n\nUnless you notify Unconfigured Forum before the end of the applicable subscription period that you want to cancel a service or upgrade, your subscription will automatically renew and you authorize us to collect the then-applicable annual or monthly subscription fee (as well as any taxes) using any credit card or other payment mechanism we have on record for you. Subscriptions can be canceled at any time.\n\n<a name="5"></a>\n\n## [5. Services](#5)\n\n### Hosting, Support Services\n\nOptional Hosting and Support services may be provided by Unconfigured Forum under the terms and conditions for each such service. By signing up for a Hosting/Support or Support services account, you agree to abide by such terms and conditions.\n\n<a name="6"></a>\n\n## [6. Responsibility of Website Visitors](#6)\n\nUnconfigured Forum has not reviewed, and cannot review, all of the material, including computer software, posted to the Website, and cannot therefore be responsible for that material’s content, use or effects. By operating the Website, Unconfigured Forum does not represent or imply that it endorses the material there posted, or that it believes such material to be accurate, useful or non-harmful. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. The Website may contain content that is offensive, indecent, or otherwise objectionable, as well as content containing technical inaccuracies, typographical mistakes, and other errors. The Website may also contain material that violates the privacy or publicity rights, or infringes the intellectual property and other proprietary rights, of third parties, or the downloading, copying or use of which is subject to additional terms and conditions, stated or unstated. Unconfigured Forum disclaims any responsibility for any harm resulting from the use by visitors of the Website, or from any downloading by those visitors of content there posted.\n\n<a name="7"></a>\n\n## [7. Content Posted on Other Websites](#7)\n\nWe have not reviewed, and cannot review, all of the material, including computer software, made available through the websites and webpages to which www.example.com links, and that link to www.example.com. Unconfigured Forum does not have any control over those non-www.example.com websites and webpages, and is not responsible for their contents or their use. By linking to a non-www.example.com website or webpage, Unconfigured Forum does not represent or imply that it endorses such website or webpage. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. Unconfigured Forum disclaims any responsibility for any harm resulting from your use of non-www.example.com websites and webpages.\n\n<a name="8"></a>\n\n## [8. Copyright Infringement and DMCA Policy](#8)\n\nAs Unconfigured Forum asks others to respect its intellectual property rights, it respects the intellectual property rights of others. If you believe that material located on or linked to by www.example.com violates your copyright, and if this website resides in the USA, you are encouraged to notify Unconfigured Forum in accordance with Unconfigured Forum’s [Digital Millennium Copyright Act](http://en.wikipedia.org/wiki/Digital_Millennium_Copyright_Act) ("DMCA") Policy. Unconfigured Forum will respond to all such notices, including as required or appropriate by removing the infringing material or disabling all links to the infringing material. Unconfigured Forum will terminate a visitor’s access to and use of the Website if, under appropriate circumstances, the visitor is determined to be a repeat infringer of the copyrights or other intellectual property rights of Unconfigured Forum or others. In the case of such termination, Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid to Unconfigured Forum.\n\n<a name="9"></a>\n\n## [9. Intellectual Property](#9)\n\nThis Agreement does not transfer from Unconfigured Forum to you any Unconfigured Forum or third party intellectual property, and all right, title and interest in and to such property will remain (as between the parties) solely with Unconfigured Forum. Unconfigured Forum, www.example.com, the www.example.com logo, and all other trademarks, service marks, graphics and logos used in connection with www.example.com, or the Website are trademarks or registered trademarks of Unconfigured Forum or Unconfigured Forum’s licensors. Other trademarks, service marks, graphics and logos used in connection with the Website may be the trademarks of other third parties. Your use of the Website grants you no right or license to reproduce or otherwise use any Unconfigured Forum or third-party trademarks.\n\n<a name="10"></a>\n\n## [10. Advertisements](#10)\n\nUnconfigured Forum reserves the right to display advertisements on your content unless you have purchased an Ad-free Upgrade or a Services account.\n\n<a name="11"></a>\n\n## [11. Attribution](#11)\n\nUnconfigured Forum reserves the right to display attribution links such as ‘Powered by www.example.com,’ theme author, and font attribution in your content footer or toolbar. Footer credits and the www.example.com toolbar may not be removed regardless of upgrades purchased.\n\n<a name="12"></a>\n\n## [12. Changes](#12)\n\nUnconfigured Forum reserves the right, at its sole discretion, to modify or replace any part of this Agreement. It is your responsibility to check this Agreement periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Agreement constitutes acceptance of those changes. Unconfigured Forum may also, in the future, offer new services and/or features through the Website (including, the release of new tools and resources). Such new features and/or services shall be subject to the terms and conditions of this Agreement.\n\n<a name="13"></a>\n\n## [13. Termination](#13)\n\nUnconfigured Forum may terminate your access to all or any part of the Website at any time, with or without cause, with or without notice, effective immediately. If you wish to terminate this Agreement or your www.example.com account (if you have one), you may simply discontinue using the Website. All provisions of this Agreement which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.\n\n<a name="14"></a>\n\n## [14. Disclaimer of Warranties](#14)\n\nThe Website is provided "as is". Unconfigured Forum and its suppliers and licensors hereby disclaim all warranties of any kind, express or implied, including, without limitation, the warranties of merchantability, fitness for a particular purpose and non-infringement. Neither Unconfigured Forum nor its suppliers and licensors, makes any warranty that the Website will be error free or that cess thereto will be continuous or uninterrupted. If you’re actually reading this, here’s [a treat](http://www.newyorker.com/online/blogs/shouts/2012/12/the-hundred-best-lists-of-all-time.html). You understand that you download from, or otherwise obtain content or services through, the Website at your own discretion and risk.\n\n<a name="15"></a>\n\n## [15. Limitation of Liability](#15)\n\nIn no event will Unconfigured Forum, or its suppliers or licensors, be liable with respect to any subject matter of this agreement under any contract, negligence, strict liability or other legal or equitable theory for: (i) any special, incidental or consequential damages; (ii) the cost of procurement for substitute products or services; (iii) for interruption of use or loss or corruption of data; or (iv) for any amounts that exceed the fees paid by you to Unconfigured Forum under this agreement during the twelve (12) month period prior to the cause of action. Unconfigured Forum shall have no liability for any failure or delay due to matters beyond their reasonable control. The foregoing shall not apply to the extent prohibited by applicable law.\n\n<a name="16"></a>\n\n## [16. General Representation and Warranty](#16)\n\nYou represent and warrant that (i) your use of the Website will be in strict accordance with the Unconfigured Forum [Privacy Policy](/privacy), [Community Guidelines](/guidelines), with this Agreement and with all applicable laws and regulations (including without limitation any local laws or regulations in your country, state, city, or other governmental area, regarding online conduct and acceptable content, and including all applicable laws regarding the transmission of technical data exported from the country in which this website resides or the country in which you reside) and (ii) your use of the Website will not infringe or misappropriate the intellectual property rights of any third party.\n\n<a name="17"></a>\n\n## [17. Indemnification](#17)\n\nYou agree to indemnify and hold harmless Unconfigured Forum, its contractors, and its licensors, and their respective directors, officers, employees and agents from and against any and all claims and expenses, including attorneys’ fees, arising out of your use of the Website, including but not limited to your violation of this Agreement.\n\n<a name="18"></a>\n\n## [18. Miscellaneous](#18)\n\nThis Agreement constitutes the entire agreement between Unconfigured Forum and you concerning the subject matter hereof, and they may only be modified by a written amendment signed by an authorized executive of Unconfigured Forum, or by the posting by Unconfigured Forum of a revised version. Except to the extent applicable law, if any, provides otherwise, this Agreement, any access to or use of the Website will be governed by the laws of the state of California, U.S.A., excluding its conflict of law provisions, and the proper venue for any disputes arising out of or relating to any of the same will be the state and federal courts located in San Francisco County, California. Except for claims for injunctive or equitable relief or claims regarding intellectual property rights (which may be brought in any competent court without the posting of a bond), any dispute arising under this Agreement shall be finally settled in accordance with the Comprehensive Arbitration Rules of the Judicial Arbitration and Mediation Service, Inc. (“JAMS”) by three arbitrators appointed in accordance with such Rules. The arbitration shall take place in San Francisco, California, in the English language and the arbitral decision may be enforced in any court. The prevailing party in any action or proceeding to enforce this Agreement shall be entitled to costs and attorneys’ fees. If any part of this Agreement is held invalid or unenforceable, that part will be construed to reflect the parties’ original intent, and the remaining portions will remain in full force and effect. A waiver by either party of any term or condition of this Agreement or any breach thereof, in any one instance, will not waive such term or condition or any subsequent breach thereof. You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; Unconfigured Forum may assign its rights under this Agreement without condition. This Agreement will be binding upon and will inure to the benefit of the parties, their successors and permitted assigns.\n\nThis document is CC-BY-SA. It was last updated May 31, 2013.\n\nOriginally adapted from the [WordPress Terms of Service](http://en.wordpress.com/tos/).	<p>The following terms and conditions govern all use of the <a href="http://www.example.com">www.example.com</a> website and all content, services and products available at or through the website, including, but not limited to, <a href="http://www.example.com">www.example.com</a> Forum Software, <a href="http://www.example.com">www.example.com</a> Support Forums and the <a href="http://www.example.com">www.example.com</a> Hosting service ("Hosting"), (taken together, the Website). The Website is owned and operated by My Unconfigured Forum Ltd. ("Unconfigured Forum"). The Website is offered subject to your acceptance without modification of all of the terms and conditions contained herein and all other operating rules, policies (including, without limitation, <a href="http://www.example.com%E2%80%99s">www.example.com’s</a> <a href="/privacy">Privacy Policy</a> and <a href="/faq">Community Guidelines</a>) and procedures that may be published from time to time on this Site by Unconfigured Forum (collectively, the "Agreement").</p>\n\n<p>Please read this Agreement carefully before accessing or using the Website. By accessing or using any part of the web site, you agree to become bound by the terms and conditions of this agreement. If you do not agree to all the terms and conditions of this agreement, then you may not access the Website or use any services. If these terms and conditions are considered an offer by Unconfigured Forum, acceptance is expressly limited to these terms. The Website is available only to individuals who are at least 13 years old.</p>\n\n<p><a name="1"></a></p>\n\n<h2><a href="#1">1. Your www.example.com Account</a></h2>\n\n<p>If you create an account on the Website, you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account. You must immediately notify Unconfigured Forum of any unauthorized uses of your account or any other breaches of security. Unconfigured Forum will not be liable for any acts or omissions by you, including any damages of any kind incurred as a result of such acts or omissions.</p>\n\n<p><a name="2"></a></p>\n\n<h2><a href="#2">2. Responsibility of Contributors</a></h2>\n\n<p>If you post material to the Website, post links on the Website, or otherwise make (or allow any third party to make) material available by means of the Website (any such material, "Content"), You are entirely responsible for the content of, and any harm resulting from, that Content. That is the case regardless of whether the Content in question constitutes text, graphics, an audio file, or computer software. By making Content available, you represent and warrant that:</p>\n\n<ul>\n<li>the downloading, copying and use of the Content will not infringe the proprietary rights, including but not limited to the copyright, patent, trademark or trade secret rights, of any third party;</li>\n<li>if your employer has rights to intellectual property you create, you have either (i) received permission from your employer to post or make available the Content, including but not limited to any software, or (ii) secured from your employer a waiver as to all rights in or to the Content;</li>\n<li>you have fully complied with any third-party licenses relating to the Content, and have done all things necessary to successfully pass through to end users any required terms;</li>\n<li>the Content does not contain or install any viruses, worms, malware, Trojan horses or other harmful or destructive content;</li>\n<li>the Content is not spam, is not machine- or randomly-generated, and does not contain unethical or unwanted commercial content designed to drive traffic to third party sites or boost the search engine rankings of third party sites, or to further unlawful acts (such as phishing) or mislead recipients as to the source of the material (such as spoofing);</li>\n<li>the Content is not pornographic, does not contain threats or incite violence, and does not violate the privacy or publicity rights of any third party;</li>\n<li>your content is not getting advertised via unwanted electronic messages such as spam links on newsgroups, email lists, blogs and web sites, and similar unsolicited promotional methods;</li>\n<li>your content is not named in a manner that misleads your readers into thinking that you are another person or company; and</li>\n<li>you have, in the case of Content that includes computer code, accurately categorized and/or described the type, nature, uses and effects of the materials, whether requested to do so by Unconfigured Forum or otherwise.</li>\n</ul>\n\n<p><a name="3"></a></p>\n\n<h2><a href="#3">3. User Content License</a></h2>\n\n<p>User contributions are licensed under a <a href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US">Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License</a>. Without limiting any of those representations or warranties, Unconfigured Forum has the right (though not the obligation) to, in Unconfigured Forum’s sole discretion (i) refuse or remove any content that, in Unconfigured Forum’s reasonable opinion, violates any Unconfigured Forum policy or is in any way harmful or objectionable, or (ii) terminate or deny access to and use of the Website to any individual or entity for any reason, in Unconfigured Forum’s sole discretion. Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid.</p>\n\n<p><a name="4"></a></p>\n\n<h2><a href="#4">4. Payment and Renewal</a></h2>\n\n<h3>General Terms</h3>\n\n<p>Optional paid services or upgrades may be available on the Website. When utilizing an optional paid service or upgrade, you agree to pay Unconfigured Forum the monthly or annual subscription fees indicated. Payments will be charged on a pre-pay basis on the day you begin utilizing the service or upgrade and will cover the use of that service or upgrade for a monthly or annual subscription period as indicated. These fees are not refundable.</p>\n\n<h3>Automatic Renewal</h3>\n\n<p>Unless you notify Unconfigured Forum before the end of the applicable subscription period that you want to cancel a service or upgrade, your subscription will automatically renew and you authorize us to collect the then-applicable annual or monthly subscription fee (as well as any taxes) using any credit card or other payment mechanism we have on record for you. Subscriptions can be canceled at any time.</p>\n\n<p><a name="5"></a></p>\n\n<h2><a href="#5">5. Services</a></h2>\n\n<h3>Hosting, Support Services</h3>\n\n<p>Optional Hosting and Support services may be provided by Unconfigured Forum under the terms and conditions for each such service. By signing up for a Hosting/Support or Support services account, you agree to abide by such terms and conditions.</p>\n\n<p><a name="6"></a></p>\n\n<h2><a href="#6">6. Responsibility of Website Visitors</a></h2>\n\n<p>Unconfigured Forum has not reviewed, and cannot review, all of the material, including computer software, posted to the Website, and cannot therefore be responsible for that material’s content, use or effects. By operating the Website, Unconfigured Forum does not represent or imply that it endorses the material there posted, or that it believes such material to be accurate, useful or non-harmful. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. The Website may contain content that is offensive, indecent, or otherwise objectionable, as well as content containing technical inaccuracies, typographical mistakes, and other errors. The Website may also contain material that violates the privacy or publicity rights, or infringes the intellectual property and other proprietary rights, of third parties, or the downloading, copying or use of which is subject to additional terms and conditions, stated or unstated. Unconfigured Forum disclaims any responsibility for any harm resulting from the use by visitors of the Website, or from any downloading by those visitors of content there posted.</p>\n\n<p><a name="7"></a></p>\n\n<h2><a href="#7">7. Content Posted on Other Websites</a></h2>\n\n<p>We have not reviewed, and cannot review, all of the material, including computer software, made available through the websites and webpages to which <a href="http://www.example.com">www.example.com</a> links, and that link to <a href="http://www.example.com">www.example.com</a>. Unconfigured Forum does not have any control over those non-www.example.com websites and webpages, and is not responsible for their contents or their use. By linking to a non-www.example.com website or webpage, Unconfigured Forum does not represent or imply that it endorses such website or webpage. You are responsible for taking precautions as necessary to protect yourself and your computer systems from viruses, worms, Trojan horses, and other harmful or destructive content. Unconfigured Forum disclaims any responsibility for any harm resulting from your use of non-www.example.com websites and webpages.</p>\n\n<p><a name="8"></a></p>\n\n<h2><a href="#8">8. Copyright Infringement and DMCA Policy</a></h2>\n\n<p>As Unconfigured Forum asks others to respect its intellectual property rights, it respects the intellectual property rights of others. If you believe that material located on or linked to by <a href="http://www.example.com">www.example.com</a> violates your copyright, and if this website resides in the USA, you are encouraged to notify Unconfigured Forum in accordance with Unconfigured Forum’s <a href="http://en.wikipedia.org/wiki/Digital_Millennium_Copyright_Act">Digital Millennium Copyright Act</a> ("DMCA") Policy. Unconfigured Forum will respond to all such notices, including as required or appropriate by removing the infringing material or disabling all links to the infringing material. Unconfigured Forum will terminate a visitor’s access to and use of the Website if, under appropriate circumstances, the visitor is determined to be a repeat infringer of the copyrights or other intellectual property rights of Unconfigured Forum or others. In the case of such termination, Unconfigured Forum will have no obligation to provide a refund of any amounts previously paid to Unconfigured Forum.</p>\n\n<p><a name="9"></a></p>\n\n<h2><a href="#9">9. Intellectual Property</a></h2>\n\n<p>This Agreement does not transfer from Unconfigured Forum to you any Unconfigured Forum or third party intellectual property, and all right, title and interest in and to such property will remain (as between the parties) solely with Unconfigured Forum. Unconfigured Forum, <a href="http://www.example.com">www.example.com</a>, the <a href="http://www.example.com">www.example.com</a> logo, and all other trademarks, service marks, graphics and logos used in connection with <a href="http://www.example.com">www.example.com</a>, or the Website are trademarks or registered trademarks of Unconfigured Forum or Unconfigured Forum’s licensors. Other trademarks, service marks, graphics and logos used in connection with the Website may be the trademarks of other third parties. Your use of the Website grants you no right or license to reproduce or otherwise use any Unconfigured Forum or third-party trademarks.</p>\n\n<p><a name="10"></a></p>\n\n<h2><a href="#10">10. Advertisements</a></h2>\n\n<p>Unconfigured Forum reserves the right to display advertisements on your content unless you have purchased an Ad-free Upgrade or a Services account.</p>\n\n<p><a name="11"></a></p>\n\n<h2><a href="#11">11. Attribution</a></h2>\n\n<p>Unconfigured Forum reserves the right to display attribution links such as ‘Powered by <a href="http://www.example.com">www.example.com</a>,’ theme author, and font attribution in your content footer or toolbar. Footer credits and the <a href="http://www.example.com">www.example.com</a> toolbar may not be removed regardless of upgrades purchased.</p>\n\n<p><a name="12"></a></p>\n\n<h2><a href="#12">12. Changes</a></h2>\n\n<p>Unconfigured Forum reserves the right, at its sole discretion, to modify or replace any part of this Agreement. It is your responsibility to check this Agreement periodically for changes. Your continued use of or access to the Website following the posting of any changes to this Agreement constitutes acceptance of those changes. Unconfigured Forum may also, in the future, offer new services and/or features through the Website (including, the release of new tools and resources). Such new features and/or services shall be subject to the terms and conditions of this Agreement.</p>\n\n<p><a name="13"></a></p>\n\n<h2><a href="#13">13. Termination</a></h2>\n\n<p>Unconfigured Forum may terminate your access to all or any part of the Website at any time, with or without cause, with or without notice, effective immediately. If you wish to terminate this Agreement or your <a href="http://www.example.com">www.example.com</a> account (if you have one), you may simply discontinue using the Website. All provisions of this Agreement which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.</p>\n\n<p><a name="14"></a></p>\n\n<h2><a href="#14">14. Disclaimer of Warranties</a></h2>\n\n<p>The Website is provided "as is". Unconfigured Forum and its suppliers and licensors hereby disclaim all warranties of any kind, express or implied, including, without limitation, the warranties of merchantability, fitness for a particular purpose and non-infringement. Neither Unconfigured Forum nor its suppliers and licensors, makes any warranty that the Website will be error free or that cess thereto will be continuous or uninterrupted. If you’re actually reading this, here’s <a href="http://www.newyorker.com/online/blogs/shouts/2012/12/the-hundred-best-lists-of-all-time.html">a treat</a>. You understand that you download from, or otherwise obtain content or services through, the Website at your own discretion and risk.</p>\n\n<p><a name="15"></a></p>\n\n<h2><a href="#15">15. Limitation of Liability</a></h2>\n\n<p>In no event will Unconfigured Forum, or its suppliers or licensors, be liable with respect to any subject matter of this agreement under any contract, negligence, strict liability or other legal or equitable theory for: (i) any special, incidental or consequential damages; (ii) the cost of procurement for substitute products or services; (iii) for interruption of use or loss or corruption of data; or (iv) for any amounts that exceed the fees paid by you to Unconfigured Forum under this agreement during the twelve (12) month period prior to the cause of action. Unconfigured Forum shall have no liability for any failure or delay due to matters beyond their reasonable control. The foregoing shall not apply to the extent prohibited by applicable law.</p>\n\n<p><a name="16"></a></p>\n\n<h2><a href="#16">16. General Representation and Warranty</a></h2>\n\n<p>You represent and warrant that (i) your use of the Website will be in strict accordance with the Unconfigured Forum <a href="/privacy">Privacy Policy</a>, <a href="/guidelines">Community Guidelines</a>, with this Agreement and with all applicable laws and regulations (including without limitation any local laws or regulations in your country, state, city, or other governmental area, regarding online conduct and acceptable content, and including all applicable laws regarding the transmission of technical data exported from the country in which this website resides or the country in which you reside) and (ii) your use of the Website will not infringe or misappropriate the intellectual property rights of any third party.</p>\n\n<p><a name="17"></a></p>\n\n<h2><a href="#17">17. Indemnification</a></h2>\n\n<p>You agree to indemnify and hold harmless Unconfigured Forum, its contractors, and its licensors, and their respective directors, officers, employees and agents from and against any and all claims and expenses, including attorneys’ fees, arising out of your use of the Website, including but not limited to your violation of this Agreement.</p>\n\n<p><a name="18"></a></p>\n\n<h2><a href="#18">18. Miscellaneous</a></h2>\n\n<p>This Agreement constitutes the entire agreement between Unconfigured Forum and you concerning the subject matter hereof, and they may only be modified by a written amendment signed by an authorized executive of Unconfigured Forum, or by the posting by Unconfigured Forum of a revised version. Except to the extent applicable law, if any, provides otherwise, this Agreement, any access to or use of the Website will be governed by the laws of the state of California, U.S.A., excluding its conflict of law provisions, and the proper venue for any disputes arising out of or relating to any of the same will be the state and federal courts located in San Francisco County, California. Except for claims for injunctive or equitable relief or claims regarding intellectual property rights (which may be brought in any competent court without the posting of a bond), any dispute arising under this Agreement shall be finally settled in accordance with the Comprehensive Arbitration Rules of the Judicial Arbitration and Mediation Service, Inc. (“JAMS”) by three arbitrators appointed in accordance with such Rules. The arbitration shall take place in San Francisco, California, in the English language and the arbitral decision may be enforced in any court. The prevailing party in any action or proceeding to enforce this Agreement shall be entitled to costs and attorneys’ fees. If any part of this Agreement is held invalid or unenforceable, that part will be construed to reflect the parties’ original intent, and the remaining portions will remain in full force and effect. A waiver by either party of any term or condition of this Agreement or any breach thereof, in any one instance, will not waive such term or condition or any subsequent breach thereof. You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; Unconfigured Forum may assign its rights under this Agreement without condition. This Agreement will be binding upon and will inure to the benefit of the parties, their successors and permitted assigns.</p>\n\n<p>This document is CC-BY-SA. It was last updated May 31, 2013.</p>\n\n<p>Originally adapted from the <a href="http://en.wordpress.com/tos/">WordPress Terms of Service</a>.</p>	2014-11-01 07:31:04.316664	2014-11-01 07:31:04.316664	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:04.360741	f	\N	0	0	0	\N	\N	2727	1	1	f	2014-11-01 07:31:04.316467	1	\N	0	f	f	\N	1
13	-1	10	1	Congratulations, you are now the proud owner of your very own [Civilized Discourse Construction Kit](http://www.discourse.org). :hatching_chick:\n\n### Admin Dashboard\n\nAs an admin you have total control over this Discourse instance. Exercise your admin superpowers via the admin dashboard at\n\n[**/admin**](/admin)\n\nYou can also access it via the "hamburger" <kbd>☰</kbd> menu in the upper right: Admin functions are generally marked with the wrench :wrench:  icon, so look for that.\n\n### Enter Required Settings\n\nGo to the [Required tab](/admin/site_settings/category/required) of the site settings and enter all the required fields. **Until you set these required fields, _your Discourse is broken!_** Go ahead and do that now.\n\nWe'll wait.\n\n### Customize Logos and Colors\n\nBy default you get the standard "penciled in" Discourse logo. Look for the [**assets for the site design**](/t/assets-for-the-site-design) topic; follow the instructions there to upload your logos to that topic, and then paste the uploaded image paths into the required logo settings.\n\nTo quickly give your Discourse a distinctive look, without having to edit or understand CSS, create a new color scheme via [**Customize, Colors**](/admin/customize/colors).\n\nYou can also specify custom CSS and custom HTML headers/footers to further customize the look. One common request is a navigation header that takes you back to the parent site. Here is some example HTML to put in [**Customize, CSS/HTML**](/admin/customize/css_html) under "Header":\n\n```\n<div id="top-navbar" class="container">\n<span id="top-navbar-links" style="height:20px;">\n  <a href="http://example.com">Home</a> | \n  <a href="http://example.com/about/">About</a> | \n  <a href="http://example.com/news/">News</a> | \n  <a href="http://example.com/products/">Products</a> | \n  <a href="http://blog.example.com/blog">Blog</a> | \n  <a href="http://forums.example.com/">Forums</a>\n</span>\n</div>\n```\n\n### Establish Staff\n\nStaff members are official representatives of this community. There are two kinds of Staff:\n\n1. **Admins**, who can do anything and configure anything on this site. \n2. **Moderators**, who can edit all posts and users, but cannot add categories or change any site settings. \n\nYou may want to grant other users staff abilities &ndash; to do so click the admin button :wrench: on their user page, then look for the grant buttons.\n\n### Private or Public?\n\nDiscourse assumes you want a public discussion area. If you prefer a private one, change these [login site settings](/admin/site_settings/category/login):\n\n- `must approve users`\n- `login required`\n- `invite only`\n\nIf you only want some parts of your site to be private, edit category permissions. You already have one private category: this topic is in it!\n\n### Configure Login Methods\n\nUsers can log in with traditional local username and password accounts. You may want to add:\n\n- [Google logins](https://meta.discourse.org/t/configuring-google-oauth2-login-for-discourse/15858)\n- [Twitter logins](https://meta.discourse.org/t/configuring-twitter-login-for-discourse/13395)\n- [Facebook logins](https://meta.discourse.org/t/configuring-facebook-login-for-discourse/13394)\n- [GitHub logins](https://meta.discourse.org/t/configuring-github-login-for-discourse/13745)\n\nIf you want to get extra-fancy you can also [set up single-sign on](https://meta.discourse.org/t/official-single-sign-on-for-discourse/13045), or even [build your own login method](https://meta.discourse.org/t/login-to-discourse-with-custom-oauth2-provider/14717).\n\n### Test Your Email\n\nEmail is required for new account signups and notifications. **Test your email to make sure it is configured correctly!**  Visit [the admin email settings](/admin/email), then enter an email address in the "email address to test" field and click <kbd>send test email</kbd>.\n\n- You got the test email? Great! **Read that email closely**, it has important email deliverability tips. \n- You didn't get the test email? This means your users probably aren't getting any signup or notification emails either.\n\nEmail deliverability can be hard. We strongly recommend using dedicated email services like [Mandrill](http://mandrill.com), [MailGun](http://www.mailgun.com/), or [MailJet](http://www.mailjet.com/), which offer generous free plans that work fine for most communities.\n\nIf you'd like to enable *replying* to topics via email, [see this howto](https://meta.discourse.org/t/set-up-reply-via-email-support/14003).\n\n### What and Who is this site for?\n\nOne of the default topics is [Welcome to Discourse](/t/welcome-to-discourse). This topic is pinned globally, so it will appear on the homepage, right at the top of the topic list, for all new users. Try viewing your site with incognito, inprivate, or anonymous mode enabled in your browser to see it how new users will.\n\nYour welcome topic is important because it is the first thing you visitors will see:\n\n- Where am I?\n- Who are these discussions for?\n- What can I [find here](https://www.youtube.com/watch?v=d0VNHe5fq30)?\n- Why should I visit?\n\n[Edit your welcome topic](/t/welcome-to-discourse) and write a **brief introduction to your community**. Think of it as your "elevator pitch" &ndash; how would you describe this site to a stranger on an elevator when you had about 1 minute to talk?\n\nNote that pinning topics works a little differently in Discourse:\n\n- Users can hide pins on topics once they have read them via the controls at the bottom of the topic, so they aren't always pinned forever for everyone.\n- When you pin a topic, you can choose to pin it globally to all topic lists, or pin it only within its category.\n\nIf a pin isn't visible enough, you can also turn one single topic into a **banner**. The banner topic floats on top of all topics and all primary pages. Users can permanently dismiss this floating banner by clicking the &times; in the upper right corner.\n\nTo make (or remove) a pin or a banner, use the admin wrench at the top right or bottom of the topic.\n\n### Set the Homepage\n\nBy default your homepage is a simple list of the latest posts.\n\nWe strongly recommend sticking with this homepage for small and medium communities until you start getting lots of new topics every day.\n\nYou can change the homepage to the Categories list by editing `top menu` in the [Basic Setup](/admin/site_settings/category/basic) site settings. Change it from the default of\n\n`latest|new|unread|starred|top|categories`\n\nto\n\n`categories|latest|new|unread|starred|top`\n\nThat is, move categories from the far right to the far left -- that leftmost top menu item is your default homepage. \n\n### Build Your Own FAQ\n\nRight now [your FAQ](/faq) is the same Creative Commons [universal rules of civilized discourse](http://blog.discourse.org/2013/03/the-universal-rules-of-civilized-discourse/) we provide to all Discourse installs. These built-in community guidelines are referenced a bunch of places; please *do* use them and refer to them often – they really work!\n\nHowever, if you want to set up a more detailed FAQ dealing with the specifics of *your* community, here's how:\n\n1. Create a new [meta topic](category/meta), titled "Frequently Asked Questions (FAQ)" or similar.\n\n2. Use the admin wrench icon below the post to make it a wiki post. This means the post is now editable to any user with a trust level of 1 or higher.\n\n3. Note the URL to that topic.\n\n4. Paste that URL into the `faq url` setting in the admin site settings. This links your topic from the hamburger FAQ menu entry at the top right of every page.\n\nNow you have a community FAQ for your site that is collaboratively editable, and linked from every page on the site. \n\n### Categories\n\nYou have three default categories:\n\n1. [Meta](/category/meta) – general discussion about the site itself. [It's important!](https://meta.discourse.org/t/what-is-meta/5249)\n2. [Lounge](/category/lounge) – a perk for users at trust level 3 and higher\n3. [Staff](/category/staff) – visible only to staff (admins and moderators)\n\n**Don't create too many initial categories**, as you can overwhelm your audience. You can always add more categories, and easily bulk recategorize topics later. It's better to figure out the organization as you go rather than assuming you'll get it all right from the beginning (hint: you won't).\n\nTo add a category, visit the [categories page](/categories), then click Create Category at the upper right. You can set security per-category so only certain groups of users can see topics in that category.\n\nEvery category has an initial "About this category" topic. This topic will be pinned to the top of the category, and the description you enter will be used in a bunch of places. Be sure to give your new category a good, clear description, so people understand what belongs there!\n\n### File Uploads\n\nBasic image uploads work fine out of the box stored locally, provided you have adequate disk space.\n\n- If you'd like other sorts of files to be uploaded beyond just images, modify the [file settings](/admin/site_settings/category/files).\n\n- If you'd rather store your images and files on Amazon S3, [follow this howto](http://meta.discourse.org/t/how-to-set-up-image-uploads-to-s3/7229).\n\n\n### New User Sandbox and the Trust System\n\nIf your discussion area is be open to the public, new visitors will arrive that are initially strangers to the community. Discourse has a [trust system](https://meta.discourse.org/t/what-do-user-trust-levels-do/4924/2) where users can, over time, earn the trust of the community and gain abilities to assist in governing their community.\n\nDiscourse is designed to offer safe defaults for public communities, even with no active moderation. \n\n> **0 (new) &rarr; 1 (basic) &rarr; 2 (member) &rarr; 3 (regular) &rarr; 4 (leader)**\n\nAll new users start out in a sandbox with restrictions for everyone's safety. **Trust level 0 (new) users _cannot_** &hellip;\n\n- post more than 2 hyperlinks\n- post any images or file attachments\n- send private messages\n- flag posts or topics\n- have actual links in the "about me" field of their profile\n- @name mention more than 2 users in a post\n\nVirtually every action a user can take is rate limited for safety, and especially so for new users. But don't worry, new users can [transition to trust level 1](https://meta.discourse.org/t/what-do-user-trust-levels-do/4924/2) in about 15 minutes.\n\nThese defaults are safe, but they may be too conservative for your site:\n\n- If you are pre-vetting all users, or your site is private and you approve all new users manually, you can set everyone's `default trust level` to 1.\n\n- You can relax individual new user restrictions. Search settings for `newuser`. Ones commonly adjusted are `newuser max images`, `newuser max replies per topic`, `newuser max links`.\n\n### User Content Licensing\n\nOut of the box, Discourse defaults to [Creative Commons licensing](https://creativecommons.org/).\n\n> Your users will always retain copyright on their posts, and will always grant the site owner enough rights to include their content on the site.\n>\n> Who is allowed to republish the content posted on this forum?\n> \n> 1. Only the author\n> 2. Author and the owner of this forum\n> 3. Anybody\\*\n\nNumber 3 is the Discourse default &ndash; that's [Creative Commons BY-NC-SA 3.0](http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US).\n\n If that's not what you want, edit the [Terms of Service](/tos) to taste via the edit link at the top.\n\n### Building Your Community\n\nBe patient! Building communities is hard. Before launching, be sure to:\n\n1. Define your community's purpose in a pinned or banner topic.\n2. Seed the discussion with interesting topics.\n3. Commit to visiting and participating regularly.\n4. Link your community everywhere and promote it so people can find it.\n\nThere's more advice at [Building a Discourse Community](http://blog.discourse.org/2014/08/building-a-discourse-community/).\n\n### Sending Invitations\n\nOne way to get people to visit your site is to invite them via email. You can do this via:\n\n- The Invite button at the bottom of the topic.\n- The Invite area on your profile page.\n \nThe invite area on your profile page also includes advanced Staff methods of [sending bulk invites](https://meta.discourse.org/t/sending-bulk-user-invites/16468), and [inviting users into groups](https://meta.discourse.org/t/invite-individual-users-to-a-group/15544).\n\n### Maintenance\n\n- One CPU and 1GB of memory, with swap, is the minimum for a basic Discourse community. As your community grows you may need more memory or CPU resources.\n\n- Hopefully you are running [in our Docker container install](https://github.com/discourse/discourse/blob/master/docs/INSTALL.md); it's the only one we officially support. It guarantees easy updates, and all recommended optimizations from the Discourse team.\n\n- You should get an email notification when new versions of Discourse are released. To update your instance via our easy one click upgrade process, visit [/admin/upgrade](/admin/upgrade).\n\n- Some other things you might eventually want to set up:\n   - [Automatic daily backups](https://meta.discourse.org/t/configure-automatic-backups-for-discourse/14855)\n   - [HTTPS support](https://meta.discourse.org/t/allowing-ssl-for-your-discourse-docker-setup/13847)\n   - [Content Delivery Network support](https://meta.discourse.org/t/enable-a-cdn-for-your-discourse/14857) \n   - [Reply via Email](https://meta.discourse.org/t/set-up-reply-via-email-support/14003)   \n   - [Import and Export your data](https://meta.discourse.org/t/move-your-discourse-instance-to-a-different-server/15721)\n   - [Change the domain name](https://meta.discourse.org/t/how-do-i-change-the-domain-name/16098)\n   - [Multiple Discourse instances on the same server](https://meta.discourse.org/t/multisite-configuration-with-docker/14084)\n   - [Import old content from vBulletin, PHPbb, Vanilla, Drupal, BBPress, etc?](https://github.com/discourse/discourse/tree/master/script/import_scripts)?\n\n### Need more Help?\n\nFor more assistance on configuring and running your Discourse forum, see [meta.discourse.org](http://meta.discourse.org).\n\n----\n\nHave suggestions to improve or update this guide? Submit a [pull request](https://github.com/discourse/discourse/blob/master/docs/ADMIN-QUICK-START-GUIDE.md).	<p>Congratulations, you are now the proud owner of your very own <a href="http://www.discourse.org">Civilized Discourse Construction Kit</a>. <img src="//jnu-developer.com/plugins/emoji/images/hatching_chick.png" title=":hatching_chick:" class="emoji" alt="hatching_chick" width="64" height="64"></p>\n\n<h3>Admin Dashboard</h3>\n\n<p>As an admin you have total control over this Discourse instance. Exercise your admin superpowers via the admin dashboard at</p>\n\n<p><a href="/admin"><strong>/admin</strong></a></p>\n\n<p>You can also access it via the "hamburger" <kbd>☰</kbd> menu in the upper right: Admin functions are generally marked with the wrench <img src="//jnu-developer.com/plugins/emoji/images/wrench.png" title=":wrench:" class="emoji" alt="wrench" width="" height="">  icon, so look for that.</p>\n\n<h3>Enter Required Settings</h3>\n\n<p>Go to the <a href="/admin/site_settings/category/required">Required tab</a> of the site settings and enter all the required fields. <strong>Until you set these required fields, <em>your Discourse is broken!</em></strong> Go ahead and do that now.</p>\n\n<p>We'll wait.</p>\n\n<h3>Customize Logos and Colors</h3>\n\n<p>By default you get the standard "penciled in" Discourse logo. Look for the <a href="/t/assets-for-the-site-design"><strong>assets for the site design</strong></a> topic; follow the instructions there to upload your logos to that topic, and then paste the uploaded image paths into the required logo settings.</p>\n\n<p>To quickly give your Discourse a distinctive look, without having to edit or understand CSS, create a new color scheme via <a href="/admin/customize/colors"><strong>Customize, Colors</strong></a>.</p>\n\n<p>You can also specify custom CSS and custom HTML headers/footers to further customize the look. One common request is a navigation header that takes you back to the parent site. Here is some example HTML to put in <a href="/admin/customize/css_html"><strong>Customize, CSS/HTML</strong></a> under "Header":</p>\n\n<p></p><pre><code class="lang-auto">&lt;div id="top-navbar" class="container"&gt;\n&lt;span id="top-navbar-links" style="height:20px;"&gt;\n  &lt;a href="http://example.com"&gt;Home&lt;/a&gt; | \n  &lt;a href="http://example.com/about/"&gt;About&lt;/a&gt; | \n  &lt;a href="http://example.com/news/"&gt;News&lt;/a&gt; | \n  &lt;a href="http://example.com/products/"&gt;Products&lt;/a&gt; | \n  &lt;a href="http://blog.example.com/blog"&gt;Blog&lt;/a&gt; | \n  &lt;a href="http://forums.example.com/"&gt;Forums&lt;/a&gt;\n&lt;/span&gt;\n&lt;/div&gt;</code></pre>\n\n<h3>Establish Staff</h3>\n\n<p>Staff members are official representatives of this community. There are two kinds of Staff:</p>\n\n<ol>\n<li>\n<strong>Admins</strong>, who can do anything and configure anything on this site. </li>\n<li>\n<strong>Moderators</strong>, who can edit all posts and users, but cannot add categories or change any site settings. </li>\n</ol>\n\n<p>You may want to grant other users staff abilities – to do so click the admin button <img src="//jnu-developer.com/plugins/emoji/images/wrench.png" title=":wrench:" class="emoji" alt="wrench" width="64" height="64"> on their user page, then look for the grant buttons.</p>\n\n<h3>Private or Public?</h3>\n\n<p>Discourse assumes you want a public discussion area. If you prefer a private one, change these <a href="/admin/site_settings/category/login">login site settings</a>:</p>\n\n<ul>\n<li><code>must approve users</code></li>\n<li><code>login required</code></li>\n<li><code>invite only</code></li>\n</ul>\n\n<p>If you only want some parts of your site to be private, edit category permissions. You already have one private category: this topic is in it!</p>\n\n<h3>Configure Login Methods</h3>\n\n<p>Users can log in with traditional local username and password accounts. You may want to add:</p>\n\n<ul>\n<li><a href="https://meta.discourse.org/t/configuring-google-oauth2-login-for-discourse/15858">Google logins</a></li>\n<li><a href="https://meta.discourse.org/t/configuring-twitter-login-for-discourse/13395">Twitter logins</a></li>\n<li><a href="https://meta.discourse.org/t/configuring-facebook-login-for-discourse/13394">Facebook logins</a></li>\n<li><a href="https://meta.discourse.org/t/configuring-github-login-for-discourse/13745">GitHub logins</a></li>\n</ul>\n\n<p>If you want to get extra-fancy you can also <a href="https://meta.discourse.org/t/official-single-sign-on-for-discourse/13045">set up single-sign on</a>, or even <a href="https://meta.discourse.org/t/login-to-discourse-with-custom-oauth2-provider/14717">build your own login method</a>.</p>\n\n<h3>Test Your Email</h3>\n\n<p>Email is required for new account signups and notifications. <strong>Test your email to make sure it is configured correctly!</strong>  Visit <a href="/admin/email">the admin email settings</a>, then enter an email address in the "email address to test" field and click <kbd>send test email</kbd>.</p>\n\n<ul>\n<li>You got the test email? Great! <strong>Read that email closely</strong>, it has important email deliverability tips. </li>\n<li>You didn't get the test email? This means your users probably aren't getting any signup or notification emails either.</li>\n</ul>\n\n<p>Email deliverability can be hard. We strongly recommend using dedicated email services like <a href="http://mandrill.com">Mandrill</a>, <a href="http://www.mailgun.com/">MailGun</a>, or <a href="http://www.mailjet.com/">MailJet</a>, which offer generous free plans that work fine for most communities.</p>\n\n<p>If you'd like to enable <em>replying</em> to topics via email, <a href="https://meta.discourse.org/t/set-up-reply-via-email-support/14003">see this howto</a>.</p>\n\n<h3>What and Who is this site for?</h3>\n\n<p>One of the default topics is <a href="/t/welcome-to-discourse">Welcome to Discourse</a>. This topic is pinned globally, so it will appear on the homepage, right at the top of the topic list, for all new users. Try viewing your site with incognito, inprivate, or anonymous mode enabled in your browser to see it how new users will.</p>\n\n<p>Your welcome topic is important because it is the first thing you visitors will see:</p>\n\n<ul>\n<li>Where am I?</li>\n<li>Who are these discussions for?</li>\n<li>What can I <a href="https://www.youtube.com/watch?v=d0VNHe5fq30">find here</a>?</li>\n<li>Why should I visit?</li>\n</ul>\n\n<p><a href="/t/welcome-to-discourse">Edit your welcome topic</a> and write a <strong>brief introduction to your community</strong>. Think of it as your "elevator pitch" – how would you describe this site to a stranger on an elevator when you had about 1 minute to talk?</p>\n\n<p>Note that pinning topics works a little differently in Discourse:</p>\n\n<ul>\n<li>Users can hide pins on topics once they have read them via the controls at the bottom of the topic, so they aren't always pinned forever for everyone.</li>\n<li>When you pin a topic, you can choose to pin it globally to all topic lists, or pin it only within its category.</li>\n</ul>\n\n<p>If a pin isn't visible enough, you can also turn one single topic into a <strong>banner</strong>. The banner topic floats on top of all topics and all primary pages. Users can permanently dismiss this floating banner by clicking the × in the upper right corner.</p>\n\n<p>To make (or remove) a pin or a banner, use the admin wrench at the top right or bottom of the topic.</p>\n\n<h3>Set the Homepage</h3>\n\n<p>By default your homepage is a simple list of the latest posts.</p>\n\n<p>We strongly recommend sticking with this homepage for small and medium communities until you start getting lots of new topics every day.</p>\n\n<p>You can change the homepage to the Categories list by editing <code>top menu</code> in the <a href="/admin/site_settings/category/basic">Basic Setup</a> site settings. Change it from the default of</p>\n\n<p><code>latest|new|unread|starred|top|categories</code></p>\n\n<p>to</p>\n\n<p><code>categories|latest|new|unread|starred|top</code></p>\n\n<p>That is, move categories from the far right to the far left -- that leftmost top menu item is your default homepage. </p>\n\n<h3>Build Your Own FAQ</h3>\n\n<p>Right now <a href="/faq">your FAQ</a> is the same Creative Commons <a href="http://blog.discourse.org/2013/03/the-universal-rules-of-civilized-discourse/">universal rules of civilized discourse</a> we provide to all Discourse installs. These built-in community guidelines are referenced a bunch of places; please <em>do</em> use them and refer to them often – they really work!</p>\n\n<p>However, if you want to set up a more detailed FAQ dealing with the specifics of <em>your</em> community, here's how:</p>\n\n<ol>\n<li><p>Create a new <a>meta topic</a>, titled "Frequently Asked Questions (FAQ)" or similar.</p></li>\n<li><p>Use the admin wrench icon below the post to make it a wiki post. This means the post is now editable to any user with a trust level of 1 or higher.</p></li>\n<li><p>Note the URL to that topic.</p></li>\n<li><p>Paste that URL into the <code>faq url</code> setting in the admin site settings. This links your topic from the hamburger FAQ menu entry at the top right of every page.</p></li>\n</ol>\n\n<p>Now you have a community FAQ for your site that is collaboratively editable, and linked from every page on the site. </p>\n\n<h3>Categories</h3>\n\n<p>You have three default categories:</p>\n\n<ol>\n<li>\n<a href="/category/meta">Meta</a> – general discussion about the site itself. <a href="https://meta.discourse.org/t/what-is-meta/5249">It's important!</a>\n</li>\n<li>\n<a href="/category/lounge">Lounge</a> – a perk for users at trust level 3 and higher</li>\n<li>\n<a href="/category/staff">Staff</a> – visible only to staff (admins and moderators)</li>\n</ol>\n\n<p><strong>Don't create too many initial categories</strong>, as you can overwhelm your audience. You can always add more categories, and easily bulk recategorize topics later. It's better to figure out the organization as you go rather than assuming you'll get it all right from the beginning (hint: you won't).</p>\n\n<p>To add a category, visit the <a href="/categories">categories page</a>, then click Create Category at the upper right. You can set security per-category so only certain groups of users can see topics in that category.</p>\n\n<p>Every category has an initial "About this category" topic. This topic will be pinned to the top of the category, and the description you enter will be used in a bunch of places. Be sure to give your new category a good, clear description, so people understand what belongs there!</p>\n\n<h3>File Uploads</h3>\n\n<p>Basic image uploads work fine out of the box stored locally, provided you have adequate disk space.</p>\n\n<ul>\n<li><p>If you'd like other sorts of files to be uploaded beyond just images, modify the <a href="/admin/site_settings/category/files">file settings</a>.</p></li>\n<li><p>If you'd rather store your images and files on Amazon S3, <a href="http://meta.discourse.org/t/how-to-set-up-image-uploads-to-s3/7229">follow this howto</a>.</p></li>\n</ul>\n\n<h3>New User Sandbox and the Trust System</h3>\n\n<p>If your discussion area is be open to the public, new visitors will arrive that are initially strangers to the community. Discourse has a <a href="https://meta.discourse.org/t/what-do-user-trust-levels-do/4924/2">trust system</a> where users can, over time, earn the trust of the community and gain abilities to assist in governing their community.</p>\n\n<p>Discourse is designed to offer safe defaults for public communities, even with no active moderation. </p>\n\n<blockquote><p><strong>0 (new) → 1 (basic) → 2 (member) → 3 (regular) → 4 (leader)</strong></p></blockquote>\n\n<p>All new users start out in a sandbox with restrictions for everyone's safety. <strong>Trust level 0 (new) users <em>cannot</em></strong> …</p>\n\n<ul>\n<li>post more than 2 hyperlinks</li>\n<li>post any images or file attachments</li>\n<li>send private messages</li>\n<li>flag posts or topics</li>\n<li>have actual links in the "about me" field of their profile</li>\n<li>\n<span class="mention">@name</span> mention more than 2 users in a post</li>\n</ul>\n\n<p>Virtually every action a user can take is rate limited for safety, and especially so for new users. But don't worry, new users can <a href="https://meta.discourse.org/t/what-do-user-trust-levels-do/4924/2">transition to trust level 1</a> in about 15 minutes.</p>\n\n<p>These defaults are safe, but they may be too conservative for your site:</p>\n\n<ul>\n<li><p>If you are pre-vetting all users, or your site is private and you approve all new users manually, you can set everyone's <code>default trust level</code> to 1.</p></li>\n<li><p>You can relax individual new user restrictions. Search settings for <code>newuser</code>. Ones commonly adjusted are <code>newuser max images</code>, <code>newuser max replies per topic</code>, <code>newuser max links</code>.</p></li>\n</ul>\n\n<h3>User Content Licensing</h3>\n\n<p>Out of the box, Discourse defaults to <a href="https://creativecommons.org/">Creative Commons licensing</a>.</p>\n\n<blockquote>\n<p>Your users will always retain copyright on their posts, and will always grant the site owner enough rights to include their content on the site.</p>\n<p>Who is allowed to republish the content posted on this forum?</p>\n<ol>\n<li>Only the author</li>\n<li>Author and the owner of this forum</li>\n<li>Anybody*</li>\n</ol>\n</blockquote>\n\n<p>Number 3 is the Discourse default – that's <a href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US">Creative Commons BY-NC-SA 3.0</a>.</p>\n\n<p> If that's not what you want, edit the <a href="/tos">Terms of Service</a> to taste via the edit link at the top.</p>\n\n<h3>Building Your Community</h3>\n\n<p>Be patient! Building communities is hard. Before launching, be sure to:</p>\n\n<ol>\n<li>Define your community's purpose in a pinned or banner topic.</li>\n<li>Seed the discussion with interesting topics.</li>\n<li>Commit to visiting and participating regularly.</li>\n<li>Link your community everywhere and promote it so people can find it.</li>\n</ol>\n\n<p>There's more advice at <a href="http://blog.discourse.org/2014/08/building-a-discourse-community/">Building a Discourse Community</a>.</p>\n\n<h3>Sending Invitations</h3>\n\n<p>One way to get people to visit your site is to invite them via email. You can do this via:</p>\n\n<ul>\n<li>The Invite button at the bottom of the topic.</li>\n<li>The Invite area on your profile page.</li>\n</ul>\n\n<p>The invite area on your profile page also includes advanced Staff methods of <a href="https://meta.discourse.org/t/sending-bulk-user-invites/16468">sending bulk invites</a>, and <a href="https://meta.discourse.org/t/invite-individual-users-to-a-group/15544">inviting users into groups</a>.</p>\n\n<h3>Maintenance</h3>\n\n<ul>\n<li><p>One CPU and 1GB of memory, with swap, is the minimum for a basic Discourse community. As your community grows you may need more memory or CPU resources.</p></li>\n<li><p>Hopefully you are running <a href="https://github.com/discourse/discourse/blob/master/docs/INSTALL.md">in our Docker container install</a>; it's the only one we officially support. It guarantees easy updates, and all recommended optimizations from the Discourse team.</p></li>\n<li><p>You should get an email notification when new versions of Discourse are released. To update your instance via our easy one click upgrade process, visit <a href="/admin/upgrade">/admin/upgrade</a>.</p></li>\n<li>\n<p>Some other things you might eventually want to set up:</p>\n<ul>\n<li><a href="https://meta.discourse.org/t/configure-automatic-backups-for-discourse/14855">Automatic daily backups</a></li>\n<li><a href="https://meta.discourse.org/t/allowing-ssl-for-your-discourse-docker-setup/13847">HTTPS support</a></li>\n<li>\n<a href="https://meta.discourse.org/t/enable-a-cdn-for-your-discourse/14857">Content Delivery Network support</a> </li>\n<li>\n<a href="https://meta.discourse.org/t/set-up-reply-via-email-support/14003">Reply via Email</a>   </li>\n<li><a href="https://meta.discourse.org/t/move-your-discourse-instance-to-a-different-server/15721">Import and Export your data</a></li>\n<li><a href="https://meta.discourse.org/t/how-do-i-change-the-domain-name/16098">Change the domain name</a></li>\n<li><a href="https://meta.discourse.org/t/multisite-configuration-with-docker/14084">Multiple Discourse instances on the same server</a></li>\n<li>\n<a href="https://github.com/discourse/discourse/tree/master/script/import_scripts">Import old content from vBulletin, PHPbb, Vanilla, Drupal, BBPress, etc?</a>?</li>\n</ul>\n</li>\n</ul>\n\n<h3>Need more Help?</h3>\n\n<p>For more assistance on configuring and running your Discourse forum, see <a href="http://meta.discourse.org">meta.discourse.org</a>.</p>\n\n<hr>\n\n<p>Have suggestions to improve or update this guide? Submit a <a href="https://github.com/discourse/discourse/blob/master/docs/ADMIN-QUICK-START-GUIDE.md">pull request</a>.</p>	2014-11-01 07:31:06.388933	2014-11-01 07:31:06.388933	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:06.429096	f	\N	0	0	0	\N	\N	2354	1	1	f	2014-11-01 07:31:06.388776	1	\N	0	f	f	\N	1
10	-1	7	1	This is a permanent topic, visible only to staff, for storing images and files used in the site design. Don't delete it!\n\n\nHere's how:\n\n\n1. Reply to this topic.\n2. Upload all the images you wish to use for logos, favicons, and so forth here. (Use the upload toolbar icon in the post editor, or drag-and-drop or paste images.)\n3. Submit your reply to post it.\n4. Right click the images in your new post to get the path to the uploaded images, or click the edit icon to edit your post and retrieve the path to the images. Copy the image paths.\n5. Paste those image paths into [basic settings](/admin/site_settings/category/required).\n\n\nIf you need to enable different file type uploads, edit `authorized_extensions` in the [file settings](/admin/site_settings/category/files).	<p>This is a permanent topic, visible only to staff, for storing images and files used in the site design. Don't delete it!</p>\n\n<p>Here's how:</p>\n\n<ol>\n<li>Reply to this topic.</li>\n<li>Upload all the images you wish to use for logos, favicons, and so forth here. (Use the upload toolbar icon in the post editor, or drag-and-drop or paste images.)</li>\n<li>Submit your reply to post it.</li>\n<li>Right click the images in your new post to get the path to the uploaded images, or click the edit icon to edit your post and retrieve the path to the images. Copy the image paths.</li>\n<li>Paste those image paths into <a href="/admin/site_settings/category/required">basic settings</a>.</li>\n</ol>\n\n<p>If you need to enable different file type uploads, edit <code>authorized_extensions</code> in the <a href="/admin/site_settings/category/files">file settings</a>.</p>	2014-11-01 07:31:05.866237	2014-11-01 07:31:05.866237	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:05.872076	f	\N	0	0	0	\N	\N	138	1	1	f	2014-11-01 07:31:05.866123	1	\N	0	f	f	\N	1
12	-1	9	1	\nCongratulations! :confetti_ball:\n\nIf you can see this topic, you were recently promoted to **regular** (trust level 3).\n\nYou can now &hellip;\n\n* Edit the title of any topic\n* Change the category of any topic\n* Have all your links followed ([automatic nofollow](http://en.wikipedia.org/wiki/Nofollow) is removed)\n* Access a private Lounge category only visible to users at trust level 3 and higher\n* Hide spam with a single flag\n\nHere's the [current list of fellow regulars](/badges/3/regular). Be sure to say hi.\n\nThanks for being an important part of this community!\n\n(For more information on trust levels, [see this topic][trust]. Please note that only members who continue to meet the requirements over time will remain regulars.)\n\n[trust]: https://meta.discourse.org/t/what-do-user-trust-levels-do/4924	<p>Congratulations! <img src="//jnu-developer.com/plugins/emoji/images/confetti_ball.png" title=":confetti_ball:" class="emoji" alt="confetti_ball" width="64" height="64"></p>\n\n<p>If you can see this topic, you were recently promoted to <strong>regular</strong> (trust level 3).</p>\n\n<p>You can now …</p>\n\n<ul>\n<li>Edit the title of any topic</li>\n<li>Change the category of any topic</li>\n<li>Have all your links followed (<a href="http://en.wikipedia.org/wiki/Nofollow">automatic nofollow</a> is removed)</li>\n<li>Access a private Lounge category only visible to users at trust level 3 and higher</li>\n<li>Hide spam with a single flag</li>\n</ul>\n\n<p>Here's the <a href="/badges/3/regular">current list of fellow regulars</a>. Be sure to say hi.</p>\n\n<p>Thanks for being an important part of this community!</p>\n\n<p>(For more information on trust levels, <a href="https://meta.discourse.org/t/what-do-user-trust-levels-do/4924">see this topic</a>. Please note that only members who continue to meet the requirements over time will remain regulars.)</p>	2014-11-01 07:31:06.046818	2014-11-01 07:31:06.046818	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	-1	f	\N	0	0	0	0	2014-11-01 07:31:06.055335	f	\N	0	0	0	\N	\N	133	1	1	f	2014-11-01 07:31:06.046718	1	\N	0	f	f	\N	1
14	1	11	1	本分类用于发布有关本站管理和运行的通知,公告及相关条款.	<p>本分类用于发布有关本站管理和运行的通知,公告及相关条款.</p>	2014-11-01 07:55:27.182161	2014-11-01 07:56:33.968432	\N	0	0	2014-11-01 07:58:21.092486	0	0	0	0	\N	0.200000000000000011	1	1	0	1	1	f	\N	0	0	0	0	2014-11-01 07:55:27.192561	f	\N	0	0	0	1	\N	0	1	1	f	2014-11-01 07:56:33.968055	1	\N	2	f	f	\N	1
15	1	12	1	[用一段简短的话描述分类，并替换这第一段的内容。这段文字将出现在分类选择区域，所以尽量不要超过200个字符。当您编辑了这段文字或者再次分类创建了一个主题后，分类才会出现在分类列表中。]\n\n在接下来的一段文字中输入分类的详细描述信息，可以在这里包含在此分类下讨论的规则、内容导向等等。\n\n考虑这些事情：\n\n- 这个分类用来做什么？ 为什么人们选择这个分类寻找主题？\n\n- 这个分类和其他已有分类有什么不同？\n\n- 我们需要这个分类么？\n\n- 我们应该和已有分类合并吗？还是分离成更多的分类？\n	<p>[用一段简短的话描述分类，并替换这第一段的内容。这段文字将出现在分类选择区域，所以尽量不要超过200个字符。当您编辑了这段文字或者再次分类创建了一个主题后，分类才会出现在分类列表中。]</p>\n\n<p>在接下来的一段文字中输入分类的详细描述信息，可以在这里包含在此分类下讨论的规则、内容导向等等。</p>\n\n<p>考虑这些事情：</p>\n\n<ul><li><p>这个分类用来做什么？ 为什么人们选择这个分类寻找主题？</p></li><li><p>这个分类和其他已有分类有什么不同？</p></li><li><p>我们需要这个分类么？</p></li><li><p>我们应该和已有分类合并吗？还是分离成更多的分类？</p></li></ul>	2014-11-01 08:00:55.771201	2014-11-01 08:00:55.771201	\N	0	0	\N	0	0	2	0	\N	10	0	1	0	1	1	f	\N	0	0	0	0	2014-11-01 08:00:55.781599	f	\N	0	0	0	\N	\N	1	1	1	f	2014-11-01 08:00:55.771037	1	\N	0	f	f	\N	1
17	1	14	1	##蟒营开营纪要##\n\n###概述###\n- 时间:2014/11/8 14:30~18:00\n- 地点:暨南大学珠海校区教702\n- 参与人员:\n    + 学员:15+\n    + 导师:Zoom.Quiet(下面简称大妈)\n- 提出作品:5个\n\n###流程###\n####1. 自我介绍:\n\n+ 姓名和所读的专业\n+ 同时说出自己认为在接下去的蟒营活动中会面临的问题,其中一些主要问题如下:\n    - 团队之间的沟通、学员与导师的沟通.\n    - 零基础.\n    - 编程方面的不熟悉.\n    - 担心毅力不够.\n\n####2. 大妈对上述提问逐个回答:\n\n> 团队之间的沟通、学员与导师的沟通\n\n\n团队间每次就项目问题进行沟通时最好是面对面地沟通,把话讲明白,一起弄清楚每周、每天、每个人要做的事情.\n\n而学员与老师的沟通最好是以邮件的形式(参考markdown语法:http://wowubuntu.com/markdown/ )进行.\n\n在问问题时,学员一定要把问题阐述得尽量详细,并且最好不要问一些过于简单的问题.提问要显真诚.  \n参考:<提问的智慧>  \n    http://wiki.woodpecker.org.cn/moin/AskForHelp)  \n参考:珠的自白:34 如何提问?才对世界有帮助!  \n    http://blog.zhgdg.org/2014-10/dm34-how2ask/  \n\n> 零基础\n> 编程方面的不熟悉.\n\n对于零基础和编程方面的问题，大妈认为这问题不大,因为Python本身就是让大家从同一起点开始学起，所以不要有太多的顾虑，只要每天都合理地抽出时间来自学，不懂的问题请教导师，那么就可以.\n\n> 担心毅力不够.\n\n大妈认为,来到这里的人,都是对编程有或大或小的兴趣.只要有兴趣并且热爱它,你就可以坚持下去.\n\n而要做到不断地把自己的激情上扬,就要切实地做到完成每天的任务,然后慢慢地看到自己不断在进步,看到自己的小成就出现,你就会更加热爱,从而就坚持到底.\n\n####3. 大妈讲述工具的重要性\n软件开发过程中三大要素:gitcafe、wiki文档、issue.  \n    在往后的项目介绍中，主要以wiki文档的形式呈现，更好地把项目的进度、问题等展示出来.\n  \n参考:珠海GDG 社区知识管理 指南\n    http://blog.zhgdg.org/2014-09/km4gdg-guider/  \n    因为好工具,或是对不同工具/渠道/平台的使用,配合,才可能持续提高团队的沟通效率;\n\n####4. 讲述蟒营流程(迭代计划)\n- 周报,每周一次公开演示\n- 日报,都向 蠎营 列表给出\n    - 养成习惯,进入工作后,就不会对周报有厌烦心理了\n    - 同时,这也有很多连带好处,其中,最关键的一个就是\n        - 自然形成了自身能力增长的感知\n        - 知道相似任务,自个儿的工作实际效率\n        - 对团队的承诺将越来越精确\n        - 即靠谱起来 ;-)\n- 大妈建议:\n    + 周日:用来review上周所完成的任务\n    + 周一周二:构思自己本周任务、对项目的进一步改造(认为构思才是项目开发中最重要的部分)\n        - 构思包含了实验\n        - 得通过实际代码的运行,才能印证自个儿的想法是否可行的哪...\n        - 所以,这时,就不是一个人的事儿了\n        - 自然的应该是全组,分工,分头实践不同的方案,最终,在限定时间里 谁的多快好省就用谁的,然后,那个谁 来快速教授其它同学明白怎么折腾\n        - 只有能教会其它人,才能证明你真的掌握了以为掌握的东西.\n    + 周三:编程(会遇到的最大问题：给函数取名)\n         - 这是一个程序员,一生都无法解决的终极问题!\n         - 也是人的思想和现实世界沟通时的核心矛盾.\n    + 周四周五:测试,发现问题并解决问题\n    + 周六:公开演示(演示时间视具体情况而定)\n####5. 学员各自组团,进行半小时多的头脑风暴\n\n####6. 项目介绍与点评\n#####1. 作品名称:管家婆(housekeeper)\n- 要解决的问题:处理宿舍一些财务、事情安排等内务问题,同时也解决生活上由于地域不同等的不适应问题.\n- 形式：app\n- 分工：提醒 表格 彩蛋\n- 迭代计划：\n    + 第一周--制作表格 \n    + 第二周--设置提醒 \n    + 第三周--加入彩蛋 \n    + 第四周--暂未定\n- 组员:严平安 何振宇 张子豪\n- 点评:\n    - 解决了实际问题,开发的工程量也不大,完全可以.\n    - 只是放置的重点不应该在功能处理上,而是应该在数据处理上.\n    - 可以把表格设计放在最后\n    - 同样的,建议使用 微信后台服务 来以一个 公众号的形式,提供服务\n    - 省去大量的辅助功能的开发工作量\n\n#####2. 作品名称:快客(Quick)\n- 要解决的问题: 帮助大家在每个学期能快速地抢课,设置几个志愿,以志愿优先选课原则进行.\n- 形式: 桌面软件\n- 技术难题: 自助服务的设定\n- 分工: 暂未定\n- 迭代演示: 暂未定\n- 组员: 潘琦 黄嘉欣 廖颖湳\n- 点评：\n    - 切实地解决大学中的一些问题.\n    - 但抢课系统不是每天都会开,后期没有办法进行测试,因此没有办法证明最终这个软件是否抢课成功.\n\nPS:\n这一组的Quick已换成 书友(Bookfriend):\n\n- 作品名称: 书友(Bookfriend)\n- 要解决的问题: 让学生更方便的共享书籍\n- 形式: app\n- 技术难题: 暂未定\n- 分工: 功能设计、程序设计、整体界面设计\n- 迭代演示: 暂未定\n- 组员: 潘琦 黄嘉欣 廖颖湳\n\n#####3. 作品名称:邮泡(mailpop)\n- 要解决的问题:让邮件以图形的形式呈现出来\n- 形式:app\n- 技术难题：要涉及Pop3协议\n- 分工:前段设计（用户界面设计、邮件收发协议） pop3\n- 迭代演示：\n    + 第一周--GUI \n    + 第二周--邮件收发协议 \n    + 第三周--pop3 \n    + 第四周--设定小功能\n- 组员：卢星宇 郭东锐 段欣\n- 点评：\n    + 邮件协议比较复杂,可能百分之八十都是GUI的代码,但是蛮有趣.有创意,可以尝试\n    + 只要能实现最有创意的, 以通讯录为线索的 聊天式邮件查阅功能, 就是成功\n    + 其它的常见功能,根本不应该是开发重点\n\n#####4. 作品名称:乐帮帮(happy helper)\n- 要解决的问题:帮助特定时间有特定事情的人(如帮拿快递,帮打饭,帮寄信),同时也可以找人一起吃饭,组团去玩等\n- 形式:app\n- 技术难题:聊天界面程序的设定（目前已改为 通知程序的设定）\n- 分工：界面 发帖 回馈（游戏） 加些其他元素（动漫）\n- 迭代演示：\n    + 第一周--界面 \n    + 第二周--发帖设定 \n    + 第三周--回馈部分的加入 \n    + 第四周--加一些其他元素\n- 组员：卓洁 李露 杨雅希 高琳 汤楚雯\n- 点评：\n    + 如果是apps,且技术问题放在聊天界面上，则不太现实，因为这样大众可以直接用微信等而不需要用你们的产品.\n    + 关键要放在ux(用户体验过程)中,把业务简化为任务发布、任务接收、任务关闭。\n    + 第一时间,可用,可感知什么是 分享时间 的任务系统, 才是最要命的\n    + 同样的,没有功能的界面,再漂亮也无用\n    + 建议迭代顺序:\n       - w1 定义明确服务流程, 给出可演示的 app 原型\n       - w2 探索技术方案, 选定成本最小的那种\n       - w3 完成核心流程, 可真实完成经典的任务发布/认领/完成 的流程\n       - w4 提高使用体验, 兼容意外情况\n       - w5 专注发布, 建立运营机制, 可以快速升级系统\n    + 同样的,建议使用 微信后台服务 来以一个 公众号的形式,提供服务\n      - 省去大量的辅助功能的开发工作量\n\n#####5. 作品名称:m阅(mread)\n- 要解决的问题:可直接编辑阅读的内容,不限定txt格式,就是也可以看ppt格式等,加入听书功能等\n- 形式:app\n- 技术难题:暂未定\n- 分工:暂未定\n- 迭代演示:暂未定\n- 组员:李科健 肖克雅 卢晋炜\n- 点评:\n    - 手机的阅读软件的运算量等非常有限,阅读软件要开发得好所需的时间较长.\n    - 在手机上面设置这样的阅读功能不太必要,解决的问题不是很关键.\n\nPS:这一组作品已换成 组我吧\n\n- 作品名称：组我吧（Take me up）\n- 要解决的问题:各种校园比赛组队找不着人的问题。\n- 技术难题:一是聊天功能的实现，二是用户帐户的管理\n- 分工:UI设计  功能模块实现\n- 迭代演示:\n    + 第一周--设计好UI框架和功能  \n    + 第二周--着手实现UI   \n    + 第三周--实现功能模块  \n    + 第四周--完善\n- 组员:李科健 肖克雅 卢晋炜\n\n#### 大妈反复强调 工具 的重要性\n应该说是全程反复强调 工具 的重要性\n\n- 人之所以为人,就是比动物能 发明/使用 工具\n- 工具 实际上包含了一系列高效工作习惯\n- 但是,并不存在一种工具,辞行所有工作\n- 特别是计算机领域\n    - 程序员 是世界上唯一一种,以消灭自身所在行业为目标 的行业\n    - 程序员 一直在下死力发明能节省时间/脑力,自动化的工具\n    - 所以, 想进入这一行业,对新工具不能快速上手,领悟要着,合理使用\n    永远只能是小工,不是工程师\n\n> *要尽量做到每周都有作品可以演示，比如第一周演示的作品不仅可以以PPT的形式演示，也可以手绘的形式演示出软件的操作进行过程\n\n- 以及移动领域,有大量的 原型 工具\n    - 比如 POP\n\n- markdown和git是要重点掌握的工具\n    + 对于 app 应该尝试 QPython\n    + 对于网站式服务  bottle 值得使用\n\n- 推荐学习Python的书:\n    + <<笨办法学Python>> http://sebug.net/paper/books/LearnPythonTheHardWay/\n    + <<像计算机科学家一样思考Python>> http://www.greenteapress.com/thinkpython/thinkCSpy.pdf\n\n#### 附录:各项目gitcafe仓库\n1. 管家婆: https://gitcafe.com/PythoniCamp/housekeeper\n2. 书友: https://gitcafe.com/PythoniCamp/Bookfriend\n3. 邮泡: https://gitcafe.com/PythoniCamp/Mailpop\n4. 乐帮帮: https://gitcafe.com/PythoniCamp/happyhelp\n5. 组我吧: https://gitcafe.com/PythoniCamp/Takemeup\n\n####附录:录音\nhttp://zoomq.qiniudn.com/CPyUG/PythoniCamp/141108-jnu-start/	<h2>蟒营开营纪要</h2>\n\n<h3>概述</h3>\n\n<ul>\n<li>时间:2014/11/8 14:30~18:00</li>\n<li>地点:暨南大学珠海校区教702</li>\n<li>参与人员:<ul>\n<li>学员:15+</li>\n<li>导师:Zoom.Quiet(下面简称大妈)</li>\n</ul>\n</li>\n<li>提出作品:5个</li>\n</ul>\n\n<h3>流程</h3>\n\n<h4>1. 自我介绍:</h4>\n\n<ul>\n<li>姓名和所读的专业</li>\n<li>同时说出自己认为在接下去的蟒营活动中会面临的问题,其中一些主要问题如下:<ul>\n<li>团队之间的沟通、学员与导师的沟通.</li>\n<li>零基础.</li>\n<li>编程方面的不熟悉.</li>\n<li>担心毅力不够.</li>\n</ul>\n</li>\n</ul>\n\n<h4>2. 大妈对上述提问逐个回答:</h4>\n\n<blockquote><p>团队之间的沟通、学员与导师的沟通</p></blockquote>\n\n<p>团队间每次就项目问题进行沟通时最好是面对面地沟通,把话讲明白,一起弄清楚每周、每天、每个人要做的事情.</p>\n\n<p>而学员与老师的沟通最好是以邮件的形式(参考markdown语法:http://wowubuntu.com/markdown/ )进行.</p>\n\n<p>在问问题时,学员一定要把问题阐述得尽量详细,并且最好不要问一些过于简单的问题.提问要显真诚.<br>参考:&lt;提问的智慧&gt;<br>    <a href="http://wiki.woodpecker.org.cn/moin/AskForHelp">http://wiki.woodpecker.org.cn/moin/AskForHelp</a>)<br>参考:珠的自白:34 如何提问?才对世界有帮助!<br>    <a href="http://blog.zhgdg.org/2014-10/dm34-how2ask/">http://blog.zhgdg.org/2014-10/dm34-how2ask/</a>  </p>\n\n<blockquote><p>零基础<br>编程方面的不熟悉.</p></blockquote>\n\n<p>对于零基础和编程方面的问题，大妈认为这问题不大,因为Python本身就是让大家从同一起点开始学起，所以不要有太多的顾虑，只要每天都合理地抽出时间来自学，不懂的问题请教导师，那么就可以.</p>\n\n<blockquote><p>担心毅力不够.</p></blockquote>\n\n<p>大妈认为,来到这里的人,都是对编程有或大或小的兴趣.只要有兴趣并且热爱它,你就可以坚持下去.</p>\n\n<p>而要做到不断地把自己的激情上扬,就要切实地做到完成每天的任务,然后慢慢地看到自己不断在进步,看到自己的小成就出现,你就会更加热爱,从而就坚持到底.</p>\n\n<h4>3. 大妈讲述工具的重要性</h4>\n\n<p>软件开发过程中三大要素:gitcafe、wiki文档、issue.<br>    在往后的项目介绍中，主要以wiki文档的形式呈现，更好地把项目的进度、问题等展示出来.</p>\n\n<p>参考:珠海GDG 社区知识管理 指南<br>    <a href="http://blog.zhgdg.org/2014-09/km4gdg-guider/">http://blog.zhgdg.org/2014-09/km4gdg-guider/</a><br>    因为好工具,或是对不同工具/渠道/平台的使用,配合,才可能持续提高团队的沟通效率;</p>\n\n<h4>4. 讲述蟒营流程(迭代计划)</h4>\n\n<ul>\n<li>周报,每周一次公开演示</li>\n<li>日报,都向 蠎营 列表给出<ul>\n<li>养成习惯,进入工作后,就不会对周报有厌烦心理了</li>\n<li>同时,这也有很多连带好处,其中,最关键的一个就是<ul>\n<li>自然形成了自身能力增长的感知</li>\n<li>知道相似任务,自个儿的工作实际效率</li>\n<li>对团队的承诺将越来越精确</li>\n<li>即靠谱起来 <img src="//jnu-developer.com/plugins/emoji/images/wink.png" title=":wink:" class="emoji" alt="wink" width="64" height="64">\n</li>\n</ul>\n</li>\n</ul>\n</li>\n<li>大妈建议:<ul>\n<li>周日:用来review上周所完成的任务</li>\n<li>周一周二:构思自己本周任务、对项目的进一步改造(认为构思才是项目开发中最重要的部分)<ul>\n<li>构思包含了实验</li>\n<li>得通过实际代码的运行,才能印证自个儿的想法是否可行的哪...</li>\n<li>所以,这时,就不是一个人的事儿了</li>\n<li>自然的应该是全组,分工,分头实践不同的方案,最终,在限定时间里 谁的多快好省就用谁的,然后,那个谁 来快速教授其它同学明白怎么折腾</li>\n<li>只有能教会其它人,才能证明你真的掌握了以为掌握的东西.</li>\n</ul>\n</li>\n<li>周三:编程(会遇到的最大问题：给函数取名)<ul>\n<li>这是一个程序员,一生都无法解决的终极问题!</li>\n<li>也是人的思想和现实世界沟通时的核心矛盾.</li>\n</ul>\n</li>\n<li>周四周五:测试,发现问题并解决问题</li>\n<li>周六:公开演示(演示时间视具体情况而定)</li>\n</ul>\n</li>\n</ul>\n\n<h4>5. 学员各自组团,进行半小时多的头脑风暴</h4>\n\n<h4>6. 项目介绍与点评</h4>\n\n<h5>1. 作品名称:管家婆(housekeeper)</h5>\n\n<ul>\n<li>要解决的问题:处理宿舍一些财务、事情安排等内务问题,同时也解决生活上由于地域不同等的不适应问题.</li>\n<li>形式：app</li>\n<li>分工：提醒 表格 彩蛋</li>\n<li>迭代计划：<ul>\n<li>第一周--制作表格 </li>\n<li>第二周--设置提醒 </li>\n<li>第三周--加入彩蛋 </li>\n<li>第四周--暂未定</li>\n</ul>\n</li>\n<li>组员:严平安 何振宇 张子豪</li>\n<li>点评:<ul>\n<li>解决了实际问题,开发的工程量也不大,完全可以.</li>\n<li>只是放置的重点不应该在功能处理上,而是应该在数据处理上.</li>\n<li>可以把表格设计放在最后</li>\n<li>同样的,建议使用 微信后台服务 来以一个 公众号的形式,提供服务</li>\n<li>省去大量的辅助功能的开发工作量</li>\n</ul>\n</li>\n</ul>\n\n<h5>2. 作品名称:快客(Quick)</h5>\n\n<ul>\n<li>要解决的问题: 帮助大家在每个学期能快速地抢课,设置几个志愿,以志愿优先选课原则进行.</li>\n<li>形式: 桌面软件</li>\n<li>技术难题: 自助服务的设定</li>\n<li>分工: 暂未定</li>\n<li>迭代演示: 暂未定</li>\n<li>组员: 潘琦 黄嘉欣 廖颖湳</li>\n<li>点评：<ul>\n<li>切实地解决大学中的一些问题.</li>\n<li>但抢课系统不是每天都会开,后期没有办法进行测试,因此没有办法证明最终这个软件是否抢课成功.</li>\n</ul>\n</li>\n</ul>\n\n<p>PS:<br>这一组的Quick已换成 书友(Bookfriend):</p>\n\n<ul>\n<li>作品名称: 书友(Bookfriend)</li>\n<li>要解决的问题: 让学生更方便的共享书籍</li>\n<li>形式: app</li>\n<li>技术难题: 暂未定</li>\n<li>分工: 功能设计、程序设计、整体界面设计</li>\n<li>迭代演示: 暂未定</li>\n<li>组员: 潘琦 黄嘉欣 廖颖湳</li>\n</ul>\n\n<h5>3. 作品名称:邮泡(mailpop)</h5>\n\n<ul>\n<li>要解决的问题:让邮件以图形的形式呈现出来</li>\n<li>形式:app</li>\n<li>技术难题：要涉及Pop3协议</li>\n<li>分工:前段设计（用户界面设计、邮件收发协议） pop3</li>\n<li>迭代演示：<ul>\n<li>第一周--GUI </li>\n<li>第二周--邮件收发协议 </li>\n<li>第三周--pop3 </li>\n<li>第四周--设定小功能</li>\n</ul>\n</li>\n<li>组员：卢星宇 郭东锐 段欣</li>\n<li>点评：<ul>\n<li>邮件协议比较复杂,可能百分之八十都是GUI的代码,但是蛮有趣.有创意,可以尝试</li>\n<li>只要能实现最有创意的, 以通讯录为线索的 聊天式邮件查阅功能, 就是成功</li>\n<li>其它的常见功能,根本不应该是开发重点</li>\n</ul>\n</li>\n</ul>\n\n<h5>4. 作品名称:乐帮帮(happy helper)</h5>\n\n<ul>\n<li>要解决的问题:帮助特定时间有特定事情的人(如帮拿快递,帮打饭,帮寄信),同时也可以找人一起吃饭,组团去玩等</li>\n<li>形式:app</li>\n<li>技术难题:聊天界面程序的设定（目前已改为 通知程序的设定）</li>\n<li>分工：界面 发帖 回馈（游戏） 加些其他元素（动漫）</li>\n<li>迭代演示：<ul>\n<li>第一周--界面 </li>\n<li>第二周--发帖设定 </li>\n<li>第三周--回馈部分的加入 </li>\n<li>第四周--加一些其他元素</li>\n</ul>\n</li>\n<li>组员：卓洁 李露 杨雅希 高琳 汤楚雯</li>\n<li>点评：<ul>\n<li>如果是apps,且技术问题放在聊天界面上，则不太现实，因为这样大众可以直接用微信等而不需要用你们的产品.</li>\n<li>关键要放在ux(用户体验过程)中,把业务简化为任务发布、任务接收、任务关闭。</li>\n<li>第一时间,可用,可感知什么是 分享时间 的任务系统, 才是最要命的</li>\n<li>同样的,没有功能的界面,再漂亮也无用</li>\n<li>建议迭代顺序:<ul>\n<li>w1 定义明确服务流程, 给出可演示的 app 原型</li>\n<li>w2 探索技术方案, 选定成本最小的那种</li>\n<li>w3 完成核心流程, 可真实完成经典的任务发布/认领/完成 的流程</li>\n<li>w4 提高使用体验, 兼容意外情况</li>\n<li>w5 专注发布, 建立运营机制, 可以快速升级系统</li>\n</ul>\n</li>\n<li>同样的,建议使用 微信后台服务 来以一个 公众号的形式,提供服务<ul><li>省去大量的辅助功能的开发工作量</li></ul>\n</li>\n</ul>\n</li>\n</ul>\n\n<h5>5. 作品名称:m阅(mread)</h5>\n\n<ul>\n<li>要解决的问题:可直接编辑阅读的内容,不限定txt格式,就是也可以看ppt格式等,加入听书功能等</li>\n<li>形式:app</li>\n<li>技术难题:暂未定</li>\n<li>分工:暂未定</li>\n<li>迭代演示:暂未定</li>\n<li>组员:李科健 肖克雅 卢晋炜</li>\n<li>点评:<ul>\n<li>手机的阅读软件的运算量等非常有限,阅读软件要开发得好所需的时间较长.</li>\n<li>在手机上面设置这样的阅读功能不太必要,解决的问题不是很关键.</li>\n</ul>\n</li>\n</ul>\n\n<p>PS:这一组作品已换成 组我吧</p>\n\n<ul>\n<li>作品名称：组我吧（Take me up）</li>\n<li>要解决的问题:各种校园比赛组队找不着人的问题。</li>\n<li>技术难题:一是聊天功能的实现，二是用户帐户的管理</li>\n<li>分工:UI设计  功能模块实现</li>\n<li>迭代演示:<ul>\n<li>第一周--设计好UI框架和功能  </li>\n<li>第二周--着手实现UI   </li>\n<li>第三周--实现功能模块  </li>\n<li>第四周--完善</li>\n</ul>\n</li>\n<li>组员:李科健 肖克雅 卢晋炜</li>\n</ul>\n\n<h4>大妈反复强调 工具 的重要性</h4>\n\n<p>应该说是全程反复强调 工具 的重要性</p>\n\n<ul>\n<li>人之所以为人,就是比动物能 发明/使用 工具</li>\n<li>工具 实际上包含了一系列高效工作习惯</li>\n<li>但是,并不存在一种工具,辞行所有工作</li>\n<li>特别是计算机领域<ul>\n<li>程序员 是世界上唯一一种,以消灭自身所在行业为目标 的行业</li>\n<li>程序员 一直在下死力发明能节省时间/脑力,自动化的工具</li>\n<li>所以, 想进入这一行业,对新工具不能快速上手,领悟要着,合理使用<br>永远只能是小工,不是工程师</li>\n</ul>\n</li>\n</ul>\n\n<blockquote><p>*要尽量做到每周都有作品可以演示，比如第一周演示的作品不仅可以以PPT的形式演示，也可以手绘的形式演示出软件的操作进行过程</p></blockquote>\n\n<ul>\n<li>以及移动领域,有大量的 原型 工具<ul><li>比如 POP</li></ul>\n</li>\n<li>\n<p>markdown和git是要重点掌握的工具</p>\n<ul>\n<li>对于 app 应该尝试 QPython</li>\n<li>对于网站式服务  bottle 值得使用</li>\n</ul>\n</li>\n<li>\n<p>推荐学习Python的书:</p>\n<ul>\n<li>&lt;&lt;笨办法学Python&gt;&gt; <a href="http://sebug.net/paper/books/LearnPythonTheHardWay/">http://sebug.net/paper/books/LearnPythonTheHardWay/</a>\n</li>\n<li>&lt;&lt;像计算机科学家一样思考Python&gt;&gt; <a href="http://www.greenteapress.com/thinkpython/thinkCSpy.pdf">http://www.greenteapress.com/thinkpython/thinkCSpy.pdf</a>\n</li>\n</ul>\n</li>\n</ul>\n\n<h4>附录:各项目gitcafe仓库</h4>\n\n<ol>\n<li>管家婆: <a href="https://gitcafe.com/PythoniCamp/housekeeper">https://gitcafe.com/PythoniCamp/housekeeper</a>\n</li>\n<li>书友: <a href="https://gitcafe.com/PythoniCamp/Bookfriend">https://gitcafe.com/PythoniCamp/Bookfriend</a>\n</li>\n<li>邮泡: <a href="https://gitcafe.com/PythoniCamp/Mailpop">https://gitcafe.com/PythoniCamp/Mailpop</a>\n</li>\n<li>乐帮帮: <a href="https://gitcafe.com/PythoniCamp/happyhelp">https://gitcafe.com/PythoniCamp/happyhelp</a>\n</li>\n<li>组我吧: <a href="https://gitcafe.com/PythoniCamp/Takemeup">https://gitcafe.com/PythoniCamp/Takemeup</a>\n</li>\n</ol>\n\n<h4>附录:录音</h4>\n\n<p><a href="http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141108-jnu-start/" class="onebox" target="_blank">http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141108-jnu-start/</a></p>	2014-11-12 16:38:55.179517	2014-11-12 16:39:09.374168	\N	0	0	\N	0	0	4	0	\N	20.1999999999999993	1	1	0	1	1	f	\N	0	0	0	0	2014-11-12 16:38:55.222728	f	\N	0	0	0	\N	\N	160	1	1	f	2014-11-12 16:39:09.369407	1	\N	1	f	f	\N	1
22	1	18	1	##蟒营迭代演示W1##\n \n###概述###\n- 时间：11月16日下午15:00-18:00\n- 地点：暨南大学珠海校区教409\n- 参与人员：\n        + 蟒营学员：20+\n        + 导师：Zoom.Quiet(以下简称“大妈”)\n \n \n###流程###\n####1.大妈发言，讲明本周迭代演示所要介绍的事项:\n\n- 产品名称\n- 谁做了什么\n- 下周做什么\n\n在此之前，投影仪出现了问题，由此引发大妈呼吁学员要获得完整的高等教育。\n \n####2.演示调试（两组进行参与）\n- 组我吧：试图通过网络进行,但网速过慢,未成功\n- 管家婆：调试基本成功。（但准备演示的只一个在台上准备）\n\n- 调试完毕，大妈由此提出：\n> 任何形式的演示都可以\n> 要学会换角色思考问题和解决问题:\n> \n>    - 投资人vs创业人\n>    - 大妈vs学员\n>    - 公司年会vs参请资源的员工   \n> 维系团队，否则无效。加强团队之间的沟通，学会开会，以邮件或文档的形式在组员间交流一些问题，提高工作效率  \n> 再次强调提问方面的问题。参考《提问的智慧》:http://www.oyonyou.com/  thread-3669-1-1.html\n> 谨记：多做做错，不做不错，不做终会，一做就错\n \n####3.访谈\n\n- 每个学员进行发言\n- 内容：\n    - 我是谁？我在组里做什么？\n    - 上周我们组做什么？\n    - 什么做得好？有什么不好的地方？\n    - 下周要做什么？\n \n####4.正式演示\n - #####内容：\n    - 说清哪组几人\n    - 上周做了什么\n    - 什么是最大的困难\n    - 下周做什么\n    \n - #####项目：管家婆（3人）\n   - 上周已完成：财务管理的设定\n   - 上周最大问题：存储用户信息的设置\n   - 解决方案：继续学习Python，编辑文档\n   - 分工：用户界面   \n   - 下周：实现记忆功能\n   - 存在的问题：\n\n    * 只要按依照、提示两方面去做\n    * 修改性较弱\n    * 权限设置方面\n\n-  #####项目：乐帮帮(happyhelper)（5人）\n   - 上周已完成:功能的确定、界面的设计\n   - 上周最大问题：不知道如何把app变成软件\n   -  解决方案：加紧Python的学习        \n   - 下周：学习Python、争取交出app的模型\n\n- #####项目：邮泡（mail pop)（4人）\n    - 上周已完成：一部分代码、原型设计、学习Python\n    - 上周最大问题：积极性不高\n    - 下周：继续学习Python             \n\n- #####项目：组我吧（Take me up）（2人）\n    - 上周已完成：SAE申请，微信公众号“组我吧”通过验证，并通过了开发者模式\n    - 上周最大问题：Token验证无法通过（已经解决）\n    - 下周：\n        * 学习Python微信公众平台开发教程（Web框架，XML相关知识）\n        * 完成自动回复用户消息功能\n        * 争取初步实现“组我吧”核心功能\n\n- #####项目：书友（bookfriend）\n     - 上周已完成：功能和界面的确定\n     - 上周最大问题：暂未知\n     - 下周：暂未知（周报未写）\n \n \n#### 5.大妈总结:\n\n > 坚持团队分工  \n > 坚持smart原则,可验证.  \n > 争取发日报,投入精力,让项目更易完成  \n > 代码为客观依据  \n > 分配任务:根据性格、能力分配  \n > 学会寻途径(导师,同学,图书馆)来解决问题  \n > 命令行、基础、数据库（文本当数据库略麻烦）   \n      \n####6.提问环节(无人提问)\n - 大妈提出\n  > 要以代码为"我学了"的依据  \n  > 团队要有周报(做什么、下周做什么、最大困难是什么)\n\n###附录###\n录音:http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141116-jnu-w1/	<h2>蟒营迭代演示W1</h2>\n\n<h3>概述</h3>\n\n<ul>\n<li>时间：11月16日下午15:00-18:00</li>\n<li>地点：暨南大学珠海校区教409</li>\n<li>参与人员：<br>    + 蟒营学员：20+<br>    + 导师：Zoom.Quiet(以下简称“大妈”)</li>\n</ul>\n\n<h3>流程</h3>\n\n<h4>1.大妈发言，讲明本周迭代演示所要介绍的事项:</h4>\n\n<ul>\n<li>产品名称</li>\n<li>谁做了什么</li>\n<li>下周做什么</li>\n</ul>\n\n<p>在此之前，投影仪出现了问题，由此引发大妈呼吁学员要获得完整的高等教育。</p>\n\n<h4>2.演示调试（两组进行参与）</h4>\n\n<ul>\n<li>组我吧：试图通过网络进行,但网速过慢,未成功</li>\n<li><p>管家婆：调试基本成功。（但准备演示的只一个在台上准备）</p></li>\n<li>\n<p>调试完毕，大妈由此提出：</p>\n<blockquote>\n<p>任何形式的演示都可以<br>要学会换角色思考问题和解决问题:</p>\n<ul>\n<li>投资人vs创业人</li>\n<li>大妈vs学员</li>\n<li>公司年会vs参请资源的员工 <br>维系团队，否则无效。加强团队之间的沟通，学会开会，以邮件或文档的形式在组员间交流一些问题，提高工作效率<br>再次强调提问方面的问题。参考《提问的智慧》:http://www.oyonyou.com/  thread-3669-1-1.html<br>谨记：多做做错，不做不错，不做终会，一做就错</li>\n</ul>\n</blockquote>\n</li>\n</ul>\n\n<h4>3.访谈</h4>\n\n<ul>\n<li>每个学员进行发言</li>\n<li>内容：<ul>\n<li>我是谁？我在组里做什么？</li>\n<li>上周我们组做什么？</li>\n<li>什么做得好？有什么不好的地方？</li>\n<li>下周要做什么？</li>\n</ul>\n</li>\n</ul>\n\n<h4>4.正式演示</h4>\n\n<ul>\n<li>#####内容：<ul>\n<li>说清哪组几人</li>\n<li>上周做了什么</li>\n<li>什么是最大的困难</li>\n<li>下周做什么</li>\n</ul>\n</li>\n<li>\n<p>#####项目：管家婆（3人）</p>\n<ul>\n<li>上周已完成：财务管理的设定</li>\n<li>上周最大问题：存储用户信息的设置</li>\n<li>解决方案：继续学习Python，编辑文档</li>\n<li>分工：用户界面   </li>\n<li>下周：实现记忆功能</li>\n<li>存在的问题：</li>\n</ul>\n</li>\n</ul>\n\n<pre><code>* 只要按依照、提示两方面去做\n* 修改性较弱\n* 权限设置方面</code></pre>\n\n<ul>\n<li>#####项目：乐帮帮(happyhelper)（5人）<ul>\n<li>上周已完成:功能的确定、界面的设计</li>\n<li>上周最大问题：不知道如何把app变成软件</li>\n<li>解决方案：加紧Python的学习        </li>\n<li>下周：学习Python、争取交出app的模型</li>\n</ul>\n</li>\n<li>\n<p>#####项目：邮泡（mail pop)（4人）</p>\n<ul>\n<li>上周已完成：一部分代码、原型设计、学习Python</li>\n<li>上周最大问题：积极性不高</li>\n<li>下周：继续学习Python             </li>\n</ul>\n</li>\n<li>\n<p>#####项目：组我吧（Take me up）（2人）</p>\n<ul>\n<li>上周已完成：SAE申请，微信公众号“组我吧”通过验证，并通过了开发者模式</li>\n<li>上周最大问题：Token验证无法通过（已经解决）</li>\n<li>下周：<ul>\n<li>学习Python微信公众平台开发教程（Web框架，XML相关知识）</li>\n<li>完成自动回复用户消息功能</li>\n<li>争取初步实现“组我吧”核心功能</li>\n</ul>\n</li>\n</ul>\n</li>\n<li>\n<p>#####项目：书友（bookfriend）</p>\n<ul>\n<li>上周已完成：功能和界面的确定</li>\n<li>上周最大问题：暂未知</li>\n<li>下周：暂未知（周报未写）</li>\n</ul>\n</li>\n</ul>\n\n<h4>5.大妈总结:</h4>\n\n<blockquote><p>坚持团队分工<br>坚持smart原则,可验证.<br>争取发日报,投入精力,让项目更易完成<br>代码为客观依据<br>分配任务:根据性格、能力分配<br>学会寻途径(导师,同学,图书馆)来解决问题<br>命令行、基础、数据库（文本当数据库略麻烦）   </p></blockquote>\n\n<h4>6.提问环节(无人提问)</h4>\n\n<ul><li>大妈提出<blockquote><p>要以代码为"我学了"的依据<br>团队要有周报(做什么、下周做什么、最大困难是什么)</p></blockquote>\n</li></ul>\n\n<h3>附录</h3>\n\n<p>录音:http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141116-jnu-w1/</p>	2014-11-30 15:36:39.970091	2014-11-30 15:37:22.537977	\N	0	0	\N	0	0	3	0	\N	15.1999999999999993	1	1	0	1	1	f	\N	0	0	0	0	2014-11-30 15:36:40.030074	f	\N	0	0	0	\N		62	1	1	f	2014-11-30 15:37:22.537597	1	\N	1	f	f	\N	1
23	1	19	1	##蟒营迭代演示W2##\n\n###概述###\n- 时间：11月22日下午15:00-17:30\n- 地点：暨南大学珠海校区教702\n- 参与人员：\n    - 蟒营学员：+10\n    - 旁听:+2\n    - 大妈:+1(Zoom.Quiet)\n\n###流程###\n1.演示（15:00-15:40）\n\n- 第一组:组我吧(Take me up) 2人\n   - 上周:开通了微信的注册号,设置了注册账号、组团等大致的基本功能\n   - 下周：完成多个项目的同时进行组团功能\n   - 最大困难:调试\n    - 大妈点评:\n    > - 现场问题 演示\n    > - 根本没有考虑到现场网络的事儿\n    > - 空口, 没有任何直觉说明来帮助大家理解 作品到底想作到什么\n\n- 第二组:邮泡(mailpop)4人\n    - 上周：完成邮件的接收，读取，新建，发送等基本功能，以及GUI的基本设计\n    - 下周：CLI与GUI之间的连接\n    - 难题：邮件察看方面\n\n- 第三组：乐帮帮（happyhelper）5人\n    - 上周：界面的设置显示\n    - 下周：发布、注册、登录等基本功能的实现\n    - 大妈点评: \n        > - 在成员没有统一提升 Python 能力到一定水平时,\n        > - 一周想完成以上功能,基本不可能哪\n        > - 现场给出的共同学习,当面互教 等等加强互动的措施,怎么样的计划下来了?\n    - 难题：在不同手机上显示的界面情况不一致\n        + 大妈:\n            > - 关键词再次给出:\n                响应式设计框架\n\n- 第四组：管家婆3人\n     - 上周：实现搜寻缴费记录功能，用字典管理实现存储用户帐号密码等\n     - 下周：学习关于网络方面的编程、GUI等问题\n     - 难题：数据库问题\n\n2.休息（15:40-15:50）\n\n3.大妈与学员面对面交谈（15:50-17:30）  \n> 坚持团队分工,缺乏沟通依旧是存在的主要问题  \n> 学会去使用工具库,而不要用QQ(解决不了问题)等  \n> 代码为客观依据  \n> 演示的时候希望能够以一个可用的实体操作系统来进行  \n> 命令行、基础、数据库  \n>\n\n4.本周退出的成员:\n\n潘琦、黄嘉欣、廖颖湳\n(原因将会以邮件的形式呈现)\n\n###备注###\n- 本次到达的成员有:  \n卢星宇\n段欣\n李露\n郭东锐\n卓洁\n林伟杰\n李科健\n严平安\n段文涛\n\n- 未到达的成员:  \n何振宇（不详）\n张子豪（不详）\n肖伟杰（不详）\n杨雅希（有课）\n高琳（外出）\n汤楚雯（回家）\n卢晋炜（不详）\n曾嵘（不详）\n杨霖霏（不详）\n\n大妈:\n> 所有不祥 的同学们,哪应该补个说明吧,,,  \n> 至少得 给同伴们一个说法哪\n\n###附录###\n录音:http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141101-jnu/141122-jnu-w2/index.html	<h2>蟒营迭代演示W2</h2>\n\n<h3>概述</h3>\n\n<ul>\n<li>时间：11月22日下午15:00-17:30</li>\n<li>地点：暨南大学珠海校区教702</li>\n<li>参与人员：<ul>\n<li>蟒营学员：+10</li>\n<li>旁听:+2</li>\n<li>大妈:+1(Zoom.Quiet)</li>\n</ul>\n</li>\n</ul>\n\n<h3>流程</h3>\n\n<p>1.演示（15:00-15:40）</p>\n\n<ul>\n<li>第一组:组我吧(Take me up) 2人<ul>\n<li>上周:开通了微信的注册号,设置了注册账号、组团等大致的基本功能</li>\n<li>下周：完成多个项目的同时进行组团功能</li>\n<li>最大困难:调试<ul><li>大妈点评:<blockquote><ul>\n<li>现场问题 演示</li>\n<li>根本没有考虑到现场网络的事儿</li>\n<li>空口, 没有任何直觉说明来帮助大家理解 作品到底想作到什么</li>\n</ul></blockquote>\n</li></ul>\n</li>\n</ul>\n</li>\n<li>\n<p>第二组:邮泡(mailpop)4人</p>\n<ul>\n<li>上周：完成邮件的接收，读取，新建，发送等基本功能，以及GUI的基本设计</li>\n<li>下周：CLI与GUI之间的连接</li>\n<li>难题：邮件察看方面</li>\n</ul>\n</li>\n<li>\n<p>第三组：乐帮帮（happyhelper）5人</p>\n<ul>\n<li>上周：界面的设置显示</li>\n<li>下周：发布、注册、登录等基本功能的实现</li>\n<li>大妈点评: <br>&gt; - 在成员没有统一提升 Python 能力到一定水平时,<br>&gt; - 一周想完成以上功能,基本不可能哪<br>&gt; - 现场给出的共同学习,当面互教 等等加强互动的措施,怎么样的计划下来了?</li>\n<li>难题：在不同手机上显示的界面情况不一致<ul><li>大妈:<blockquote><ul><li>关键词再次给出:<br>响应式设计框架</li></ul></blockquote>\n</li></ul>\n</li>\n</ul>\n</li>\n<li>\n<p>第四组：管家婆3人</p>\n<ul>\n<li>上周：实现搜寻缴费记录功能，用字典管理实现存储用户帐号密码等</li>\n<li>下周：学习关于网络方面的编程、GUI等问题</li>\n<li>难题：数据库问题</li>\n</ul>\n</li>\n</ul>\n\n<p>2.休息（15:40-15:50）</p>\n\n<p>3.大妈与学员面对面交谈（15:50-17:30）  </p>\n\n<blockquote><p>坚持团队分工,缺乏沟通依旧是存在的主要问题<br>学会去使用工具库,而不要用QQ(解决不了问题)等<br>代码为客观依据<br>演示的时候希望能够以一个可用的实体操作系统来进行<br>命令行、基础、数据库  </p></blockquote>\n\n<p>4.本周退出的成员:</p>\n\n<p>潘琦、黄嘉欣、廖颖湳<br>(原因将会以邮件的形式呈现)</p>\n\n<h3>备注</h3>\n\n<ul>\n<li><p>本次到达的成员有:<br>卢星宇<br>段欣<br>李露<br>郭东锐<br>卓洁<br>林伟杰<br>李科健<br>严平安<br>段文涛</p></li>\n<li><p>未到达的成员:<br>何振宇（不详）<br>张子豪（不详）<br>肖伟杰（不详）<br>杨雅希（有课）<br>高琳（外出）<br>汤楚雯（回家）<br>卢晋炜（不详）<br>曾嵘（不详）<br>杨霖霏（不详）</p></li>\n</ul>\n\n<p>大妈:</p>\n\n<blockquote><p>所有不祥 的同学们,哪应该补个说明吧,,,<br>至少得 给同伴们一个说法哪</p></blockquote>\n\n<h3>附录</h3>\n\n<p>录音:http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141101-jnu/141122-jnu-w2/index.html</p>	2014-11-30 15:55:18.735207	2014-11-30 15:55:18.735207	\N	0	0	\N	0	0	1	0	14	6.09999999999999964	2	1	0	1	1	f	\N	0	0	0	0	2014-11-30 15:55:18.773228	f	\N	0	0	0	\N	\N	57	1	1	f	2014-11-30 15:55:18.734966	1	\N	0	f	f	\N	1
18	1	15	1	##JDC的成立##\n-JDC成立于2014年下半年,由移动公司支持以及暨大珠区一群爱好编程的同学组成.\n##JDC的主要分类##\n-JDC分为移动MM成员和JDC成员,都以小组的形式来完成一个特定的项目,当然也可以自己发起项目.\n-每个小组都分为主程,测试,产品设计,美工四个方面的工作.\n##JDC现有主要活动##\n-由珠海GDG负责人周琦带领的蟒营学习活动.\n-移动MM的周汇报活动.	<h2>JDC的成立</h2>\n\n<p>-JDC成立于2014年下半年,由移动公司支持以及暨大珠区一群爱好编程的同学组成.</p>\n\n<h2>JDC的主要分类</h2>\n\n<p>-JDC分为移动MM成员和JDC成员,都以小组的形式来完成一个特定的项目,当然也可以自己发起项目.<br>-每个小组都分为主程,测试,产品设计,美工四个方面的工作.</p>\n\n<h2>JDC现有主要活动</h2>\n\n<p>-由珠海GDG负责人周琦带领的蟒营学习活动.<br>-移动MM的周汇报活动.</p>	2014-11-23 02:40:37.485535	2014-11-23 02:40:37.485535	\N	0	0	2014-11-30 14:53:30.212193	0	0	0	0	\N	0.200000000000000011	1	1	0	1	1	f	\N	0	0	0	0	2014-11-23 02:40:37.501228	f	\N	0	0	0	1	\N	10	1	1	f	2014-11-23 02:40:37.484974	1	\N	0	f	f	\N	1
24	1	20	1	感谢加入 暨大开发者社区，并且欢迎！\n\n这条私信包含了一些可以让您快速开始的技巧提示：\n\n## 保持滚动\n\n没有下一页按钮或者页码——要阅读更多，**只需要继续向下滚动页面！**\n\n当新的帖子加载后，它们会自动显示。\n\n## 我在哪儿？\n\n- 要搜索，访问您的用户页面或者菜单，使用**右上角的图标<kbd>☰</kbd>按钮**。\n\n- 任何主题标题点击后都将引导您至下一个未读的帖子。使用最后一次活动时间和帖子数量跳至主题顶部或底部。\n\n- 当在阅读主题时，通过点击帖子标题回到顶部 &uarr;。点击右下角的绿色进度条使用完整导航控制，或使用键盘上的 <kbd>home</kbd> 和 <kbd>end</kbd>键。\n\n    <img src="/images/welcome/progress-bar.png" width="143" height="39">\n\n\n\n## 我怎么回复？\n\n- 要回复整个主题，使用页面最底下的回复按钮 <img src="/images/welcome/reply-topic.png" width="29" height="25">。\n\n- 要回复特定的帖子，使用那个帖子的回复按钮 <img src="/images/welcome/reply-post.png" width="29" height="25">。\n\n- 如果您想把讨论导向另一个方向，但是保持讨论之间的联系，请使用帖子右侧的“回复为联结主题”<img src="/images/welcome/reply-as-linked-topic.png" width="15" height="25">。\n\n若想在您的回复中引用什么，选择想要引用的文字，然后点击任何回复按钮。\n\n每一个帖子最下方有功能按钮。\n\n<img src="/images/welcome/quote-reply.png" width="350" height="129">\n\n（要引用整个帖子，使用编辑器工具栏的导入引用按钮。）\n\n要在您的回复中提到某人，键入 `@`，自动完成将会弹出。\n\n<img src="/images/welcome/username-completion.png" width="230" height="131">\n\n要使用[标准绘文字（Emoji）](http://www.emoji.codes/)，先键入`:`或传统表情符`:)` :smile\n\n## 我还能做什么？\n\n<img src="/images/welcome/like-link-flag-bookmark.png" width="169" height="46">\n\n要让别人知道您喜欢他们的帖子，使用**赞**按钮。如果您觉得一个帖子有问题，请使用**标记**按钮以私下地让它们或者我们的职员了解情况。\n\n您可以分享一个帖子的链接，或者是收藏一个帖子以在用户也中引用他们。\n\n\n## 谁在跟我交谈？\n\n当有人回复您的帖子，引用您的帖子或者使用`@用户名`提及到您的时候，一个数字将会立即出现在页面右上角。使用它查看**通知**。\n\n<img src="/images/welcome/notification-panel.png" width="178" height="59">\n\n不用担心错过他人的回复 —— 当别人回复您的帖子（和私信）时您不在站点上，您将会收到邮件提醒。\n\n## 哪一个是新讨论？\n\n默认情况，所有小于两天的对话被认为是心的，并且所有您参与的讨论（回复过的、创建的或阅读了很长一段时间的）将自动被追踪。\n\n您将会在主题名字附近见到蓝色的新合数字指示：\n\n<img src="/images/welcome/topics-new-unread.png" width="368" height="89">\n\n您可以通过帖子下方的控制选项改变每一个主题的通知状态（也可以设置每一个分类的状态）。要改变您跟踪帖子的方式，或新的定义，详见[您的用户设置](/my/preferences)。\n\n## 为什么我不能做某些事？\n\n新用户因为某些安全原因被限制。只要您参与了讨论，您将会得到社群的信任，成为一个真正的成员，并且这些限制将自动被移除。当达到了一个足够的[信任等级](https://meta.discourse.org/t/what-do-user-trust-levels-do/4924)，您将会得到足够的权力来参与帮助社群管理。\n\n\n我们始终相信[文明的社会行为](http://jnu-developer.com/guidelines)。\n\n好好享受你在论坛的时光吧！	<p>感谢加入 暨大开发者社区，并且欢迎！</p>\n\n<p>这条私信包含了一些可以让您快速开始的技巧提示：</p>\n\n<h2>保持滚动</h2>\n\n<p>没有下一页按钮或者页码——要阅读更多，<strong>只需要继续向下滚动页面！</strong></p>\n\n<p>当新的帖子加载后，它们会自动显示。</p>\n\n<h2>我在哪儿？</h2>\n\n<ul>\n<li><p>要搜索，访问您的用户页面或者菜单，使用**右上角的图标<kbd>☰</kbd>按钮**。</p></li>\n<li><p>任何主题标题点击后都将引导您至下一个未读的帖子。使用最后一次活动时间和帖子数量跳至主题顶部或底部。</p></li>\n<li>\n<p>当在阅读主题时，通过点击帖子标题回到顶部 ↑。点击右下角的绿色进度条使用完整导航控制，或使用键盘上的 <kbd>home</kbd> 和 <kbd>end</kbd>键。</p>\n<p><img src="/images/welcome/progress-bar.png" width="143" height="39"></p>\n</li>\n</ul>\n\n<h2>我怎么回复？</h2>\n\n<ul>\n<li><p>要回复整个主题，使用页面最底下的回复按钮 <img src="/images/welcome/reply-topic.png" width="29" height="25">。</p></li>\n<li><p>要回复特定的帖子，使用那个帖子的回复按钮 <img src="/images/welcome/reply-post.png" width="29" height="25">。</p></li>\n<li><p>如果您想把讨论导向另一个方向，但是保持讨论之间的联系，请使用帖子右侧的“回复为联结主题”<img src="/images/welcome/reply-as-linked-topic.png" width="15" height="25">。</p></li>\n</ul>\n\n<p>若想在您的回复中引用什么，选择想要引用的文字，然后点击任何回复按钮。</p>\n\n<p>每一个帖子最下方有功能按钮。</p>\n\n<p><img src="/images/welcome/quote-reply.png" width="350" height="129"></p>\n\n<p>（要引用整个帖子，使用编辑器工具栏的导入引用按钮。）</p>\n\n<p>要在您的回复中提到某人，键入 <code>@</code>，自动完成将会弹出。</p>\n\n<p><img src="/images/welcome/username-completion.png" width="230" height="131"></p>\n\n<p>要使用<a href="http://www.emoji.codes/">标准绘文字（Emoji）</a>，先键入<code>:</code>或传统表情符<code>:)</code> :smile</p>\n\n<h2>我还能做什么？</h2>\n\n<p><img src="/images/welcome/like-link-flag-bookmark.png" width="169" height="46"></p>\n\n<p>要让别人知道您喜欢他们的帖子，使用**赞**按钮。如果您觉得一个帖子有问题，请使用**标记**按钮以私下地让它们或者我们的职员了解情况。</p>\n\n<p>您可以分享一个帖子的链接，或者是收藏一个帖子以在用户也中引用他们。</p>\n\n<h2>谁在跟我交谈？</h2>\n\n<p>当有人回复您的帖子，引用您的帖子或者使用<code>@用户名</code>提及到您的时候，一个数字将会立即出现在页面右上角。使用它查看**通知**。</p>\n\n<p><img src="/images/welcome/notification-panel.png" width="178" height="59"></p>\n\n<p>不用担心错过他人的回复 —— 当别人回复您的帖子（和私信）时您不在站点上，您将会收到邮件提醒。</p>\n\n<h2>哪一个是新讨论？</h2>\n\n<p>默认情况，所有小于两天的对话被认为是心的，并且所有您参与的讨论（回复过的、创建的或阅读了很长一段时间的）将自动被追踪。</p>\n\n<p>您将会在主题名字附近见到蓝色的新合数字指示：</p>\n\n<p><img src="/images/welcome/topics-new-unread.png" width="368" height="89"></p>\n\n<p>您可以通过帖子下方的控制选项改变每一个主题的通知状态（也可以设置每一个分类的状态）。要改变您跟踪帖子的方式，或新的定义，详见<a href="/my/preferences">您的用户设置</a>。</p>\n\n<h2>为什么我不能做某些事？</h2>\n\n<p>新用户因为某些安全原因被限制。只要您参与了讨论，您将会得到社群的信任，成为一个真正的成员，并且这些限制将自动被移除。当达到了一个足够的<a href="https://meta.discourse.org/t/what-do-user-trust-levels-do/4924">信任等级</a>，您将会得到足够的权力来参与帮助社群管理。</p>\n\n<p>我们始终相信<a href="//jnu-developer.com/guidelines">文明的社会行为</a>。</p>\n\n<p>好好享受你在论坛的时光吧！</p>	2014-12-08 15:56:02.231675	2014-12-08 15:56:02.231675	\N	0	0	\N	0	0	0	0	\N	0.200000000000000011	1	1	0	1	1	f	\N	0	0	0	0	2014-12-08 15:56:02.270168	f	\N	0	0	0	\N	\N	138	1	1	f	2014-12-08 15:56:02.230441	1	\N	0	f	f	\N	1
20	1	17	1	###欢迎来到暨大开发者社区###\n\n暨大开发者社区是由暨南大学一群技术爱好者组成的开源技术社区.我们通常将暨大开发者社区简称为JDC. JDC的前身是暨南大学金山软件俱乐部(KSC). 目前,JDC与KSC时期一样托管于暨大电气信息学院团委学生会. 我们的目标,在于提供一个让大家一起折腾编程开发的平台. 任何人都可以加入暨大开发者社区,只要你对编程感兴趣,崇尚开源精神.\n\n在暨大开发者社区,你可以找到志同道合的朋友,与你一起走上编程这条不归路.在暨大开发者社区,你可以提出你学习编程中遇到的困难,我们会定期处理论坛和邮件列表中的提问.\n\n在这里(JDC社区论坛),我们会发布一些活动纪要,通知和技术文章.同时也欢迎任何人发帖讨论技术.\n\n**但是发帖前请仔细阅读置顶,如果管理员判断发帖者有未阅读置顶的迹象,将不予警告直接禁言或删帖**\n\n###目前的暨大开发者社区###\n2014年下半年,我们与珠海GDG合作开办了新的一期蟒营,详情可参阅:\n\n+ [14/11/08]暨大蟒营开营纪要: http://jnu-developer.com/t/14-11-08/14\n+ 蟒营wiki(GitCafe): https://gitcafe.com/PythoniCamp/PythoniCamp/wiki\n+ 蟒营wiki(Google Code): https://code.google.com/p/kcpycamp/wiki/PythoniCamp?tm=6\n+ 蟒营邮件列表: pythonicamp@googlegroups.com\n+ 珠海GDG邮件列表: gdg-zhuhai@googlegroups.com\n    \n**不过,蟒营的形式限制,目前只能关注不能加入;-)**\n\n除了蟒营之外,我们还与中国移动合作,成立移动MM孵化基地作为暨大开发者社区的子社区,旨在开发移动平台产品,目前已经有3个开发团队和1个美术团队.\n\n**暨大开发者社区常年招收主程,测试,美术,产品设计,有意者联系dengzuoheng@gmail.com出示作品即可,要求暨大在校生**\n\n###如何加入暨大开发者社区###\n- 只需订阅暨大开发者社区邮件列表即可视为加入:\n    + 订阅方式:发送空邮件到jnu-developer+subscribe@googlegroups.com 即可完成订阅\n    + 如果需要获得更及时的活动通知,可发私人邮件至暨大开发者社区技术负责人说明情况\n    + 目前的技术负责人:dengzuoheng@gmail.com\n- 也可注册本论坛成为论坛会员:\n    + 注册需要通过电子邮件激活,所以注册时务必填写**真实邮件地址**否则无法注册成功.\n\n###社区资源###\n论坛: jnu-dveloper.com    \n邮件列表: jnu-developer@googlegroups.com\n官方文档库(附开源项目列表): https://github.com/DengZuoheng/doc.jdc\n\n###发帖须知###\n本讨论区采用先进的下一代论坛程序 Discourse[1] 搭建而成，具有很多新功能与新特性，所以建议您在正式开始发表话题之前，先熟悉一下这里的环境，以及本讨论区的相关说明。\n\n在您发表前 2 个主题或回复时，系统会自动弹出发帖指导，希望您认真阅读其中的内容后再发表。\n\n发帖的内容支持 Markdown[2] 语法控制格式.\n\n\n[1] http://www.discourse.org21\n\n[2] http://wowubuntu.com/markdown28	<h3>欢迎来到暨大开发者社区</h3>\n\n<p>暨大开发者社区是由暨南大学一群技术爱好者组成的开源技术社区.我们通常将暨大开发者社区简称为JDC. JDC的前身是暨南大学金山软件俱乐部(KSC). 目前,JDC与KSC时期一样托管于暨大电气信息学院团委学生会. 我们的目标,在于提供一个让大家一起折腾编程开发的平台. 任何人都可以加入暨大开发者社区,只要你对编程感兴趣,崇尚开源精神.</p>\n\n<p>在暨大开发者社区,你可以找到志同道合的朋友,与你一起走上编程这条不归路.在暨大开发者社区,你可以提出你学习编程中遇到的困难,我们会定期处理论坛和邮件列表中的提问.</p>\n\n<p>在这里(JDC社区论坛),我们会发布一些活动纪要,通知和技术文章.同时也欢迎任何人发帖讨论技术.</p>\n\n<p><strong>但是发帖前请仔细阅读置顶,如果管理员判断发帖者有未阅读置顶的迹象,将不予警告直接禁言或删帖</strong></p>\n\n<h3>目前的暨大开发者社区</h3>\n\n<p>2014年下半年,我们与珠海GDG合作开办了新的一期蟒营,详情可参阅:</p>\n\n<ul>\n<li>[14/11/08]暨大蟒营开营纪要: <a href="//jnu-developer.com/t/14-11-08/14">http://jnu-developer.com/t/14-11-08/14</a>\n</li>\n<li>蟒营wiki(GitCafe): <a href="https://gitcafe.com/PythoniCamp/PythoniCamp/wiki">https://gitcafe.com/PythoniCamp/PythoniCamp/wiki</a>\n</li>\n<li>蟒营wiki(Google Code): <a href="https://code.google.com/p/kcpycamp/wiki/PythoniCamp?tm=6">https://code.google.com/p/kcpycamp/wiki/PythoniCamp?tm=6</a>\n</li>\n<li>蟒营邮件列表: pythonicamp@googlegroups.com</li>\n<li>珠海GDG邮件列表: gdg-zhuhai@googlegroups.com</li>\n</ul>\n\n<p><strong>不过,蟒营的形式限制,目前只能关注不能加入;-)</strong></p>\n\n<p>除了蟒营之外,我们还与中国移动合作,成立移动MM孵化基地作为暨大开发者社区的子社区,旨在开发移动平台产品,目前已经有3个开发团队和1个美术团队.</p>\n\n<p><strong>暨大开发者社区常年招收主程,测试,美术,产品设计,有意者联系dengzuoheng@gmail.com出示作品即可,要求暨大在校生</strong></p>\n\n<h3>如何加入暨大开发者社区</h3>\n\n<ul>\n<li>只需订阅暨大开发者社区邮件列表即可视为加入:<ul>\n<li>订阅方式:发送空邮件到jnu-developer+subscribe@googlegroups.com 即可完成订阅</li>\n<li>如果需要获得更及时的活动通知,可发私人邮件至暨大开发者社区技术负责人说明情况</li>\n<li>目前的技术负责人:dengzuoheng@gmail.com</li>\n</ul>\n</li>\n<li>也可注册本论坛成为论坛会员:<ul><li>注册需要通过电子邮件激活,所以注册时务必填写**真实邮件地址**否则无法注册成功.</li></ul>\n</li>\n</ul>\n\n<h3>社区资源</h3>\n\n<p>论坛: jnu-dveloper.com  <br>邮件列表: jnu-developer@googlegroups.com<br>官方文档库(附开源项目列表): <a href="https://github.com/DengZuoheng/doc.jdc">https://github.com/DengZuoheng/doc.jdc</a></p>\n\n<h3>发帖须知</h3>\n\n<p>本讨论区采用先进的下一代论坛程序 Discourse[1] 搭建而成，具有很多新功能与新特性，所以建议您在正式开始发表话题之前，先熟悉一下这里的环境，以及本讨论区的相关说明。</p>\n\n<p>在您发表前 2 个主题或回复时，系统会自动弹出发帖指导，希望您认真阅读其中的内容后再发表。</p>\n\n<p>发帖的内容支持 Markdown[2] 语法控制格式.</p>\n\n<p>[1] <a href="http://www.discourse.org21">http://www.discourse.org21</a></p>\n\n<p>[2] <a href="http://wowubuntu.com/markdown28">http://wowubuntu.com/markdown28</a></p>	2014-11-30 14:52:28.526081	2014-11-30 14:52:39.059933	\N	0	0	\N	0	0	2	0	\N	10.1999999999999993	1	1	0	1	1	f	\N	0	0	0	0	2014-11-30 14:52:28.560252	f	\N	0	0	0	\N	\N	91	1	1	f	2014-11-30 14:52:39.059517	1	\N	1	f	f	\N	1
21	1	17	2	本主题已全局置顶，它将始终显示在它所属分类的顶部。可由职员对所有人解除置顶，或者由用户自己取消置顶。	<p>本主题已全局置顶，它将始终显示在它所属分类的顶部。可由职员对所有人解除置顶，或者由用户自己取消置顶。</p>	2014-11-30 14:52:48.701327	2014-11-30 14:52:48.701327	\N	0	0	\N	0	0	1	0	\N	5.20000000000000018	1	2	0	2	1	f	\N	0	0	0	0	2014-11-30 14:52:48.727442	f	\N	1	0	0	\N	\N	0	1	1	f	2014-11-30 14:52:48.70103	1	\N	0	f	f	\N	1
16	1	13	1	[用一段简短的话描述分类，并替换这第一段的内容。这段文字将出现在分类选择区域，所以尽量不要超过200个字符。当您编辑了这段文字或者再次分类创建了一个主题后，分类才会出现在分类列表中。]\n\n在接下来的一段文字中输入分类的详细描述信息，可以在这里包含在此分类下讨论的规则、内容导向等等。\n\n考虑这些事情：\n\n- 这个分类用来做什么？ 为什么人们选择这个分类寻找主题？\n\n- 这个分类和其他已有分类有什么不同？\n\n- 我们需要这个分类么？\n\n- 我们应该和已有分类合并吗？还是分离成更多的分类？\n	<p>[用一段简短的话描述分类，并替换这第一段的内容。这段文字将出现在分类选择区域，所以尽量不要超过200个字符。当您编辑了这段文字或者再次分类创建了一个主题后，分类才会出现在分类列表中。]</p>\n\n<p>在接下来的一段文字中输入分类的详细描述信息，可以在这里包含在此分类下讨论的规则、内容导向等等。</p>\n\n<p>考虑这些事情：</p>\n\n<ul><li><p>这个分类用来做什么？ 为什么人们选择这个分类寻找主题？</p></li><li><p>这个分类和其他已有分类有什么不同？</p></li><li><p>我们需要这个分类么？</p></li><li><p>我们应该和已有分类合并吗？还是分离成更多的分类？</p></li></ul>	2014-11-01 08:02:15.280073	2014-11-01 08:02:15.280073	\N	0	0	\N	0	0	2	0	\N	10.1999999999999993	1	1	0	1	1	f	\N	0	0	0	0	2014-11-01 08:02:15.293568	f	\N	0	0	0	\N	\N	1	1	1	f	2014-11-01 08:02:15.279839	1	\N	0	f	f	\N	1
19	1	16	1	经过两周的设计,JDC的logo定稿,现发布如下:\n大图标:  \n<img src="/uploads/default/4/2435daeed1465e41.png" width="500" height="500"> \n网站图标:  \n<img src="/uploads/default/5/a87baee6a18e9159.png" width="244" height="66"> \n小图标:  \n<img src="/uploads/default/6/0d11ff046aee0976.png" width="66" height="66"> \n\n构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑.\n\n感谢yinnjiuu@sina.com的设计和实现.\n\ngithub地址:\nhttps://github.com/DengZuoheng/doc.jdc/tree/master/logo	<p>经过两周的设计,JDC的logo定稿,现发布如下:<br>大图标:<br><div class="lightbox-wrapper"><a data-download-href="//jnu-developer.com/uploads/default/09168762f2cd57283ff54ec17bf3b806733a9cfb" href="//jnu-developer.com/uploads/default/4/2435daeed1465e41.png" class="lightbox" title="JDC-logo(1024x1024).png"><img src="//jnu-developer.com/uploads/default/_optimized/09b/b17/6d2d8e0c76_500x500.png" width="500" height="500"><div class="meta">\n<span class="filename">JDC-logo(1024x1024).png</span><span class="informations">1024x1024 130 KB</span><span class="expand"></span>\n</div></a></div> <br>网站图标:<br><img src="//jnu-developer.com/uploads/default/5/a87baee6a18e9159.png" width="244" height="66"> <br>小图标:<br><img src="//jnu-developer.com/uploads/default/6/0d11ff046aee0976.png" width="66" height="66"> </p>\n\n<p>构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑.</p>\n\n<p>感谢yinnjiuu@sina.com的设计和实现.</p>\n\n<p>github地址:<br><a href="https://github.com/DengZuoheng/doc.jdc/tree/master/logo" class="onebox" target="_blank">https://github.com/DengZuoheng/doc.jdc/tree/master/logo</a></p>	2014-11-30 13:34:53.337051	2014-11-30 15:17:01.776269	\N	0	0	\N	0	0	3	0	\N	15.1999999999999993	1	1	0	1	1	f	\N	0	0	0	0	2014-11-30 15:17:01.633602	f	\N	0	0	0	\N		50	2	1	f	2014-11-30 15:17:01.775795	1	\N	1	f	f	\N	2
\.


--
-- TOC entry 3397 (class 0 OID 0)
-- Dependencies: 175
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_id_seq', 24, true);


--
-- TOC entry 3269 (class 0 OID 19179)
-- Dependencies: 309
-- Data for Name: quoted_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY quoted_posts (id, post_id, quoted_post_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3398 (class 0 OID 0)
-- Dependencies: 308
-- Name: quoted_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('quoted_posts_id_seq', 1, false);


--
-- TOC entry 3132 (class 0 OID 16728)
-- Dependencies: 172
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
20120311163914
20120311164326
20120311170118
20120311201341
20120311210245
20120416201606
20120420183447
20120423140906
20120423142820
20120423151548
20120425145456
20120427150624
20120427151452
20120427154330
20120427172031
20120502183240
20120502192121
20120503205521
20120507144132
20120507144222
20120514144549
20120514173920
20120514204934
20120517200130
20120518200115
20120519182212
20120523180723
20120523184307
20120523201329
20120525194845
20120529175956
20120529202707
20120530150726
20120530160745
20120530200724
20120530212912
20120614190726
20120614202024
20120615180517
20120618152946
20120618212349
20120618214856
20120619150807
20120619153349
20120619172714
20120621155351
20120621190310
20120622200242
20120625145714
20120625162318
20120625174544
20120625195326
20120629143908
20120629150253
20120629151243
20120629182637
20120702211427
20120703184734
20120703201312
20120703203623
20120703210004
20120704160659
20120704201743
20120705181724
20120708210305
20120712150500
20120712151934
20120713201324
20120716020835
20120716173544
20120718044955
20120719004636
20120720013733
20120720044246
20120720162422
20120723051512
20120724234502
20120724234711
20120725183347
20120726201830
20120726235129
20120727005556
20120727150428
20120727213543
20120802151210
20120803191426
20120806030641
20120806062617
20120807223020
20120809020415
20120809030647
20120809053414
20120809154750
20120809174649
20120809175110
20120809201855
20120810064839
20120812235417
20120813004347
20120813042912
20120813201426
20120815004411
20120815180106
20120815204733
20120816050526
20120816205537
20120816205538
20120820191804
20120821191616
20120823205956
20120824171908
20120828204209
20120828204624
20120830182736
20120910171504
20120918152319
20120918205931
20120919152846
20120921055428
20120921155050
20120921162512
20120921163606
20120924182000
20120924182031
20120925171620
20120925190802
20120928170023
20121009161116
20121011155904
20121017162924
20121018103721
20121018133039
20121018182709
20121106015500
20121108193516
20121109164630
20121113200844
20121113200845
20121115172544
20121116212424
20121119190529
20121119200843
20121121202035
20121121205215
20121122033316
20121123054127
20121123063630
20121129160035
20121129184948
20121130010400
20121130191818
20121202225421
20121203181719
20121204183855
20121204193747
20121205162143
20121207000741
20121211233131
20121216230719
20121218205642
20121224072204
20121224095139
20121224100650
20121228192219
20130107165207
20130108195847
20130115012140
20130115021937
20130115043603
20130116151829
20130120222728
20130121231352
20130122051134
20130122232825
20130123070909
20130125002652
20130125030305
20130125031122
20130127213646
20130128182013
20130129010625
20130129163244
20130129174845
20130130154611
20130131055710
20130201000828
20130201023409
20130203204338
20130204000159
20130205021905
20130207200019
20130208220635
20130213021450
20130213203300
20130221215017
20130226015336
20130306180148
20130311181327
20130313004922
20130314093434
20130315180637
20130319122248
20130320012100
20130320024345
20130321154905
20130322183614
20130326210101
20130327185852
20130328162943
20130328182433
20130402210723
20130404143437
20130404232558
20130411205132
20130412015502
20130412020156
20130416004607
20130416004933
20130416170855
20130419195746
20130422050626
20130424015746
20130424055025
20130426044914
20130426052257
20130428194335
20130429000101
20130430052751
20130501105651
20130506020935
20130506185042
20130508040235
20130509040248
20130509041351
20130515193551
20130521210140
20130522193615
20130527152648
20130528174147
20130531210816
20130603192412
20130606190601
20130610201033
20130612200846
20130613211700
20130613212230
20130615064344
20130615073305
20130615075557
20130616082327
20130617014127
20130617180009
20130617181804
20130619063902
20130621042855
20130622110348
20130624203206
20130625022454
20130625170842
20130625201113
20130709184941
20130710201248
20130712041133
20130712163509
20130723212758
20130724201552
20130725213613
20130728172550
20130731163035
20130801155107
20130807202516
20130809160751
20130809204732
20130809211409
20130813204212
20130813224817
20130816024250
20130819192358
20130820174431
20130822213513
20130823201420
20130826011521
20130828192526
20130903154323
20130904181208
20130906081326
20130906171631
20130910040235
20130910220317
20130911182437
20130912185218
20130913210454
20130917174738
20131001060630
20131002070347
20131003061137
20131014203951
20131015131652
20131017014509
20131017030605
20131017205954
20131018050738
20131022045114
20131022151218
20131023163509
20131105101051
20131107154900
20131114185225
20131115165105
20131118173159
20131120055018
20131122064921
20131206200009
20131209091702
20131209091742
20131210163702
20131210181901
20131210234530
20131212225511
20131216164557
20131217174004
20131219203905
20131223171005
20131227164338
20131229221725
20131230010239
20140101235747
20140102104229
20140102194802
20140107220141
20140109205940
20140116170655
20140120155706
20140121204628
20140122043508
20140124202427
20140129164541
20140206044818
20140206195001
20140206215029
20140210194146
20140211230222
20140211234523
20140214151255
20140220160510
20140220163213
20140224232712
20140224232913
20140227104930
20140227201005
20140228005443
20140228173431
20140228205743
20140303185354
20140304200606
20140304201403
20140305100909
20140306223522
20140318150412
20140318203559
20140320042653
20140402201432
20140404143501
20140407055830
20140407202158
20140408061512
20140408152401
20140415054717
20140416202746
20140416202801
20140416235757
20140421235646
20140422195623
20140425125742
20140425135354
20140425172618
20140429175951
20140504174212
20140505145918
20140506200235
20140507173327
20140508053815
20140515220111
20140520062826
20140520063859
20140521192142
20140521220115
20140522003151
20140525233953
20140526185749
20140526201939
20140527163207
20140527233225
20140528015354
20140529045508
20140530002535
20140530043913
20140604145431
20140607035234
20140610012414
20140610012833
20140610034314
20140612010718
20140617053829
20140617080955
20140617193351
20140618001820
20140618163511
20140620184031
20140623195618
20140624044600
20140627193814
20140703022838
20140705081453
20140707071913
20140710005023
20140710224658
20140711063215
20140711143146
20140711193923
20140711233329
20140714060646
20140715013018
20140715051412
20140715055242
20140715160720
20140715190552
20140716063802
20140717024528
20140718041445
20140721063820
20140721161249
20140721162307
20140723011456
20140725050636
20140725172830
20140727030954
20140728120708
20140728144308
20140728152804
20140729092525
20140730203029
20140731011328
20140801052028
20140801170444
20140804010803
20140804030041
20140804060439
20140804072504
20140804075613
20140805061612
20140806003116
20140807033123
20140808051823
20140809224243
20140811094300
20140813175357
20140815183851
20140815191556
20140815215618
20140817011612
20140818023700
20140826234625
20140827044811
20140828172407
20140828200231
20140831191346
20140904055702
20140904160015
20140904215629
20140905055251
20140905171733
20140908165716
20140908191429
20140910130155
20140911065449
20140913192733
20140923042349
20140924192418
20140925173220
20140929181930
20140929204155
20141001101041
20141002181613
20141007224814
20141008152953
20141008181228
20141008192525
20141008192526
20141014032859
20141014191645
20141015060145
20141016183307
20141020153415
20141020154935
20141020164816
20141020174120
20141030222425
\.


--
-- TOC entry 3217 (class 0 OID 18443)
-- Dependencies: 257
-- Data for Name: screened_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY screened_emails (id, email, action_type, match_count, last_match_at, created_at, updated_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3399 (class 0 OID 0)
-- Dependencies: 256
-- Name: screened_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('screened_emails_id_seq', 1, false);


--
-- TOC entry 3228 (class 0 OID 18602)
-- Dependencies: 268
-- Data for Name: screened_ip_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY screened_ip_addresses (id, ip_address, action_type, match_count, last_match_at, created_at, updated_at) FROM stdin;
1	10.0.0.0/8	2	0	\N	2014-11-01 07:31:02.118105	2014-11-01 07:31:02.118105
2	192.168.0.0/16	2	0	\N	2014-11-01 07:31:02.122284	2014-11-01 07:31:02.122284
3	127.0.0.0/8	2	0	\N	2014-11-01 07:31:02.124195	2014-11-01 07:31:02.124195
4	172.16.0.0/12	2	0	\N	2014-11-01 07:31:02.125884	2014-11-01 07:31:02.125884
5	fc00::/7	2	0	\N	2014-11-01 07:31:02.128006	2014-11-01 07:31:02.128006
\.


--
-- TOC entry 3400 (class 0 OID 0)
-- Dependencies: 267
-- Name: screened_ip_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('screened_ip_addresses_id_seq', 6, false);


--
-- TOC entry 3219 (class 0 OID 18472)
-- Dependencies: 259
-- Data for Name: screened_urls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY screened_urls (id, url, domain, action_type, match_count, last_match_at, created_at, updated_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3401 (class 0 OID 0)
-- Dependencies: 258
-- Name: screened_urls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('screened_urls_id_seq', 1, false);


--
-- TOC entry 3240 (class 0 OID 18797)
-- Dependencies: 280
-- Data for Name: single_sign_on_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY single_sign_on_records (id, user_id, external_id, last_payload, created_at, updated_at, external_username, external_email, external_name, external_avatar_url) FROM stdin;
\.


--
-- TOC entry 3402 (class 0 OID 0)
-- Dependencies: 279
-- Name: single_sign_on_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('single_sign_on_records_id_seq', 1, false);


--
-- TOC entry 3191 (class 0 OID 17734)
-- Dependencies: 231
-- Data for Name: site_customizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site_customizations (id, name, stylesheet, header, "position", user_id, enabled, key, created_at, updated_at, override_default_style, stylesheet_baked, mobile_stylesheet, mobile_header, mobile_stylesheet_baked) FROM stdin;
\.


--
-- TOC entry 3403 (class 0 OID 0)
-- Dependencies: 230
-- Name: site_customizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('site_customizations_id_seq', 1, false);


--
-- TOC entry 3159 (class 0 OID 17218)
-- Dependencies: 199
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site_settings (id, name, data_type, value, created_at, updated_at) FROM stdin;
1	uncategorized_category_id	3	1	2014-11-01 07:30:59.05604	2014-11-01 07:30:59.05604
2	lounge_category_id	3	2	2014-11-01 07:30:59.319108	2014-11-01 07:30:59.319108
3	meta_category_id	3	3	2014-11-01 07:31:00.581623	2014-11-01 07:31:00.581623
4	staff_category_id	3	4	2014-11-01 07:31:00.680818	2014-11-01 07:31:00.680818
5	tos_topic_id	3	4	2014-11-01 07:31:04.99946	2014-11-01 07:31:04.99946
6	guidelines_topic_id	3	5	2014-11-01 07:31:05.494559	2014-11-01 07:31:05.494559
7	privacy_topic_id	3	6	2014-11-01 07:31:05.769171	2014-11-01 07:31:05.769171
8	last_vacuum	3	1414827067	2014-11-01 07:31:07.514877	2014-11-01 07:31:07.514877
10	has_login_hint	5	f	2014-11-01 07:31:12.050335	2014-11-01 07:37:36.88773
9	global_notice	1		2014-11-01 07:31:12.044522	2014-11-01 07:37:36.897269
11	default_locale	7	zh_CN	2014-11-01 07:38:55.190451	2014-11-01 07:38:55.190451
12	title	1	暨大开发者社区	2014-11-01 07:46:18.183099	2014-11-01 07:46:18.183099
13	contact_email	1	dengzuoheng@gmail.com	2014-11-01 07:46:23.380908	2014-11-01 07:46:23.380908
14	site_contact_username	1	dengzuoheng	2014-11-01 07:46:30.978055	2014-11-01 07:46:30.978055
15	site_description	1	暨大开发者社区官方论坛	2014-11-01 07:47:29.962313	2014-11-01 07:47:29.962313
16	logo_url	1	/uploads/default/5/a87baee6a18e9159.png	2014-11-30 13:36:15.35215	2014-11-30 13:36:15.35215
17	logo_small_url	1	/uploads/default/5/a87baee6a18e9159.png	2014-11-30 13:36:25.389605	2014-11-30 13:36:25.389605
18	favicon_url	1	/uploads/default/6/0d11ff046aee0976.png	2014-11-30 13:36:38.190704	2014-11-30 13:36:38.190704
\.


--
-- TOC entry 3404 (class 0 OID 0)
-- Dependencies: 198
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('site_settings_id_seq', 18, true);


--
-- TOC entry 3199 (class 0 OID 18143)
-- Dependencies: 239
-- Data for Name: site_texts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site_texts (text_type, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3236 (class 0 OID 18703)
-- Dependencies: 276
-- Data for Name: top_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY top_topics (id, topic_id, yearly_posts_count, yearly_views_count, yearly_likes_count, monthly_posts_count, monthly_views_count, monthly_likes_count, weekly_posts_count, weekly_views_count, weekly_likes_count, daily_posts_count, daily_views_count, daily_likes_count, yearly_score, monthly_score, weekly_score, daily_score) FROM stdin;
8	14	1	73	1	1	35	1	1	13	1	1	6	1	4.86332286012045589	0	0	0
11	17	1	52	1	1	52	1	1	12	1	1	3	1	4.71600334363479945	4.71600334363479945	0	0
12	18	1	43	1	1	43	1	1	7	1	1	2	1	4.63346845557958709	4.63346845557958709	0	0
1	5	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
2	4	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
3	6	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
4	7	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
6	9	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
7	10	0	0	1	0	0	1	0	0	1	0	0	1	1	0	0	0
10	16	1	42	1	1	42	1	1	9	1	1	1	1	4.62324929039790078	4.62324929039790078	0	0
13	19	1	53	1	1	53	1	1	13	1	1	2	1	4.72427586960078916	4.72427586960078916	0	0
\.


--
-- TOC entry 3405 (class 0 OID 0)
-- Dependencies: 275
-- Name: top_topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('top_topics_id_seq', 13, true);


--
-- TOC entry 3209 (class 0 OID 18261)
-- Dependencies: 249
-- Data for Name: topic_allowed_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_allowed_groups (id, group_id, topic_id) FROM stdin;
\.


--
-- TOC entry 3406 (class 0 OID 0)
-- Dependencies: 248
-- Name: topic_allowed_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_allowed_groups_id_seq', 1, false);


--
-- TOC entry 3177 (class 0 OID 17543)
-- Dependencies: 217
-- Data for Name: topic_allowed_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_allowed_users (id, user_id, topic_id, created_at, updated_at) FROM stdin;
1	6	20	2014-12-08 15:56:01.968749	2014-12-08 15:56:01.968749
2	1	20	2014-12-08 15:56:01.974513	2014-12-08 15:56:01.974513
\.


--
-- TOC entry 3407 (class 0 OID 0)
-- Dependencies: 216
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_allowed_users_id_seq', 2, true);


--
-- TOC entry 3260 (class 0 OID 18997)
-- Dependencies: 300
-- Data for Name: topic_custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_custom_fields (id, topic_id, name, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3408 (class 0 OID 0)
-- Dependencies: 299
-- Name: topic_custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_custom_fields_id_seq', 1, false);


--
-- TOC entry 3234 (class 0 OID 18683)
-- Dependencies: 274
-- Data for Name: topic_embeds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_embeds (id, topic_id, post_id, embed_url, content_sha1, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3409 (class 0 OID 0)
-- Dependencies: 273
-- Name: topic_embeds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_embeds_id_seq', 1, false);


--
-- TOC entry 3183 (class 0 OID 17669)
-- Dependencies: 223
-- Data for Name: topic_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_invites (id, topic_id, invite_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3410 (class 0 OID 0)
-- Dependencies: 222
-- Name: topic_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_invites_id_seq', 1, false);


--
-- TOC entry 3168 (class 0 OID 17327)
-- Dependencies: 208
-- Data for Name: topic_link_clicks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_link_clicks (id, topic_link_id, user_id, created_at, updated_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3411 (class 0 OID 0)
-- Dependencies: 207
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_link_clicks_id_seq', 1, false);


--
-- TOC entry 3146 (class 0 OID 16916)
-- Dependencies: 186
-- Data for Name: topic_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_links (id, topic_id, post_id, user_id, url, domain, internal, link_topic_id, created_at, updated_at, reflection, clicks, link_post_id, title, crawled_at, quote) FROM stdin;
2	4	4	-1	/privacy	jnu-developer.com	t	\N	2014-11-01 07:31:04.553914	2014-11-01 07:31:04.553914	f	0	\N	\N	\N	f
3	4	4	-1	/faq	jnu-developer.com	t	\N	2014-11-01 07:31:04.559216	2014-11-01 07:31:04.559216	f	0	\N	\N	\N	f
4	4	4	-1	#1	jnu-developer.com	t	\N	2014-11-01 07:31:04.575115	2014-11-01 07:31:04.575115	f	0	\N	\N	\N	f
5	4	4	-1	#2	jnu-developer.com	t	\N	2014-11-01 07:31:04.579645	2014-11-01 07:31:04.579645	f	0	\N	\N	\N	f
6	4	4	-1	#3	jnu-developer.com	t	\N	2014-11-01 07:31:04.582855	2014-11-01 07:31:04.582855	f	0	\N	\N	\N	f
8	4	4	-1	#4	jnu-developer.com	t	\N	2014-11-01 07:31:04.588642	2014-11-01 07:31:04.588642	f	0	\N	\N	\N	f
9	4	4	-1	#5	jnu-developer.com	t	\N	2014-11-01 07:31:04.592324	2014-11-01 07:31:04.592324	f	0	\N	\N	\N	f
10	4	4	-1	#6	jnu-developer.com	t	\N	2014-11-01 07:31:04.595875	2014-11-01 07:31:04.595875	f	0	\N	\N	\N	f
11	4	4	-1	#7	jnu-developer.com	t	\N	2014-11-01 07:31:04.599422	2014-11-01 07:31:04.599422	f	0	\N	\N	\N	f
12	4	4	-1	#8	jnu-developer.com	t	\N	2014-11-01 07:31:04.603061	2014-11-01 07:31:04.603061	f	0	\N	\N	\N	f
14	4	4	-1	#9	jnu-developer.com	t	\N	2014-11-01 07:31:04.610771	2014-11-01 07:31:04.610771	f	0	\N	\N	\N	f
15	4	4	-1	#10	jnu-developer.com	t	\N	2014-11-01 07:31:04.614676	2014-11-01 07:31:04.614676	f	0	\N	\N	\N	f
16	4	4	-1	#11	jnu-developer.com	t	\N	2014-11-01 07:31:04.618318	2014-11-01 07:31:04.618318	f	0	\N	\N	\N	f
17	4	4	-1	#12	jnu-developer.com	t	\N	2014-11-01 07:31:04.62197	2014-11-01 07:31:04.62197	f	0	\N	\N	\N	f
18	4	4	-1	#13	jnu-developer.com	t	\N	2014-11-01 07:31:04.625867	2014-11-01 07:31:04.625867	f	0	\N	\N	\N	f
19	4	4	-1	#14	jnu-developer.com	t	\N	2014-11-01 07:31:04.629147	2014-11-01 07:31:04.629147	f	0	\N	\N	\N	f
21	4	4	-1	#15	jnu-developer.com	t	\N	2014-11-01 07:31:04.63388	2014-11-01 07:31:04.63388	f	0	\N	\N	\N	f
22	4	4	-1	#16	jnu-developer.com	t	\N	2014-11-01 07:31:04.636882	2014-11-01 07:31:04.636882	f	0	\N	\N	\N	f
23	4	4	-1	/guidelines	jnu-developer.com	t	\N	2014-11-01 07:31:04.640709	2014-11-01 07:31:04.640709	f	0	\N	\N	\N	f
24	4	4	-1	#17	jnu-developer.com	t	\N	2014-11-01 07:31:04.644398	2014-11-01 07:31:04.644398	f	0	\N	\N	\N	f
25	4	4	-1	#18	jnu-developer.com	t	\N	2014-11-01 07:31:04.648372	2014-11-01 07:31:04.648372	f	0	\N	\N	\N	f
27	5	6	-1	#civilized	jnu-developer.com	t	\N	2014-11-01 07:31:05.173312	2014-11-01 07:31:05.173312	f	0	\N	\N	\N	f
28	5	6	-1	#improve	jnu-developer.com	t	\N	2014-11-01 07:31:05.176684	2014-11-01 07:31:05.176684	f	0	\N	\N	\N	f
29	5	6	-1	#agreeable	jnu-developer.com	t	\N	2014-11-01 07:31:05.179666	2014-11-01 07:31:05.179666	f	0	\N	\N	\N	f
30	5	6	-1	#participate	jnu-developer.com	t	\N	2014-11-01 07:31:05.182631	2014-11-01 07:31:05.182631	f	0	\N	\N	\N	f
31	5	6	-1	#flag-problems	jnu-developer.com	t	\N	2014-11-01 07:31:05.185601	2014-11-01 07:31:05.185601	f	0	\N	\N	\N	f
32	5	6	-1	#be-civil	jnu-developer.com	t	\N	2014-11-01 07:31:05.189002	2014-11-01 07:31:05.189002	f	0	\N	\N	\N	f
33	5	6	-1	#keep-tidy	jnu-developer.com	t	\N	2014-11-01 07:31:05.192281	2014-11-01 07:31:05.192281	f	0	\N	\N	\N	f
34	5	6	-1	#stealing	jnu-developer.com	t	\N	2014-11-01 07:31:05.19556	2014-11-01 07:31:05.19556	f	0	\N	\N	\N	f
35	5	6	-1	#tos	jnu-developer.com	t	\N	2014-11-01 07:31:05.198646	2014-11-01 07:31:05.198646	f	0	\N	\N	\N	f
36	5	6	-1	/tos	jnu-developer.com	t	\N	2014-11-01 07:31:05.20177	2014-11-01 07:31:05.20177	f	0	\N	\N	\N	f
37	6	8	-1	#collect	jnu-developer.com	t	\N	2014-11-01 07:31:05.640644	2014-11-01 07:31:05.640644	f	0	\N	\N	\N	f
38	6	8	-1	#use	jnu-developer.com	t	\N	2014-11-01 07:31:05.644077	2014-11-01 07:31:05.644077	f	0	\N	\N	\N	f
39	6	8	-1	#protect	jnu-developer.com	t	\N	2014-11-01 07:31:05.647074	2014-11-01 07:31:05.647074	f	0	\N	\N	\N	f
40	6	8	-1	#data-retention	jnu-developer.com	t	\N	2014-11-01 07:31:05.650083	2014-11-01 07:31:05.650083	f	0	\N	\N	\N	f
41	6	8	-1	#cookies	jnu-developer.com	t	\N	2014-11-01 07:31:05.653114	2014-11-01 07:31:05.653114	f	0	\N	\N	\N	f
42	6	8	-1	#disclose	jnu-developer.com	t	\N	2014-11-01 07:31:05.6562	2014-11-01 07:31:05.6562	f	0	\N	\N	\N	f
43	6	8	-1	#third-party	jnu-developer.com	t	\N	2014-11-01 07:31:05.659486	2014-11-01 07:31:05.659486	f	0	\N	\N	\N	f
44	6	8	-1	#coppa	jnu-developer.com	t	\N	2014-11-01 07:31:05.662665	2014-11-01 07:31:05.662665	f	0	\N	\N	\N	f
46	6	8	-1	#online	jnu-developer.com	t	\N	2014-11-01 07:31:05.667815	2014-11-01 07:31:05.667815	f	0	\N	\N	\N	f
47	6	8	-1	#consent	jnu-developer.com	t	\N	2014-11-01 07:31:05.671124	2014-11-01 07:31:05.671124	f	0	\N	\N	\N	f
48	6	8	-1	#changes	jnu-developer.com	t	\N	2014-11-01 07:31:05.674375	2014-11-01 07:31:05.674375	f	0	\N	\N	\N	f
50	9	12	-1	/badges/3/regular	jnu-developer.com	t	\N	2014-11-01 07:31:06.07549	2014-11-01 07:31:06.07549	f	0	\N	\N	\N	f
53	10	13	-1	/t/assets-for-the-site-design	jnu-developer.com	t	\N	2014-11-01 07:31:06.517311	2014-11-01 07:31:06.517311	f	0	\N	\N	\N	f
64	10	13	-1	/t/welcome-to-discourse	jnu-developer.com	t	\N	2014-11-01 07:31:06.547521	2014-11-01 07:31:06.547521	f	0	\N	\N	\N	f
7	4	4	-1	http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US	creativecommons.org	f	\N	2014-11-01 07:31:04.584755	2014-11-01 07:31:04.584755	f	0	\N	Creative Commons — Attribution-NonCommercial-ShareAlike 3.0 Unported — CC BY-NC-SA 3.0	2014-11-01 07:36:25.598569	f
45	6	8	-1	http://en.wikipedia.org/wiki/Children	en.wikipedia.org	f	\N	2014-11-01 07:31:05.664472	2014-11-01 07:31:05.664472	f	0	\N	Child - Wikipedia, the free encyclopedia	2014-11-01 07:36:26.419076	f
26	4	4	-1	http://en.wordpress.com/tos/	en.wordpress.com	f	\N	2014-11-01 07:31:04.65035	2014-11-01 07:31:04.65035	f	0	\N	Terms of Service — WordPress.com	2014-11-01 07:36:26.894977	f
52	10	13	-1	http://www.discourse.org	www.discourse.org	f	\N	2014-11-01 07:31:06.502888	2014-11-01 07:31:06.502888	f	0	\N	Discourse	2014-11-01 07:36:27.405026	f
54	10	13	-1	https://meta.discourse.org/t/configuring-google-oauth2-login-for-discourse/15858	meta.discourse.org	f	\N	2014-11-01 07:31:06.52544	2014-11-01 07:31:06.52544	f	0	\N	Configuring Google OAuth2 login for Discourse - Discourse Meta	2014-11-01 07:36:29.070452	f
55	10	13	-1	https://meta.discourse.org/t/configuring-twitter-login-for-discourse/13395	meta.discourse.org	f	\N	2014-11-01 07:31:06.527227	2014-11-01 07:31:06.527227	f	0	\N	Configuring Twitter login for Discourse - Discourse Meta	2014-11-01 07:36:29.419709	f
20	4	4	-1	http://www.newyorker.com/online/blogs/shouts/2012/12/the-hundred-best-lists-of-all-time.html	www.newyorker.com	f	\N	2014-11-01 07:31:04.630878	2014-11-01 07:31:04.630878	f	0	\N	The Hundred Best Lists of All Time - The New Yorker	2014-11-01 07:36:30.54701	f
57	10	13	-1	https://meta.discourse.org/t/configuring-github-login-for-discourse/13745	meta.discourse.org	f	\N	2014-11-01 07:31:06.530651	2014-11-01 07:31:06.530651	f	0	\N	Configuring GitHub login for Discourse - Discourse Meta	2014-11-01 07:36:31.191324	f
58	10	13	-1	https://meta.discourse.org/t/official-single-sign-on-for-discourse/13045	meta.discourse.org	f	\N	2014-11-01 07:31:06.532501	2014-11-01 07:31:06.532501	f	0	\N	Official Single-Sign-On for Discourse - Discourse Meta	2014-11-01 07:36:31.752075	f
60	10	13	-1	http://mandrill.com	mandrill.com	f	\N	2014-11-01 07:31:06.537971	2014-11-01 07:31:06.537971	f	0	\N	Transactional Email from MailChimp - Mandrill	2014-11-01 07:36:31.989588	f
61	10	13	-1	http://www.mailgun.com/	www.mailgun.com	f	\N	2014-11-01 07:31:06.539987	2014-11-01 07:31:06.539987	f	0	\N	Transactional Email API Service for Developers - Mailgun	2014-11-01 07:36:32.534326	f
63	10	13	-1	https://meta.discourse.org/t/set-up-reply-via-email-support/14003	meta.discourse.org	f	\N	2014-11-01 07:31:06.543841	2014-11-01 07:31:06.543841	f	0	\N	Set up reply via email support - Discourse Meta	2014-11-01 07:36:33.605221	f
66	10	13	-1	/faq	jnu-developer.com	t	\N	2014-11-01 07:31:06.555874	2014-11-01 07:31:06.555874	f	0	\N	\N	\N	f
68	10	13	-1	/category/meta	jnu-developer.com	t	\N	2014-11-01 07:31:06.574966	2014-11-01 07:31:06.574966	f	0	\N	\N	\N	f
70	10	13	-1	/category/lounge	jnu-developer.com	t	\N	2014-11-01 07:31:06.581074	2014-11-01 07:31:06.581074	f	0	\N	\N	\N	f
71	10	13	-1	/category/staff	jnu-developer.com	t	\N	2014-11-01 07:31:06.584029	2014-11-01 07:31:06.584029	f	0	\N	\N	\N	f
72	10	13	-1	/categories	jnu-developer.com	t	\N	2014-11-01 07:31:06.587164	2014-11-01 07:31:06.587164	f	0	\N	\N	\N	f
77	10	13	-1	/tos	jnu-developer.com	t	\N	2014-11-01 07:31:06.598759	2014-11-01 07:31:06.598759	f	0	\N	\N	\N	f
1	4	4	-1	http://www.example.com	www.example.com	f	\N	2014-11-01 07:31:04.439673	2014-11-01 07:31:04.439673	f	0	\N	Example Domain	2014-11-01 07:36:25.483477	f
13	4	4	-1	http://en.wikipedia.org/wiki/Digital_Millennium_Copyright_Act	en.wikipedia.org	f	\N	2014-11-01 07:31:04.605639	2014-11-01 07:31:04.605639	f	0	\N	Digital Millennium Copyright Act - Wikipedia, the free encyclopedia	2014-11-01 07:36:25.524265	f
49	9	12	-1	http://en.wikipedia.org/wiki/Nofollow	en.wikipedia.org	f	\N	2014-11-01 07:31:06.065002	2014-11-01 07:31:06.065002	f	0	\N	nofollow - Wikipedia, the free encyclopedia	2014-11-01 07:36:26.486329	f
51	9	12	-1	https://meta.discourse.org/t/what-do-user-trust-levels-do/4924	meta.discourse.org	f	\N	2014-11-01 07:31:06.077682	2014-11-01 07:31:06.077682	f	0	\N	What do user trust levels do? - Discourse Meta	2014-11-01 07:36:28.411258	f
56	10	13	-1	https://meta.discourse.org/t/configuring-facebook-login-for-discourse/13394	meta.discourse.org	f	\N	2014-11-01 07:31:06.528942	2014-11-01 07:31:06.528942	f	0	\N	Configuring Facebook login for Discourse - Discourse Meta	2014-11-01 07:36:30.208711	f
59	10	13	-1	https://meta.discourse.org/t/login-to-discourse-with-custom-oauth2-provider/14717	meta.discourse.org	f	\N	2014-11-01 07:31:06.534267	2014-11-01 07:31:06.534267	f	0	\N	Login to Discourse with custom Oauth2 provider - Discourse Meta	2014-11-01 07:36:32.108308	f
65	10	13	-1	https://www.youtube.com/watch?v=d0VNHe5fq30	www.youtube.com	f	\N	2014-11-01 07:31:06.54966	2014-11-01 07:31:06.54966	f	0	\N	What in the Wide, Wide World of Sports?.mp4 - YouTube	2014-11-01 07:36:33.938708	f
67	10	13	-1	http://blog.discourse.org/2013/03/the-universal-rules-of-civilized-discourse/	blog.discourse.org	f	\N	2014-11-01 07:31:06.558764	2014-11-01 07:31:06.558764	f	0	\N	The Universal Rules of Civilized Discourse	2014-11-01 07:36:34.076148	f
62	10	13	-1	http://www.mailjet.com/	www.mailjet.com	f	\N	2014-11-01 07:31:06.542069	2014-11-01 07:31:06.542069	f	0	\N	Mailjet | email delivery service for marketing & transactional email	2014-11-01 07:36:35.110996	f
76	10	13	-1	http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US	creativecommons.org	f	\N	2014-11-01 07:31:06.595583	2014-11-01 07:31:06.595583	f	0	\N	Creative Commons — Attribution-NonCommercial-ShareAlike 3.0 Unported — CC BY-NC-SA 3.0	2014-11-01 07:36:36.229518	f
74	10	13	-1	https://meta.discourse.org/t/what-do-user-trust-levels-do/4924/2	meta.discourse.org	f	\N	2014-11-01 07:31:06.592064	2014-11-01 07:31:06.592064	f	0	\N	What do user trust levels do? - Discourse Meta	2014-11-01 07:36:36.250412	f
69	10	13	-1	https://meta.discourse.org/t/what-is-meta/5249	meta.discourse.org	f	\N	2014-11-01 07:31:06.577492	2014-11-01 07:31:06.577492	f	0	\N	What is "Meta"? - Discourse Meta	2014-11-01 07:36:36.254383	f
75	10	13	-1	https://creativecommons.org/	creativecommons.org	f	\N	2014-11-01 07:31:06.593797	2014-11-01 07:31:06.593797	f	0	\N	Creative Commons	2014-11-01 07:36:36.682047	f
78	10	13	-1	http://blog.discourse.org/2014/08/building-a-discourse-community/	blog.discourse.org	f	\N	2014-11-01 07:31:06.600489	2014-11-01 07:31:06.600489	f	0	\N	Building a Discourse Community	2014-11-01 07:36:37.642541	f
73	10	13	-1	http://meta.discourse.org/t/how-to-set-up-image-uploads-to-s3/7229	meta.discourse.org	f	\N	2014-11-01 07:31:06.590287	2014-11-01 07:31:06.590287	f	0	\N	Setting up file and image uploads to S3 - Discourse Meta	2014-11-01 07:36:37.656262	f
80	10	13	-1	https://meta.discourse.org/t/invite-individual-users-to-a-group/15544	meta.discourse.org	f	\N	2014-11-01 07:31:06.604029	2014-11-01 07:31:06.604029	f	0	\N	Invite individual users to a group - Discourse Meta	2014-11-01 07:36:38.835958	f
79	10	13	-1	https://meta.discourse.org/t/sending-bulk-user-invites/16468	meta.discourse.org	f	\N	2014-11-01 07:31:06.602277	2014-11-01 07:31:06.602277	f	0	\N	Sending Bulk User Invites - Discourse Meta	2014-11-01 07:36:38.855368	f
82	10	13	-1	https://meta.discourse.org/t/configure-automatic-backups-for-discourse/14855	meta.discourse.org	f	\N	2014-11-01 07:31:06.608836	2014-11-01 07:31:06.608836	f	0	\N	Configure automatic backups for Discourse - Discourse Meta	2014-11-01 07:36:40.415557	f
81	10	13	-1	https://github.com/discourse/discourse/blob/master/docs/INSTALL.md	github.com	f	\N	2014-11-01 07:31:06.605783	2014-11-01 07:31:06.605783	f	0	\N	discourse/INSTALL.md at master · discourse/discourse · GitHub	2014-11-01 07:36:40.44224	f
83	10	13	-1	https://meta.discourse.org/t/allowing-ssl-for-your-discourse-docker-setup/13847	meta.discourse.org	f	\N	2014-11-01 07:31:06.610601	2014-11-01 07:31:06.610601	f	0	\N	Allowing SSL for your Discourse Docker setup - Discourse Meta	2014-11-01 07:36:41.444863	f
85	10	13	-1	https://meta.discourse.org/t/move-your-discourse-instance-to-a-different-server/15721	meta.discourse.org	f	\N	2014-11-01 07:31:06.614116	2014-11-01 07:31:06.614116	f	0	\N	Move your Discourse Instance to a Different Server - Discourse Meta	2014-11-01 07:36:41.954901	f
84	10	13	-1	https://meta.discourse.org/t/enable-a-cdn-for-your-discourse/14857	meta.discourse.org	f	\N	2014-11-01 07:31:06.612386	2014-11-01 07:31:06.612386	f	0	\N	Enable a CDN for your Discourse - Discourse Meta	2014-11-01 07:36:41.962017	f
87	10	13	-1	https://meta.discourse.org/t/multisite-configuration-with-docker/14084	meta.discourse.org	f	\N	2014-11-01 07:31:06.617623	2014-11-01 07:31:06.617623	f	0	\N	Multisite configuration with Docker - Discourse Meta	2014-11-01 07:36:43.135123	f
86	10	13	-1	https://meta.discourse.org/t/how-do-i-change-the-domain-name/16098	meta.discourse.org	f	\N	2014-11-01 07:31:06.615911	2014-11-01 07:31:06.615911	f	0	\N	Change the domain name or rename my Discourse? - Discourse Meta	2014-11-01 07:36:44.13301	f
88	10	13	-1	https://github.com/discourse/discourse/tree/master/script/import_scripts	github.com	f	\N	2014-11-01 07:31:06.619517	2014-11-01 07:31:06.619517	f	0	\N	discourse/script/import_scripts at master · discourse/discourse · GitHub	2014-11-01 07:36:44.881823	f
89	10	13	-1	http://meta.discourse.org	meta.discourse.org	f	\N	2014-11-01 07:31:06.621286	2014-11-01 07:31:06.621286	f	0	\N	Discourse Meta	2014-11-01 07:36:45.03901	f
90	10	13	-1	https://github.com/discourse/discourse/blob/master/docs/ADMIN-QUICK-START-GUIDE.md	github.com	f	\N	2014-11-01 07:31:06.623043	2014-11-01 07:31:06.623043	f	0	\N	discourse/ADMIN-QUICK-START-GUIDE.md at master · discourse/discourse · GitHub	2014-11-01 07:36:45.247786	f
95	14	17	1	http://www.greenteapress.com/thinkpython/thinkCSpy.pdf	www.greenteapress.com	f	\N	2014-11-12 16:38:55.736332	2014-11-12 16:38:55.736332	f	0	\N	\N	2014-11-12 16:38:57.391238	f
94	14	17	1	http://sebug.net/paper/books/LearnPythonTheHardWay/	sebug.net	f	\N	2014-11-12 16:38:55.727344	2014-11-12 16:38:55.727344	f	0	\N	笨办法学 Python （Learn Python The Hard Way） — 笨办法学 Python 2.0 documentation	2014-11-12 16:38:57.463386	f
91	14	17	1	http://wiki.woodpecker.org.cn/moin/AskForHelp	wiki.woodpecker.org.cn	f	\N	2014-11-12 16:38:55.694677	2014-11-12 16:38:55.694677	f	0	\N	AskForHelp - Woodpecker Wiki for CPUG	2014-11-12 16:38:58.862561	f
96	14	17	1	https://gitcafe.com/PythoniCamp/housekeeper	gitcafe.com	f	\N	2014-11-12 16:38:55.746345	2014-11-12 16:38:55.746345	f	0	\N	PythoniCamp/housekeeper - GitCafe	2014-11-12 16:39:01.303862	f
93	14	17	1	http://blog.zhgdg.org/2014-09/km4gdg-guider/	blog.zhgdg.org	f	\N	2014-11-12 16:38:55.717816	2014-11-12 16:38:55.717816	f	0	\N	珠海GDG 社区知识管理 指南 | GDG Livin ZhuHai Life;-)	2014-11-12 16:38:57.175439	f
92	14	17	1	http://blog.zhgdg.org/2014-10/dm34-how2ask/	blog.zhgdg.org	f	\N	2014-11-12 16:38:55.707855	2014-11-12 16:38:55.707855	f	0	\N	珠的自白:34 如何提问?才对世界有帮助! | GDG Livin ZhuHai Life;-)	2014-11-12 16:38:57.229502	f
98	14	17	1	https://gitcafe.com/PythoniCamp/Mailpop	gitcafe.com	f	\N	2014-11-12 16:38:55.762987	2014-11-12 16:38:55.762987	f	0	\N	PythoniCamp/Mailpop - GitCafe	2014-11-12 16:39:01.31546	f
97	14	17	1	https://gitcafe.com/PythoniCamp/Bookfriend	gitcafe.com	f	\N	2014-11-12 16:38:55.75544	2014-11-12 16:38:55.75544	f	0	\N	PythoniCamp/Bookfriend - GitCafe	2014-11-12 16:39:01.370317	f
100	14	17	1	https://gitcafe.com/PythoniCamp/Takemeup	gitcafe.com	f	\N	2014-11-12 16:38:55.778004	2014-11-12 16:38:55.778004	f	0	\N	PythoniCamp/Takemeup - GitCafe	2014-11-12 16:39:01.606663	f
99	14	17	1	https://gitcafe.com/PythoniCamp/happyhelp	gitcafe.com	f	\N	2014-11-12 16:38:55.771288	2014-11-12 16:38:55.771288	f	0	\N	PythoniCamp/happyhelp - GitCafe	2014-11-12 16:39:01.721656	f
101	14	17	1	http://zoomq.qiniudn.com/CPyUG/PythoniCamp/141108-jnu-start/	zoomq.qiniudn.com	f	\N	2014-11-12 16:38:55.785886	2014-11-12 16:38:55.785886	f	0	\N	Index of /CPyUG/PythoniCamp/141108-jnu-start {gen. by gen4idx.py v13.4.18}	2014-11-12 16:39:02.716842	f
102	16	19	1	https://github.com/DengZuoheng/doc.jdc/tree/master/logo	github.com	f	\N	2014-11-30 13:34:53.465375	2014-11-30 13:34:53.465375	f	0	\N	doc.jdc/logo at master · DengZuoheng/doc.jdc · GitHub	2014-11-30 13:34:56.327787	f
103	17	20	1	http://jnu-developer.com/t/14-11-08/14	jnu-developer.com	t	14	2014-11-30 14:52:28.927981	2014-11-30 14:52:28.927981	f	0	17	\N	\N	f
104	14	17	1	http://jnu-developer.com/t/jdc/17	jnu-developer.com	t	17	2014-11-30 14:52:28.95473	2014-11-30 14:52:28.95473	t	0	20	\N	\N	f
108	17	20	1	http://www.discourse.org21	www.discourse.org21	f	\N	2014-11-30 14:52:29.023386	2014-11-30 14:52:29.023386	f	0	\N	\N	2014-11-30 14:52:30.114767	f
109	17	20	1	http://wowubuntu.com/markdown28	wowubuntu.com	f	\N	2014-11-30 14:52:29.031374	2014-11-30 14:52:29.031374	f	0	\N	\N	2014-11-30 14:52:30.762052	f
106	17	20	1	https://code.google.com/p/kcpycamp/wiki/PythoniCamp?tm=6	code.google.com	f	\N	2014-11-30 14:52:29.00248	2014-11-30 14:52:29.00248	f	0	\N	PythoniCamp - kcpycamp - 社区简介 - PythoniCamp ~ 蟒营 工程基地 - Google Project Hosting	2014-11-30 14:52:32.006686	f
107	17	20	1	https://github.com/DengZuoheng/doc.jdc	github.com	f	\N	2014-11-30 14:52:29.015439	2014-11-30 14:52:29.015439	f	0	\N	DengZuoheng/doc.jdc · GitHub	2014-11-30 14:52:32.181343	f
105	17	20	1	https://gitcafe.com/PythoniCamp/PythoniCamp/wiki	gitcafe.com	f	\N	2014-11-30 14:52:28.986903	2014-11-30 14:52:28.986903	f	0	\N	Wiki Home · PythoniCamp/PythoniCamp - GitCafe	2014-11-30 14:52:32.392722	f
112	20	24	1	http://jnu-developer.com/guidelines	jnu-developer.com	t	\N	2014-12-08 15:56:03.108663	2014-12-08 15:56:03.108663	f	0	\N	\N	\N	f
110	20	24	1	http://www.emoji.codes/	www.emoji.codes	f	\N	2014-12-08 15:56:03.044339	2014-12-08 15:56:03.044339	f	0	\N	Cheat Sheet — Emoji.Codes	2014-12-08 15:56:05.256769	f
111	20	24	1	https://meta.discourse.org/t/what-do-user-trust-levels-do/4924	meta.discourse.org	f	\N	2014-12-08 15:56:03.09449	2014-12-08 15:56:03.09449	f	0	\N	What do user trust levels do? - Discourse Meta	2014-12-08 15:56:05.293422	f
\.


--
-- TOC entry 3412 (class 0 OID 0)
-- Dependencies: 185
-- Name: topic_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_links_id_seq', 112, true);


--
-- TOC entry 3276 (class 0 OID 19304)
-- Dependencies: 316
-- Data for Name: topic_search_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_search_data (topic_id, raw_data, locale, search_data) FROM stdin;
11	本 分类 用于 发布 有关 本站 管理 和 运行 的 通知 公告 及 相关 条款 本 分类 用于 发布 有关 本站 管理 和 运行 的 通知 公告 及 相关 条款 	zh_CN	'公告':12,27 '分类':2,17 '及':13,28 '发布':4,19 '和':8,23 '有关':5,20 '本':1,16 '本站':6,21 '条款':15,30 '用于':3,18 '的':10,25 '相关':14,29 '管理':7,22 '运行':9,24 '通知':11,26
12	关于 分类 ： 站 务 用 一段 简短 的 话 描述 分类 ， 并 替换 这 第 一段 的 内容 。 这段 文字 将 出现 在 分类 选择 区域 ， 所以 尽量 不要 超过 200 个 字符 。 当 您 编辑 了 这段 文字 或者 再次 分类 创建 了 一个 主题 后 ， 分类 才会 出现 在 分类 列表 中 。 在 接下 来的 一段 文字 中 输入 分类 的 详细 描述 信息 ， 可以 在这里 包含 在此 分类 下 讨论 的 规则 、 内容 导向 等等 。 考虑 这些 事情 ： 这个 分类 用 来做 什么 ？ 为什么 人们 选择 这个 分类 寻找 主题 ？ 这个 分类 和 其 	zh_CN	'200':31 '一个':45 '一段':6,16,58 '下':72 '不要':29 '个':32 '中':54,60 '为什么':87 '主题':46,93 '了':37,44 '事情':81 '人们':88 '什么':86 '信息':66 '关于':1 '其':97 '内容':18,76 '再次':41 '出现':22,50 '分类':2,11,24,42,48,52,62,71,83,91,95 '列表':53 '创建':43 '务':4 '包含':69 '区域':26 '可以':67 '后':47 '和':96 '在':23,51,55 '在此':70 '在这里':68 '字符':33 '寻找':92 '导向':77 '将':21 '尽量':28 '并':12 '当':34 '您':35 '或者':40 '所以':27 '才会':49 '接下':56 '描述':10,65 '文字':20,39,59 '替换':13 '来做':85 '来的':57 '用':5,84 '的':8,17,63,74 '站':3 '第':15 '等等':78 '简短':7 '编辑':36 '考虑':79 '规则':75 '讨论':73 '话':9 '详细':64 '超过':30 '输入':61 '这':14 '这个':82,90,94 '这些':80 '这段':19,38 '选择':25,89
13	关于 分类 ： 活动 用 一段 简短 的 话 描述 分类 ， 并 替换 这 第 一段 的 内容 。 这段 文字 将 出现 在 分类 选择 区域 ， 所以 尽量 不要 超过 200 个 字符 。 当 您 编辑 了 这段 文字 或者 再次 分类 创建 了 一个 主题 后 ， 分类 才会 出现 在 分类 列表 中 。 在 接下 来的 一段 文字 中 输入 分类 的 详细 描述 信息 ， 可以 在这里 包含 在此 分类 下 讨论 的 规则 、 内容 导向 等等 。 考虑 这些 事情 ： 这个 分类 用 来做 什么 ？ 为什么 人们 选择 这个 分类 寻找 主题 ？ 这个 分类 和 其 	zh_CN	'200':30 '一个':44 '一段':5,15,57 '下':71 '不要':28 '个':31 '中':53,59 '为什么':86 '主题':45,92 '了':36,43 '事情':80 '人们':87 '什么':85 '信息':65 '关于':1 '其':96 '内容':17,75 '再次':40 '出现':21,49 '分类':2,10,23,41,47,51,61,70,82,90,94 '列表':52 '创建':42 '包含':68 '区域':25 '可以':66 '后':46 '和':95 '在':22,50,54 '在此':69 '在这里':67 '字符':32 '寻找':91 '导向':76 '将':20 '尽量':27 '并':11 '当':33 '您':34 '或者':39 '所以':26 '才会':48 '接下':55 '描述':9,64 '文字':19,38,58 '替换':12 '来做':84 '来的':56 '活动':3 '用':4,83 '的':7,16,62,73 '第':14 '等等':77 '简短':6 '编辑':35 '考虑':78 '规则':74 '讨论':72 '话':8 '详细':63 '超过':29 '输入':60 '这':13 '这个':81,89,93 '这些':79 '这段':18,37 '选择':24,88
2	About the Meta category Discussion about this site its organization how it works and how we can improve it 	zh_CN	'about':1,6 'and':14 'can':17 'category':4 'discussion':5 'how':11,15 'improve':18 'it':12,19 'its':9 'meta':3 'organization':10 'site':8 'the':2 'this':7 'we':16 'works':13
5	FAQ Guidelines This is a Civilized Place for Public Discussion Please treat this discussion forum with the same respect you would a public park We too are a shared community resource — a place to share 	zh_CN	'a':5,22,28,32 'are':27 'civilized':6 'community':30 'discussion':10,14 'faq':1 'for':8 'forum':15 'guidelines':2 'is':4 'park':24 'place':7,33 'please':11 'public':9,23 'resource':31 'respect':19 'same':18 'share':35 'shared':29 'the':17 'this':3,13 'to':34 'too':26 'treat':12 'we':25 'with':16 'would':21 'you':20
6	Privacy Policy What information do we collect We collect information from you when you register on our site and gather data when you participate in the forum by reading writing and evaluating the conten 	zh_CN	'and':19,31 'by':28 'collect':7,9 'conten':34 'data':21 'do':5 'evaluating':32 'forum':27 'from':11 'gather':20 'in':25 'information':4,10 'on':16 'our':17 'participate':24 'policy':2 'privacy':1 'reading':29 'register':15 'site':18 'the':26,33 'we':6,8 'what':3 'when':13,22 'writing':30 'you':12,14,23
4	Terms of Service The following terms and conditions govern all use of the www example com website and all content services and products available at or through the website including but not limited to www e 	zh_CN	'all':10,19 'and':7,18,22 'at':25 'available':24 'but':31 'com':16 'conditions':8 'content':20 'e':36 'example':15 'following':5 'govern':9 'including':30 'limited':33 'not':32 'of':2,12 'or':26 'products':23 'service':3 'services':21 'terms':1,6 'the':4,13,28 'through':27 'to':34 'use':11 'website':17,29 'www':14,35
7	Assets for the site design This is a permanent topic visible only to staff for storing images and files used in the site design Don t delete it Here s how Reply to this topic Upload all the images you wi 	zh_CN	'a':8 'all':37 'and':18 'assets':1 'delete':27 'design':5,24 'don':25 'files':19 'for':2,15 'here':29 'how':31 'images':17,39 'in':21 'is':7 'it':28 'only':12 'permanent':9 'reply':32 's':30 'site':4,23 'staff':14 'storing':16 't':26 'the':3,22,38 'this':6,34 'to':13,33 'topic':10,35 'upload':36 'used':20 'visible':11 'wi':41 'you':40
9	Welcome to the Lounge Congratulations confetti ball confetti ball If you can see this topic you were recently promoted to regular trust level 3 You can now … Edit the title of any topic 	zh_CN	'3':24 'any':32 'ball':7,9 'can':12,26 'confetti':6,8 'congratulations':5 'edit':28 'if':10 'level':23 'lounge':4 'now':27 'of':31 'promoted':19 'recently':18 'regular':21 'see':13 'the':3,29 'this':14 'title':30 'to':2,20 'topic':15,33 'trust':22 'welcome':1 'were':17 'you':11,16,25
1	About the Lounge category A category exclusive to members with trust level 3 and higher 	zh_CN	'3':13 'a':5 'about':1 'and':14 'category':4,6 'exclusive':7 'higher':15 'level':12 'lounge':3 'members':9 'the':2 'to':8 'trust':11 'with':10
3	About the Staff category Private category for staff discussions Topics are only visible to admins and moderators 	zh_CN	'about':1 'admins':15 'and':16 'are':11 'category':4,6 'discussions':9 'for':7 'moderators':17 'only':12 'private':5 'staff':3,8 'the':2 'to':14 'topics':10 'visible':13
8	Welcome to Discourse The first paragraph of this pinned topic will be visible as a welcome message to all new visitors on your homepage It s important Edit this into a brief description of your community 	zh_CN	'a':15,31 'all':19 'as':14 'be':12 'brief':32 'community':36 'description':33 'discourse':3 'edit':28 'first':5 'homepage':24 'important':27 'into':30 'it':25 'message':17 'new':20 'of':7,34 'on':22 'paragraph':6 'pinned':9 's':26 'the':4 'this':8,29 'to':2,18 'topic':10 'visible':13 'visitors':21 'welcome':1,16 'will':11 'your':23,35
10	READ ME FIRST Admin Quick Start Guide Congratulations you are now the proud owner of your very own Civilized Discourse Construction Kit hatching chick hatching chick Admin Dashboard As an admin you have total control 	zh_CN	'admin':4,27,31 'an':30 'are':10 'as':29 'chick':24,26 'civilized':19 'congratulations':8 'construction':21 'control':35 'dashboard':28 'discourse':20 'first':3 'guide':7 'hatching':23,25 'have':33 'kit':22 'me':2 'now':11 'of':15 'own':18 'owner':14 'proud':13 'quick':5 'read':1 'start':6 'the':12 'total':34 'very':17 'you':9,32 'your':16
14	14 11 08 暨 大 蟒 营 开 营 纪要 蟒 营 开 营 纪要 概述 时间 2014 11 8 14 30 18 00 地点 暨 南 大学 珠海 校 区 教 702 参与 人员 学员 15 导师 Zoom Quiet 下面 简称 大妈 提出 作品 5 个 流程 1 自我介绍 姓名 和 所 读 的 专业 同时 说出 自己 认为 在 接下 去的 蟒 营 活动 中会 面临 的 问题 其中 一些 主要 问题 如下 团队 之间 的 沟通 、 学员 与 导师 的 沟 	zh_CN	'00':24 '08':3 '1':49 '11':2,19 '14':1,21 '15':37 '18':23 '2014':18 '30':22 '5':46 '702':33 '8':20 'quiet':40 'zoom':39 '一些':72 '下面':41 '与':81 '专业':56 '个':47 '中会':67 '主要':73 '之间':77 '人员':35 '作品':45 '其中':71 '区':31 '南':27 '去的':63 '参与':34 '同时':57 '和':52 '团队':76 '在':61 '地点':25 '大':5 '大妈':43 '大学':28 '如下':75 '姓名':51 '学员':36,80 '导师':38,82 '开':8,13 '所':53 '接下':62 '提出':44 '教':32 '时间':17 '暨':4,26 '校':30 '概述':16 '沟':84 '沟通':79 '活动':66 '流程':48 '珠海':29 '的':55,69,78,83 '简称':42 '纪要':10,15 '自己':59 '自我介绍':50 '营':7,9,12,14,65 '蟒':6,11,64 '认为':60 '说出':58 '读':54 '问题':70,74 '面临':68
15	Welcome to JDC JDC 的 成立 JDC 成 立于 2014 年下 半年 由 移动 公司 支持 以及 暨 大 珠 区 一群 爱好 编程 的 同学 组成 JDC 的 主要 分类 JDC 分为 移动 MM 成员 和 JDC 成员 都以 小组 的 形式 来 完成 一个 特定 的 项目 当然 也可以 自己 发起 项目 每个 小组 都 分 为主 程 测试 产品 设计 美工 四个 方面 的 工作 JDC 现有 主要 活动 由 珠海 GDG 负责人 周 琦 带领 的 蟒 营 学习 活动 	zh_CN	'2014':10 'gdg':75 'jdc':3,4,7,28,32,38,69 'mm':35 'to':2 'welcome':1 '一个':46 '一群':22 '为主':59 '主要':30,71 '也可以':51 '产品':62 '以及':17 '公司':15 '分':58 '分为':33 '分类':31 '区':21 '半年':12 '发起':53 '同学':26 '周':77 '和':37 '四个':65 '大':19 '学习':83 '完成':45 '小组':41,56 '工作':68 '带领':79 '年下':11 '当然':50 '形式':43 '成':8 '成员':36,39 '成立':6 '支持':16 '方面':66 '暨':18 '来':44 '每个':55 '活动':72,84 '测试':61 '爱好':23 '特定':47 '现有':70 '珠':20 '珠海':74 '琦':78 '由':13,73 '的':5,25,29,42,48,67,80 '移动':14,34 '程':60 '立于':9 '组成':27 '编程':24 '美工':64 '自己':52 '营':82 '蟒':81 '设计':63 '负责人':76 '都':57 '都以':40 '项目':49,54
16	14 11 30 暨 大 开发者 社区 logo 发布 经过 两周 的 设计 JDC 的 logo 定稿 现 发布 如下 大 图标 网 站 图标 小 图标 构图 是 电脑 显示器 和 地球仪 意在 JDC 将 地球 搬 bian 进 电脑 感谢 yinnjiuu sina com 的 设计 和 实现 github 地址 https github com DengZuoheng doc jdc tree master logo 	zh_CN	'11':2 '14':1 '30':3 'bian':39 'com':45,54 'dengzuoheng':55 'doc':56 'github':50,53 'https':52 'jdc':14,35,57 'logo':8,16,60 'master':59 'sina':44 'tree':58 'yinnjiuu':43 '两周':11 '发布':9,19 '和':32,48 '图标':22,25,27 '地址':51 '地球':37 '地球仪':33 '大':5,21 '如下':20 '定稿':17 '实现':49 '将':36 '小':26 '开发者':6 '意在':34 '感谢':42 '搬':38 '是':29 '显示器':31 '暨':4 '构图':28 '现':18 '电脑':30,41 '的':12,15,46 '社区':7 '站':24 '经过':10 '网':23 '设计':13,47 '进':40
17	欢迎 来到 暨 大 开发者 社区 欢迎 来到 暨 大 开发者 社区 暨 大 开发者 社区 是由 暨 南 大学 一群 技术 爱好者 组成 的 开源 技术 社区 我们 通常 将 暨 大 开发者 社区 简称 为 JDC JDC 的 前身 是 暨 南 大学 金山 软件 俱乐部 KSC 目前 JDC 与 KSC 时期 一样 托管 于 暨 大 电气 信息 学院 团委 学生会 我们 的 目标 在于 提供 一个 让 大家 一起 折腾 编程 开发 的 平台 任何人 都可以 加入 暨 大 开发者 社区 只要 你对 编程 感兴趣 崇尚 开源 精神 在 暨 大 开发者 社区 	zh_CN	'jdc':38,39,51 'ksc':49,53 '一个':70 '一样':55 '一群':21 '一起':73 '与':52 '为':37 '于':57 '任何人':79 '你对':87 '信息':61 '俱乐部':48 '前身':41 '加入':81 '南':19,44 '只要':86 '团委':63 '在':93 '在于':68 '大':4,10,14,33,59,83,95 '大学':20,45 '大家':72 '学生会':64 '学院':62 '将':31 '崇尚':90 '平台':78 '开发':76 '开发者':5,11,15,34,84,96 '开源':26,91 '感兴趣':89 '我们':29,65 '托管':56 '技术':22,27 '折腾':74 '提供':69 '时期':54 '是':42 '是由':17 '暨':3,9,13,18,32,43,58,82,94 '来到':2,8 '欢迎':1,7 '爱好者':23 '电气':60 '的':25,40,66,77 '目前':50 '目标':67 '社区':6,12,16,28,35,85,97 '简称':36 '精神':92 '组成':24 '编程':75,88 '让':71 '软件':47 '通常':30 '都可以':80 '金山':46
18	14 11 16 蟒 营 迭代 演示 w1 纪要 蟒 营 迭代 演示 W1 概述 时间 ： 11 月 16 日 下午 15 00 18 00 地点 ： 暨 南 大学 珠海 校 区 教 409 参与 人员 ： 蟒 营 学员 ： 20 导师 ： Zoom Quiet 以下 简称 “ 大妈 ” 流程 1 大妈 发言 ， 讲明 本周 迭代 演示 所要 介绍 的 事项 产品 名称 谁 做了 什么 下周 做 什么 在此之前 ， 投影 仪 出现 了 问题 ， 由此 引 	zh_CN	'00':23,25 '1':48 '11':2,17 '14':1 '15':22 '16':3,19 '18':24 '20':40 '409':34 'quiet':43 'w1':8,14 'zoom':42 '下午':21 '下周':64 '了':71 '事项':58 '产品':59 '人员':36 '什么':63,66 '介绍':56 '以下':44 '仪':69 '做':65 '做了':62 '出现':70 '区':32 '南':28 '参与':35 '发言':50 '名称':60 '在此之前':67 '地点':26 '大妈':46,49 '大学':29 '学员':39 '导师':41 '引':74 '所要':55 '投影':68 '教':33 '日':20 '时间':16 '暨':27 '月':18 '本周':52 '校':31 '概述':15 '流程':47 '演示':7,13,54 '珠海':30 '由此':73 '的':57 '简称':45 '纪要':9 '营':5,11,38 '蟒':4,10,37 '讲明':51 '谁':61 '迭代':6,12,53 '问题':72
19	14 11 22 蟒 营 迭代 演示 w2 纪要 蟒 营 迭代 演示 W2 概述 时间 ： 11 月 22 日 下午 15 00 17 30 地点 ： 暨 南 大学 珠海 校 区 教 702 参与 人员 ： 蟒 营 学员 ： 10 旁听 2 大妈 1 Zoom Quiet 流程 1 演示 （ 15 00 15 40 ） 第 一组 组 我吧 Take me up 2 人 上周 开通 了 微 信 的 注册 号 设置 了 注册 账号 、 组团 等 大致 的 基本 功能 下 	zh_CN	'00':23,51 '1':44,48 '10':40 '11':2,17 '14':1 '15':22,50,52 '17':24 '2':42,61 '22':3,19 '30':25 '40':53 '702':34 'me':59 'quiet':46 'take':58 'up':60 'w2':8,14 'zoom':45 '一组':55 '上周':63 '下':81 '下午':21 '了':65,72 '人':62 '人员':36 '信':67 '功能':80 '区':32 '南':28 '参与':35 '号':70 '地点':26 '基本':79 '大妈':43 '大学':29 '大致':77 '学员':39 '开通':64 '微':66 '我吧':57 '教':33 '旁听':41 '日':20 '时间':16 '暨':27 '月':18 '校':31 '概述':15 '注册':69,73 '流程':47 '演示':7,13,49 '珠海':30 '的':68,78 '第':54 '等':76 '纪要':9 '组':56 '组团':75 '营':5,11,38 '蟒':4,10,37 '设置':71 '账号':74 '迭代':6,12
20	欢迎 来到 暨 大 开发者 社区 ！ 感谢 加入 暨 大 开发者 社区 ， 并且 欢迎 ！ 这条 私信 包含 了 一些 可以 让 您 快速 开始 的 技巧 提示 ： 保持 滚动 没有 下 一页 按钮 或者 页码 — — 要 阅读 更多 ， 只需 要 继续 向下 滚动 页面 ！ 当 新的 帖子 加载 后 ， 它们 会 自动 显示 。 我 在 哪儿 ？ 要 搜索 ， 访问 您的 用户 页面 或者 菜单 ， 使用 右上 角 的 图标 ☰ 按钮 。 任何 主题 标题 点击 后 都将 引导 您 至 下一个 未读 的 帖子 。 	zh_CN	'一些':19 '一页':32 '下':31 '下一个':80 '主题':72 '了':18 '任何':71 '会':51 '使用':65 '保持':28 '加入':8 '加载':48 '包含':17 '只需':39 '可以':20 '右上':66 '后':49,75 '向下':42 '哪儿':56 '图标':69 '在':55 '大':4,10 '它们':50 '帖子':47,83 '并且':13 '开发者':5,11 '开始':24 '引导':77 '当':45 '快速':23 '您':22,78 '您的':60 '感谢':7 '我':54 '或者':34,63 '技巧':26 '按钮':33,70 '提示':27 '搜索':58 '新的':46 '显示':53 '暨':3,9 '更多':38 '未读':81 '来到':2 '标题':73 '欢迎':1,14 '没有':30 '滚动':29,43 '点击':74 '用户':61 '的':25,68,82 '社区':6,12 '私信':16 '继续':41 '自动':52 '至':79 '菜单':64 '要':36,40,57 '角':67 '让':21 '访问':59 '这条':15 '都将':76 '阅读':37 '页码':35 '页面':44,62
\.


--
-- TOC entry 3144 (class 0 OID 16906)
-- Dependencies: 184
-- Data for Name: topic_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_users (user_id, topic_id, starred, posted, last_read_post_number, highest_seen_post_number, starred_at, last_visited_at, first_visited_at, notification_level, notifications_changed_at, notifications_reason_id, total_msecs_viewed, cleared_pinned_at, unstarred_at, id, last_emailed_post_number) FROM stdin;
-1	1	f	t	1	1	\N	2014-11-01 07:31:03.395075	2014-11-01 07:31:03.395075	3	2014-11-01 07:31:03.39287	1	0	\N	\N	1	\N
-1	2	f	t	1	1	\N	2014-11-01 07:31:03.754675	2014-11-01 07:31:03.754675	3	2014-11-01 07:31:03.753667	1	0	\N	\N	2	\N
-1	3	f	t	1	1	\N	2014-11-01 07:31:04.061588	2014-11-01 07:31:04.061588	3	2014-11-01 07:31:04.060535	1	0	\N	\N	3	\N
-1	4	f	t	2	2	\N	2014-11-01 07:31:04.263385	2014-11-01 07:31:04.263385	3	2014-11-01 07:31:04.26217	1	0	\N	\N	4	\N
-1	5	f	t	2	2	\N	2014-11-01 07:31:05.117901	2014-11-01 07:31:05.117901	3	2014-11-01 07:31:05.117122	1	0	\N	\N	5	\N
-1	6	f	t	2	2	\N	2014-11-01 07:31:05.58882	2014-11-01 07:31:05.58882	3	2014-11-01 07:31:05.58809	1	0	\N	\N	6	\N
-1	7	f	t	1	1	\N	2014-11-01 07:31:05.857851	2014-11-01 07:31:05.857851	3	2014-11-01 07:31:05.857152	1	0	\N	\N	7	\N
-1	9	f	t	1	1	\N	2014-11-01 07:31:06.039313	2014-11-01 07:31:06.039313	3	2014-11-01 07:31:06.038648	1	0	\N	\N	9	\N
-1	10	f	t	1	1	\N	2014-11-01 07:31:06.37468	2014-11-01 07:31:06.37468	3	2014-11-01 07:31:06.373677	1	0	\N	\N	10	\N
1	17	f	t	2	2	\N	2014-11-30 14:52:28.311546	2014-11-30 14:52:28.311546	3	2014-11-30 14:52:28.307777	1	3699947	\N	\N	23	\N
15	15	f	f	\N	\N	\N	2014-11-30 14:53:26.28195	2014-11-23 02:40:38.3258	1	\N	\N	0	\N	\N	20	\N
1	15	f	f	1	0	\N	2014-11-23 02:40:37.409629	2014-11-23 02:40:37.409629	3	2014-11-23 02:40:37.406694	1	351573	\N	\N	19	\N
16	16	f	f	\N	\N	\N	2014-11-30 15:15:20.895553	2014-11-30 13:34:54.795417	1	\N	\N	0	\N	\N	22	\N
1	19	f	t	1	1	\N	2014-11-30 15:55:18.590101	2014-11-30 15:55:18.590101	3	2014-11-30 15:55:18.58635	1	153209	\N	\N	27	\N
1	20	f	t	1	1	\N	2014-12-08 15:56:02.062608	2014-12-08 15:56:02.062608	3	2014-12-08 15:56:02.059577	1	0	\N	\N	29	\N
19	19	f	f	\N	\N	\N	2014-12-08 15:56:16.62658	2014-11-30 15:55:20.33472	1	\N	\N	0	\N	\N	28	\N
13	13	f	f	\N	\N	\N	2014-12-08 15:56:19.973427	2014-11-01 08:05:10.52768	1	\N	\N	0	\N	\N	15	\N
6	19	f	f	1	1	\N	2014-12-08 15:56:18.472117	2014-12-08 15:56:18.472117	1	\N	\N	31998	\N	\N	31	\N
11	11	f	f	\N	\N	\N	2014-11-01 07:55:27.846543	2014-11-01 07:55:27.846543	1	\N	\N	0	\N	\N	14	\N
1	16	f	t	1	1	\N	2014-11-30 13:34:53.133474	2014-11-30 13:34:53.133474	3	2014-11-30 13:34:53.129414	1	113540	\N	\N	21	\N
6	20	f	f	\N	\N	\N	2014-12-08 15:56:02.093872	2014-12-08 15:56:02.093872	3	2014-12-08 15:56:02.092561	2	0	\N	\N	30	1
1	11	f	f	1	0	\N	2014-11-01 07:55:26.765271	2014-11-01 07:55:26.765271	3	2014-11-01 07:55:26.763084	1	121483	\N	\N	13	\N
1	13	f	f	1	1	\N	2014-11-01 08:05:12.4572	2014-11-01 08:05:12.4572	1	\N	\N	130843	\N	\N	16	\N
17	17	f	f	\N	\N	\N	2014-12-22 14:09:48.711981	2014-11-30 14:52:29.833861	1	\N	\N	0	\N	\N	24	\N
14	14	f	f	\N	\N	\N	2014-12-02 13:03:33.798932	2014-11-12 16:38:56.79082	1	\N	\N	0	\N	\N	18	\N
1	14	f	t	1	1	\N	2014-11-12 16:38:54.693303	2014-11-12 16:38:54.693303	3	2014-11-12 16:38:54.690143	1	162114	\N	\N	17	\N
18	18	f	f	\N	\N	\N	2014-12-02 13:06:42.466099	2014-11-30 15:36:41.340728	1	\N	\N	0	\N	\N	26	\N
1	18	f	t	1	1	\N	2014-11-30 15:36:39.644975	2014-11-30 15:36:39.644975	3	2014-11-30 15:36:39.642383	1	1078019	\N	\N	25	\N
8	8	f	f	\N	\N	\N	2014-11-30 14:42:38.482652	2014-11-01 07:44:04.220899	1	\N	\N	0	\N	\N	11	\N
-1	8	f	f	0	0	\N	2014-11-01 07:31:05.959388	2014-11-01 07:31:05.959388	3	2014-11-01 07:31:05.958693	1	0	\N	\N	8	\N
1	8	f	f	1	0	\N	2014-11-01 07:44:06.17631	2014-11-01 07:44:06.17631	2	\N	\N	979678	\N	\N	12	\N
\.


--
-- TOC entry 3413 (class 0 OID 0)
-- Dependencies: 255
-- Name: topic_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_users_id_seq', 31, true);


--
-- TOC entry 3141 (class 0 OID 16879)
-- Dependencies: 181
-- Data for Name: topic_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_views (topic_id, viewed_at, user_id, ip_address) FROM stdin;
8	2014-11-01	1	106.185.37.220
11	2014-11-01	1	106.185.37.220
13	2014-11-01	1	106.185.37.220
8	2014-11-01	\N	113.76.163.190
8	2014-11-01	\N	198.27.82.153
8	2014-11-01	\N	66.249.77.107
8	2014-11-01	\N	69.58.178.58
2	2014-11-02	\N	208.107.52.27
12	2014-11-02	\N	208.107.52.27
13	2014-11-02	\N	208.107.52.27
8	2014-11-02	\N	208.107.52.27
8	2014-11-03	\N	66.249.65.157
8	2014-11-03	\N	182.118.25.224
8	2014-11-03	\N	162.210.196.98
2	2014-11-03	\N	104.131.74.168
12	2014-11-03	\N	104.131.74.168
13	2014-11-03	\N	104.131.74.168
8	2014-11-04	\N	69.58.178.59
8	2014-11-04	\N	117.57.245.41
8	2014-11-04	\N	66.249.71.100
8	2014-11-04	\N	115.193.160.135
8	2014-11-05	\N	206.183.1.74
8	2014-11-05	\N	123.125.71.36
8	2014-11-05	\N	207.46.13.83
8	2014-11-06	\N	66.249.69.203
8	2014-11-06	\N	66.249.69.109
8	2014-11-06	\N	101.226.166.201
8	2014-11-07	\N	157.55.39.32
8	2014-11-08	\N	182.118.21.201
13	2014-11-08	\N	123.125.71.17
8	2014-11-09	\N	123.125.71.39
8	2014-11-09	\N	113.108.139.56
13	2014-11-10	\N	123.125.71.91
8	2014-11-10	\N	101.226.168.206
8	2014-11-11	\N	66.249.64.69
12	2014-11-11	\N	123.125.71.43
8	2014-11-12	\N	38.100.21.64
14	2014-11-12	1	106.185.37.220
14	2014-11-12	\N	101.226.33.238
14	2014-11-12	\N	113.76.162.10
14	2014-11-12	\N	66.249.65.87
14	2014-11-12	\N	66.249.65.157
14	2014-11-12	\N	66.249.65.153
13	2014-11-12	\N	66.249.65.87
13	2014-11-12	\N	66.249.65.157
14	2014-11-13	\N	217.79.181.38
8	2014-11-13	\N	66.249.79.126
14	2014-11-14	\N	69.58.178.59
13	2014-11-14	\N	69.58.178.59
8	2014-11-14	\N	101.226.167.234
14	2014-11-14	\N	192.99.158.218
14	2014-11-14	\N	66.249.79.130
8	2014-11-14	\N	66.249.79.138
12	2014-11-14	\N	66.249.79.149
13	2014-11-14	\N	66.249.79.122
12	2014-11-14	\N	66.249.79.1
14	2014-11-15	\N	182.118.22.201
14	2014-11-15	\N	84.104.16.37
8	2014-11-15	\N	84.104.16.37
14	2014-11-15	\N	66.249.77.117
8	2014-11-15	\N	66.249.77.117
8	2014-11-15	\N	66.249.77.137
14	2014-11-15	\N	66.249.77.147
14	2014-11-15	\N	72.14.199.4
8	2014-11-15	\N	72.14.199.4
13	2014-11-15	\N	66.249.77.117
14	2014-11-15	\N	72.14.199.111
13	2014-11-15	\N	66.249.77.137
8	2014-11-15	\N	72.14.199.117
13	2014-11-15	\N	72.14.199.9
13	2014-11-15	\N	72.14.199.111
14	2014-11-15	\N	220.181.108.158
14	2014-11-15	\N	54.166.13.238
8	2014-11-15	\N	54.166.13.238
14	2014-11-15	\N	54.147.192.162
8	2014-11-15	\N	54.147.192.162
8	2014-11-16	\N	54.160.35.90
14	2014-11-16	\N	54.166.245.79
8	2014-11-16	\N	54.197.186.120
14	2014-11-16	\N	23.23.46.182
8	2014-11-16	\N	38.100.21.61
14	2014-11-16	\N	38.100.21.61
14	2014-11-16	\N	212.129.40.46
14	2014-11-16	\N	66.249.79.19
13	2014-11-16	\N	66.249.79.19
8	2014-11-17	\N	182.118.21.251
13	2014-11-17	\N	198.245.51.90
8	2014-11-17	\N	119.147.146.189
14	2014-11-17	\N	182.118.25.220
14	2014-11-17	\N	182.118.21.229
2	2014-11-18	\N	123.125.71.95
13	2014-11-18	\N	148.251.124.174
8	2014-11-19	\N	101.226.168.230
14	2014-11-19	\N	123.125.71.113
13	2014-11-19	\N	182.118.22.206
14	2014-11-20	\N	38.100.21.64
8	2014-11-20	\N	101.226.169.204
8	2014-11-21	\N	69.58.178.56
14	2014-11-21	\N	69.58.178.56
13	2014-11-21	\N	69.58.178.56
8	2014-11-21	\N	123.125.71.32
14	2014-11-21	\N	101.226.166.206
8	2014-11-21	\N	182.118.25.229
14	2014-11-22	\N	66.249.79.118
13	2014-11-22	\N	66.249.79.134
13	2014-11-22	\N	101.226.166.248
14	2014-11-22	\N	182.118.25.213
8	2014-11-22	\N	54.166.97.209
14	2014-11-22	\N	54.197.145.176
8	2014-11-22	\N	54.221.139.117
14	2014-11-22	\N	54.160.13.90
14	2014-11-22	\N	174.129.67.83
8	2014-11-22	\N	54.160.13.90
14	2014-11-22	\N	54.80.74.240
8	2014-11-22	\N	174.129.101.125
15	2014-11-23	1	113.108.139.40
15	2014-11-23	\N	119.147.146.189
14	2014-11-23	\N	188.165.15.224
8	2014-11-23	\N	188.165.15.224
13	2014-11-23	\N	182.118.20.217
14	2014-11-24	\N	207.46.13.131
8	2014-11-24	\N	207.46.13.114
12	2014-11-25	\N	123.125.71.104
15	2014-11-25	\N	198.245.51.90
14	2014-11-26	\N	157.55.39.23
15	2014-11-26	\N	148.251.183.105
15	2014-11-26	\N	66.249.65.66
15	2014-11-26	\N	66.249.65.157
15	2014-11-26	\N	66.249.65.153
15	2014-11-26	\N	220.181.108.119
15	2014-11-26	\N	5.9.123.141
13	2014-11-27	\N	182.118.22.219
2	2014-11-27	\N	123.125.71.34
15	2014-11-27	\N	144.76.8.132
14	2014-11-27	\N	123.125.71.39
13	2014-11-27	\N	182.118.22.141
15	2014-11-27	\N	101.226.169.226
15	2014-11-28	\N	182.118.21.243
14	2014-11-29	\N	153.34.163.74
8	2014-11-29	\N	153.34.163.74
15	2014-11-29	\N	153.34.163.74
8	2014-11-29	\N	54.147.227.113
15	2014-11-29	\N	54.147.227.113
8	2014-11-29	\N	50.17.64.184
15	2014-11-29	\N	50.17.64.184
15	2014-11-29	\N	54.83.249.107
8	2014-11-29	\N	54.83.249.107
15	2014-11-30	\N	54.197.130.37
8	2014-11-30	\N	54.197.130.37
14	2014-11-30	\N	153.121.51.217
8	2014-11-30	\N	116.251.210.183
16	2014-11-30	1	106.186.22.90
17	2014-11-30	1	106.186.22.90
17	2014-11-30	\N	66.249.79.1
16	2014-11-30	\N	66.249.79.149
17	2014-11-30	\N	66.249.79.149
17	2014-11-30	\N	66.249.79.157
18	2014-11-30	1	106.186.22.90
19	2014-11-30	1	106.186.22.90
14	2014-11-30	\N	101.226.168.250
16	2014-12-01	\N	124.116.237.151
19	2014-12-01	\N	66.249.79.1
18	2014-12-01	\N	66.249.79.149
16	2014-12-01	\N	66.249.79.1
2	2014-12-01	\N	66.249.79.149
18	2014-12-01	\N	66.249.79.1
12	2014-12-01	\N	66.249.79.157
16	2014-12-01	\N	68.180.228.163
19	2014-12-01	\N	68.180.228.163
18	2014-12-01	\N	68.180.228.163
14	2014-12-01	\N	68.180.228.163
18	2014-12-01	\N	68.180.228.171
16	2014-12-01	\N	68.180.228.171
13	2014-12-01	\N	68.180.228.171
12	2014-12-01	\N	68.180.228.171
14	2014-12-01	\N	68.180.228.171
19	2014-12-01	\N	68.180.228.171
2	2014-12-01	\N	68.180.228.171
2	2014-12-01	\N	68.180.228.163
17	2014-12-01	\N	68.180.228.171
12	2014-12-01	\N	68.180.228.163
17	2014-12-01	\N	68.180.228.163
13	2014-12-01	\N	68.180.228.163
14	2014-12-01	\N	101.226.167.208
18	2014-12-02	\N	37.59.60.67
19	2014-12-02	\N	37.59.60.67
16	2014-12-02	\N	37.59.60.67
17	2014-12-02	\N	37.59.60.67
14	2014-12-02	\N	207.46.13.89
18	2014-12-02	\N	198.27.82.153
19	2014-12-02	\N	198.27.82.153
16	2014-12-02	\N	198.27.82.153
17	2014-12-02	\N	198.27.82.153
14	2014-12-02	\N	101.226.66.172
19	2014-12-02	\N	180.153.114.199
19	2014-12-02	\N	66.249.75.74
18	2014-12-02	\N	66.249.75.106
19	2014-12-02	\N	66.249.75.141
18	2014-12-02	\N	66.249.75.157
2	2014-12-02	\N	178.63.49.82
19	2014-12-02	\N	66.249.69.235
17	2014-12-02	\N	66.249.69.219
18	2014-12-02	\N	66.249.69.235
16	2014-12-02	\N	66.249.69.203
17	2014-12-02	\N	66.249.75.4
18	2014-12-02	\N	66.249.75.22
19	2014-12-02	\N	66.249.75.22
16	2014-12-02	\N	66.249.75.4
2	2014-12-02	\N	66.249.69.235
12	2014-12-02	\N	66.249.69.219
2	2014-12-02	\N	66.249.75.22
2	2014-12-02	\N	66.249.75.173
12	2014-12-02	\N	66.249.75.4
14	2014-12-03	\N	66.249.75.22
13	2014-12-03	\N	66.249.75.22
17	2014-12-03	\N	69.58.178.59
2	2014-12-03	\N	69.58.178.59
19	2014-12-03	\N	69.58.178.59
18	2014-12-03	\N	69.58.178.59
16	2014-12-03	\N	69.58.178.59
16	2014-12-03	\N	66.249.75.157
12	2014-12-03	\N	212.129.40.46
18	2014-12-03	\N	62.210.138.176
19	2014-12-03	\N	62.210.138.176
16	2014-12-03	\N	62.210.138.176
17	2014-12-03	\N	62.210.138.176
18	2014-12-03	\N	94.113.118.216
19	2014-12-03	\N	94.113.118.216
16	2014-12-03	\N	94.113.118.216
17	2014-12-03	\N	94.113.118.216
16	2014-12-04	\N	182.118.20.214
18	2014-12-04	\N	182.118.20.251
17	2014-12-04	\N	182.118.20.164
2	2014-12-04	\N	136.243.5.87
2	2014-12-04	\N	66.249.67.157
13	2014-12-04	\N	207.46.13.68
19	2014-12-05	\N	66.249.67.1
18	2014-12-05	\N	66.249.67.1
19	2014-12-05	\N	123.125.71.31
2	2014-12-05	\N	162.210.196.129
12	2014-12-05	\N	195.154.99.194
17	2014-12-05	\N	23.99.83.149
19	2014-12-05	\N	23.99.83.149
18	2014-12-05	\N	23.99.83.149
16	2014-12-05	\N	23.99.83.149
14	2014-12-05	\N	23.99.83.149
2	2014-12-05	\N	23.99.83.149
18	2014-12-06	\N	123.125.71.60
17	2014-12-06	\N	23.20.102.233
19	2014-12-06	\N	23.20.102.233
17	2014-12-06	\N	54.237.71.147
19	2014-12-06	\N	54.237.71.147
18	2014-12-06	\N	123.125.71.89
17	2014-12-06	\N	220.181.108.95
17	2014-12-06	\N	188.165.15.89
18	2014-12-06	\N	188.165.15.5
16	2014-12-06	\N	123.125.71.51
19	2014-12-06	\N	220.181.108.108
13	2014-12-06	\N	157.55.39.182
19	2014-12-06	\N	188.165.15.89
16	2014-12-06	\N	188.165.15.5
12	2014-12-06	\N	188.165.15.234
2	2014-12-06	\N	188.165.15.234
14	2014-12-07	\N	188.165.15.89
17	2014-12-07	\N	123.125.71.60
19	2014-12-07	\N	188.165.15.132
19	2014-12-07	\N	182.118.25.215
16	2014-12-07	\N	101.226.167.198
17	2014-12-07	\N	101.226.169.212
16	2014-12-07	\N	188.165.15.210
18	2014-12-07	\N	188.165.15.210
17	2014-12-07	\N	188.165.15.132
18	2014-12-07	\N	66.249.65.170
19	2014-12-07	\N	66.249.65.162
16	2014-12-07	\N	123.125.71.23
13	2014-12-07	\N	188.165.15.110
12	2014-12-07	\N	101.226.166.205
13	2014-12-07	\N	101.226.168.224
13	2014-12-08	\N	101.226.168.198
18	2014-12-08	\N	101.226.168.213
19	2014-12-08	\N	101.226.168.217
18	2014-12-08	\N	182.118.22.223
2	2014-12-08	\N	101.226.167.237
17	2014-12-08	\N	113.108.139.52
14	2014-12-08	\N	113.76.199.104
16	2014-12-08	\N	113.76.199.104
19	2014-12-08	6	106.186.22.90
19	2014-12-08	\N	101.226.33.216
2	2014-12-08	\N	66.249.79.1
14	2014-12-08	\N	157.55.39.115
19	2014-12-09	\N	66.249.79.149
13	2014-12-09	\N	188.165.15.224
17	2014-12-09	\N	188.165.15.138
17	2014-12-09	\N	188.165.15.224
13	2014-12-09	\N	220.181.108.102
2	2014-12-09	\N	66.249.71.189
19	2014-12-09	\N	176.123.20.5
13	2014-12-09	\N	176.123.20.5
18	2014-12-09	\N	176.123.20.5
14	2014-12-09	\N	176.123.20.5
17	2014-12-09	\N	176.123.20.5
16	2014-12-09	\N	176.123.20.5
12	2014-12-09	\N	176.123.20.5
2	2014-12-09	\N	176.123.20.5
13	2014-12-10	\N	220.181.108.145
18	2014-12-10	\N	123.125.71.39
17	2014-12-11	\N	123.125.71.81
12	2014-12-11	\N	188.165.15.21
12	2014-12-11	\N	188.165.15.206
12	2014-12-12	\N	182.118.22.217
19	2014-12-12	\N	182.118.21.217
16	2014-12-12	\N	101.226.167.251
18	2014-12-12	\N	123.125.71.38
16	2014-12-13	\N	38.100.21.64
19	2014-12-13	\N	38.100.21.64
18	2014-12-13	\N	38.100.21.64
17	2014-12-13	\N	38.100.21.64
17	2014-12-13	\N	85.17.73.171
14	2014-12-13	\N	85.17.73.171
19	2014-12-13	\N	85.17.73.171
16	2014-12-13	\N	85.17.73.171
18	2014-12-13	\N	85.17.73.171
2	2014-12-13	\N	182.118.20.219
17	2014-12-13	\N	182.118.20.216
16	2014-12-13	\N	123.125.71.17
18	2014-12-13	\N	182.118.21.218
19	2014-12-13	\N	182.118.21.211
13	2014-12-13	\N	220.181.108.122
13	2014-12-14	\N	188.165.15.200
19	2014-12-14	\N	54.204.128.19
17	2014-12-14	\N	54.204.128.19
19	2014-12-14	\N	54.211.206.42
17	2014-12-14	\N	54.211.206.42
17	2014-12-14	\N	54.196.37.141
19	2014-12-14	\N	54.196.37.141
17	2014-12-14	\N	23.23.38.19
19	2014-12-14	\N	23.23.38.19
17	2014-12-14	\N	69.58.178.58
2	2014-12-14	\N	69.58.178.58
19	2014-12-14	\N	69.58.178.58
18	2014-12-14	\N	69.58.178.58
16	2014-12-14	\N	69.58.178.58
14	2014-12-14	\N	69.58.178.58
2	2014-12-15	\N	188.165.15.90
14	2014-12-15	\N	182.118.21.237
17	2014-12-15	\N	182.118.25.231
16	2014-12-15	\N	182.118.25.222
18	2014-12-15	\N	182.118.22.215
19	2014-12-15	\N	101.226.166.226
14	2014-12-15	\N	66.249.79.1
2	2014-12-15	\N	66.249.79.19
16	2014-12-16	\N	66.249.79.11
18	2014-12-16	\N	78.158.11.226
2	2014-12-16	\N	188.165.15.27
16	2014-12-17	\N	120.197.193.103
12	2014-12-17	\N	188.165.15.55
16	2014-12-17	\N	220.181.108.160
18	2014-12-17	\N	117.135.212.103
19	2014-12-17	\N	66.249.64.63
18	2014-12-17	\N	66.249.64.59
16	2014-12-17	\N	101.226.167.231
17	2014-12-17	\N	101.226.166.251
2	2014-12-17	\N	182.118.20.221
17	2014-12-17	\N	66.249.64.61
14	2014-12-18	\N	101.226.167.217
14	2014-12-18	\N	188.165.15.99
17	2014-12-18	\N	66.249.64.67
18	2014-12-18	\N	182.118.21.224
17	2014-12-18	\N	188.165.15.127
19	2014-12-19	\N	188.165.15.99
18	2014-12-19	\N	123.125.71.19
12	2014-12-19	\N	101.226.166.247
16	2014-12-19	\N	101.226.168.205
2	2014-12-19	\N	182.118.25.201
17	2014-12-19	\N	182.118.22.215
19	2014-12-19	\N	101.226.166.218
13	2014-12-19	\N	101.226.168.236
18	2014-12-19	\N	101.226.167.203
19	2014-12-20	\N	38.100.21.67
18	2014-12-20	\N	38.100.21.67
16	2014-12-20	\N	38.100.21.67
14	2014-12-20	\N	38.100.21.67
17	2014-12-20	\N	38.100.21.67
12	2014-12-20	\N	123.125.71.87
14	2014-12-20	\N	101.226.168.239
12	2014-12-21	\N	123.125.71.24
12	2014-12-21	\N	123.125.71.28
17	2014-12-22	\N	66.249.67.122
16	2014-12-22	\N	66.249.67.122
12	2014-12-22	\N	182.118.20.235
16	2014-12-22	\N	182.118.22.228
17	2014-12-22	\N	123.125.71.32
18	2014-12-22	\N	188.165.15.36
2	2014-12-22	\N	66.249.67.130
19	2014-12-22	\N	54.81.95.195
17	2014-12-22	\N	54.81.95.195
19	2014-12-22	\N	54.145.98.136
17	2014-12-22	\N	54.145.98.136
17	2014-12-22	\N	54.161.157.77
19	2014-12-22	\N	54.161.157.77
17	2014-12-22	\N	54.237.229.203
19	2014-12-22	\N	54.237.229.203
12	2014-12-22	\N	66.249.67.138
19	2014-12-22	\N	123.125.71.109
14	2014-12-22	\N	220.181.108.119
16	2014-12-22	\N	101.226.169.203
2	2014-12-22	\N	182.118.25.210
17	2014-12-22	\N	101.226.167.228
14	2014-12-22	\N	101.226.167.210
17	2014-12-23	\N	101.226.169.221
19	2014-12-23	\N	182.118.25.228
14	2014-12-23	\N	101.226.169.205
17	2014-12-23	\N	220.181.108.156
17	2014-12-23	\N	38.100.21.61
19	2014-12-23	\N	38.100.21.61
16	2014-12-23	\N	38.100.21.61
18	2014-12-23	\N	38.100.21.61
18	2014-12-23	\N	157.55.39.127
12	2014-12-23	\N	101.226.168.196
13	2014-12-23	\N	182.118.25.226
14	2014-12-24	\N	188.165.15.79
16	2014-12-24	\N	157.55.39.207
19	2014-12-24	\N	208.115.111.73
16	2014-12-24	\N	157.55.39.19
2	2014-12-24	\N	101.226.168.253
14	2014-12-24	\N	157.55.39.40
14	2014-12-25	\N	220.181.108.148
19	2014-12-25	\N	157.55.39.182
14	2014-12-25	\N	157.55.39.38
16	2014-12-25	\N	188.165.15.41
12	2014-12-25	\N	182.118.21.206
19	2014-12-25	\N	182.118.21.208
18	2014-12-25	\N	182.118.20.173
14	2014-12-25	\N	101.226.167.207
13	2014-12-25	\N	157.55.39.6
14	2014-12-25	\N	207.46.13.61
14	2014-12-26	\N	123.125.71.85
2	2014-12-26	\N	220.181.108.87
2	2014-12-26	\N	220.181.108.81
14	2014-12-26	\N	101.226.168.226
18	2014-12-26	\N	157.55.39.19
\.


--
-- TOC entry 3134 (class 0 OID 16734)
-- Dependencies: 174
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topics (id, title, last_posted_at, created_at, updated_at, views, posts_count, user_id, last_post_user_id, reply_count, featured_user1_id, featured_user2_id, featured_user3_id, avg_time, deleted_at, highest_post_number, image_url, off_topic_count, like_count, incoming_link_count, bookmark_count, star_count, category_id, visible, moderator_posts_count, closed, archived, bumped_at, has_summary, vote_count, archetype, featured_user4_id, notify_moderators_count, spam_count, illegal_count, inappropriate_count, pinned_at, score, percent_rank, notify_user_count, subtype, slug, auto_close_at, auto_close_user_id, auto_close_started_at, deleted_by_id, participant_count, word_count, excerpt, pinned_globally, auto_close_based_on_last_post, auto_close_hours) FROM stdin;
5	FAQ/Guidelines	2014-11-01 07:31:05.501277	2014-11-01 07:31:05.089891	2014-11-01 07:31:05.528296	0	2	-1	-1	0	\N	\N	\N	\N	\N	2	\N	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:05.501277	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	faq-guidelines	\N	\N	\N	\N	1	873	This is a Civilized Place for Public Discussion\n\nPlease treat this discussion forum with the same respect you would a public park.  We, too, are a shared community resource — a place to share skills, knowledge and int&hellip;	f	f	\N
1	About the Lounge category	2014-11-01 07:31:03.483706	2014-11-01 07:31:03.316937	2014-11-01 07:31:03.651215	0	1	-1	-1	0	\N	\N	\N	\N	\N	1	\N	0	0	0	0	0	2	t	0	f	f	2014-11-01 07:31:03.483706	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	about-the-lounge-category	\N	\N	\N	\N	1	11	A category exclusive to members with trust level 3 and higher.	f	f	\N
10	READ ME FIRST: Admin Quick Start Guide	2014-11-01 07:31:06.388933	2014-11-01 07:31:06.345691	2014-11-01 07:31:06.649443	0	1	-1	-1	0	\N	\N	\N	\N	\N	1	/plugins/emoji/images/hatching_chick.png	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:06.388933	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	read-me-first-admin-quick-start-guide	\N	\N	\N	\N	1	2354	Congratulations, you are now the proud owner of your very own Civilized Discourse Construction Kit. [hatching_chick] \n\nAdmin Dashboard\n\nAs an admin you have total control over this Discourse instance. Exercise your admin&hellip;	f	f	\N
8	Welcome to Discourse	\N	2014-11-01 07:31:05.940649	2014-11-01 07:31:05.986247	58	0	-1	-1	0	\N	\N	\N	971	2014-11-30 14:42:51.247913	0	\N	0	0	0	0	0	1	t	0	f	f	2014-11-01 07:31:05.967307	f	0	regular	\N	0	0	0	0	2014-11-01 07:31:06.014913	48.9500000000000028	0	0	\N	welcome-to-discourse	\N	\N	\N	1	1	82	The first paragraph of this pinned topic will be visible as a welcome message to all new visitors on your homepage. It&#39;s important! \n\nEdit this into a brief description of your community: \n\nWho is it for?What can they fi&hellip;	t	f	\N
3	About the Staff category	2014-11-01 07:31:04.08238	2014-11-01 07:31:03.850234	2014-11-01 07:31:04.097658	0	1	-1	-1	0	\N	\N	\N	\N	\N	1	\N	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:04.08238	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	about-the-staff-category	\N	\N	\N	\N	1	13	Private category for staff discussions. Topics are only visible to admins and moderators.	f	f	\N
12	关于分类：站务	\N	2014-11-01 08:00:55.711458	2014-11-01 08:00:55.711458	28	1	1	1	0	\N	\N	\N	\N	\N	1	\N	0	0	2	0	0	5	t	0	f	f	2014-11-01 08:00:55.711683	f	0	regular	\N	0	0	0	0	2014-11-01 08:00:55.709615	10	0.315789473684210509	0	\N	topic	\N	\N	\N	\N	1	\N	\N	f	f	\N
13	关于分类：活动	\N	2014-11-01 08:02:15.230601	2014-11-01 08:02:15.230601	40	1	1	1	0	\N	\N	\N	\N	\N	1	\N	0	0	2	0	0	6	t	0	f	f	2014-11-01 08:02:15.230836	f	0	regular	\N	0	0	0	0	2014-11-01 08:02:15.228937	10.1999999999999993	0.210526315789473673	0	\N	topic	\N	\N	\N	\N	1	\N	\N	f	f	\N
20	欢迎来到 暨大开发者社区！	2014-12-08 15:56:02.231675	2014-12-08 15:56:01.945102	2014-12-08 15:56:03.140246	0	1	1	1	0	\N	\N	\N	\N	\N	1	/images/welcome/progress-bar.png	0	0	0	0	0	\N	t	0	f	f	2014-12-08 15:56:02.231675	f	0	private_message	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	system_message	topic	\N	\N	\N	\N	1	138	感谢加入 暨大开发者社区，并且欢迎！ \n\n这条私信包含了一些可以让您快速开始的技巧提示： \n\n保持滚动\n\n没有下一页按钮或者页码——要阅读更多，只需要继续向下滚动页面！ \n\n当新的帖子加载后，它们会自动显示。 \n\n我在哪儿？\n\n要搜索，访问您的用户页面或者菜单，使用**右上角的图标☰按钮**。 任何主题标题点击后都将引导您至下一个未读的帖子。使用最后一次活动时间和帖子数量跳至主题顶部或底部。 当在阅读主题时，通过点击帖子标题回到顶部 ↑。&hellip;	f	f	\N
15	Welcome to JDC !	\N	2014-11-23 02:40:37.292395	2014-11-23 02:40:37.719636	17	0	1	1	0	\N	\N	\N	\N	2014-11-30 14:53:30.392863	0	\N	0	0	0	0	0	1	t	0	f	f	2014-11-23 02:40:37.485535	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	welcome-to-jdc	\N	\N	\N	1	1	10	JDC的成立\n\n-JDC成立于2014年下半年,由移动公司支持以及暨大珠区一群爱好编程的同学组成. \n\nJDC的主要分类\n\n-JDC分为移动MM成员和JDC成员,都以小组的形式来完成一个特定的项目,当然也可以自己发起项目. -每个小组都分为主程,测试,产品设计,美工四个方面的工作. \n\nJDC现有主要活动\n\n-由珠海GDG负责人周琦带领的蟒营学习活动. -移动MM的周汇报活动.	f	f	\N
2	About the Meta category	2014-11-01 07:31:03.770675	2014-11-01 07:31:03.729428	2014-11-01 07:31:03.791583	33	1	-1	-1	0	\N	\N	\N	\N	\N	1	\N	0	0	2	0	0	3	t	0	f	f	2014-11-01 07:31:03.770675	f	0	regular	\N	0	0	0	0	\N	10.1999999999999993	0.210526315789473673	0	\N	about-the-meta-category	\N	\N	\N	\N	1	15	Discussion about this site, its organization, how it works, and how we can improve it.	f	f	\N
11	本分类用于发布有关本站管理和运行的通知,公告及相关条款	\N	2014-11-01 07:55:26.672072	2014-11-01 07:55:27.305937	1	0	1	1	0	\N	\N	\N	\N	2014-11-01 07:58:21.29256	0	\N	0	0	0	0	0	1	t	0	f	f	2014-11-01 07:55:27.182161	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	topic	\N	\N	\N	1	1	0	本分类用于发布有关本站管理和运行的通知,公告及相关条款.	f	f	\N
7	Assets for the site design	2014-11-01 07:31:05.866237	2014-11-01 07:31:05.832832	2014-11-01 07:31:05.897031	0	1	-1	-1	0	\N	\N	\N	\N	\N	1	\N	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:05.866237	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	assets-for-the-site-design	\N	\N	\N	\N	1	138	This is a permanent topic, visible only to staff, for storing images and files used in the site design. Don&#39;t delete it! \n\nHere&#39;s how: \n\nReply to this topic.Upload all the images you wish to use for logos, favicons, and &hellip;	f	f	\N
9	Welcome to the Lounge	2014-11-01 07:31:06.046818	2014-11-01 07:31:06.02105	2014-11-01 07:31:06.08751	0	1	-1	-1	0	\N	\N	\N	\N	\N	1	/plugins/emoji/images/confetti_ball.png	0	0	0	0	0	2	t	0	f	f	2014-11-01 07:31:06.046818	f	0	regular	\N	0	0	0	0	2014-11-01 07:31:06.335549	0.200000000000000011	0.473684210526315763	0	\N	welcome-to-the-lounge	\N	\N	\N	\N	1	133	Congratulations! [confetti_ball] \n\nIf you can see this topic, you were recently promoted to regular (trust level 3). \n\nYou can now … \n\nEdit the title of any topicChange the category of any topicHave all your links follow&hellip;	f	f	\N
16	[14/11/30]暨大开发者社区logo发布	2014-11-30 13:34:53.337051	2014-11-30 13:34:52.947674	2014-11-30 13:34:53.524629	42	1	1	1	0	\N	\N	\N	\N	\N	1	/uploads/default/_optimized/09b/b17/6d2d8e0c76_500x500.png	0	0	3	0	0	5	t	0	f	f	2014-11-30 15:17:02.148752	f	0	regular	\N	0	0	0	0	\N	15.1999999999999993	0.105263157894736836	0	\N	14-11-30-logo	\N	\N	\N	\N	1	50	经过两周的设计,JDC的logo定稿,现发布如下: 大图标: [image]  网站图标: [image]  小图标: [image]  \n\n构图是电脑显示器和地球仪,意在JDC将地球搬(bian)进电脑. \n\n感谢yinnjiuu@sina.com的设计和实现. \n\ngithub地址: https://github.com/DengZuoheng/doc.jdc/tree/master/logo	f	f	\N
17	欢迎来到暨大开发者社区	2014-11-30 14:52:48.701327	2014-11-30 14:52:28.201796	2014-11-30 14:52:49.019851	52	2	1	1	0	\N	\N	\N	\N	\N	2	\N	0	0	3	0	0	3	t	1	f	f	2014-11-30 14:52:28.526081	f	0	regular	\N	0	0	0	0	2014-11-30 14:52:48.633633	7.69999999999999929	0.368421052631578927	0	\N	topic	\N	\N	\N	\N	1	91	欢迎来到暨大开发者社区\n\n暨大开发者社区是由暨南大学一群技术爱好者组成的开源技术社区.我们通常将暨大开发者社区简称为JDC. JDC的前身是暨南大学金山软件俱乐部(KSC). 目前,JDC与KSC时期一样托管于暨大电气信息学院团委学生会. 我们的目标,在于提供一个让大家一起折腾编程开发的平台. 任何人都可以加入暨大开发者社区,只要你对编程感兴趣,崇尚开源精神. \n\n在暨大开发者社区,你可以找到志同道合的朋友,与你一起走上编程这条不归路.&hellip;	t	f	\N
4	Terms of Service	2014-11-01 07:31:05.006787	2014-11-01 07:31:04.228562	2014-11-01 07:31:05.038004	0	2	-1	-1	0	\N	\N	\N	\N	\N	2	\N	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:05.006787	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	terms-of-service	\N	\N	\N	\N	1	2744	The following terms and conditions govern all use of the www.example.com website and all content, services and products available at or through the website, including, but not limited to, www.example.com Forum Software, w&hellip;	f	f	\N
6	Privacy Policy	2014-11-01 07:31:05.775228	2014-11-01 07:31:05.565752	2014-11-01 07:31:05.800735	0	2	-1	-1	0	\N	\N	\N	\N	\N	2	\N	0	0	0	0	0	4	t	0	f	f	2014-11-01 07:31:05.775228	f	0	regular	\N	0	0	0	0	\N	0.200000000000000011	0.473684210526315763	0	\N	privacy-policy	\N	\N	\N	\N	1	821	What information do we collect?\n\nWe collect information from you when you register on our site and gather data when you participate in the forum by reading, writing, and evaluating the content shared here. \n\nWhen regi&hellip;	f	f	\N
14	[14/11/08]暨大蟒营开营纪要	2014-11-12 16:38:55.179517	2014-11-12 16:38:54.435564	2014-11-12 16:39:09.936009	73	1	1	1	0	\N	\N	\N	\N	\N	1	/plugins/emoji/images/wink.png	0	0	4	0	0	6	t	0	f	f	2014-11-12 16:38:55.179517	f	0	regular	\N	0	0	0	0	\N	20.1999999999999993	0.0526315789473684181	0	\N	14-11-08	\N	\N	\N	\N	1	160	蟒营开营纪要\n\n概述\n\n时间:2014/11/8 14:30~18:00地点:暨南大学珠海校区教702参与人员:学员:15+导师:Zoom.Quiet(下面简称大妈)提出作品:5个\n\n流程\n\n1. 自我介绍:\n\n姓名和所读的专业同时说出自己认为在接下去的蟒营活动中会面临的问题,其中一些主要问题如下:团队之间的沟通、学员与导师的沟通.零基础.编程方面的不熟悉.担心毅力不够.\n\n2. 大妈对上述提问逐个回答:\n\n团队之间的沟通、学员与导师的&hellip;	f	f	\N
19	[14/11/22]蟒营迭代演示w2纪要	2014-11-30 15:55:18.735207	2014-11-30 15:55:18.466663	2014-11-30 15:55:18.865284	53	1	1	1	0	\N	\N	\N	14	\N	1	\N	0	0	1	0	0	6	t	0	f	f	2014-11-30 15:55:18.735207	f	0	regular	\N	0	0	0	0	\N	6.09999999999999964	0.421052631578947345	0	\N	14-11-22-w2	\N	\N	\N	\N	1	57	蟒营迭代演示W2\n\n概述\n\n时间：11月22日下午15:00-17:30地点：暨南大学珠海校区教702参与人员：蟒营学员：+10旁听:+2大妈:+1(Zoom.Quiet)\n\n流程\n\n1.演示（15:00-15:40） \n\n第一组:组我吧(Take me up) 2人上周:开通了微信的注册号,设置了注册账号、组团等大致的基本功能下周：完成多个项目的同时进行组团功能最大困难:调试大妈点评:现场问题 演示根本没有考虑到现场网络的事儿空口, &hellip;	f	f	\N
18	[14/11/16]蟒营迭代演示w1纪要	2014-11-30 15:36:39.970091	2014-11-30 15:36:39.516726	2014-11-30 15:36:40.555965	44	1	1	1	0	\N	\N	\N	\N	\N	1	\N	0	0	3	0	0	6	t	0	f	f	2014-11-30 15:36:39.970091	f	0	regular	\N	0	0	0	0	\N	15.1999999999999993	0.105263157894736836	0	\N	14-11-16-w1	\N	\N	\N	\N	1	62	蟒营迭代演示W1\n\n概述\n\n时间：11月16日下午15:00-18:00地点：暨南大学珠海校区教409参与人员：     + 蟒营学员：20+     + 导师：Zoom.Quiet(以下简称“大妈”)\n\n流程\n\n1.大妈发言，讲明本周迭代演示所要介绍的事项:\n\n产品名称谁做了什么下周做什么\n\n在此之前，投影仪出现了问题，由此引发大妈呼吁学员要获得完整的高等教育。 \n\n2.演示调试（两组进行参与）\n\n组我吧：试图通过网络进行,但网速过慢&hellip;	f	f	\N
\.


--
-- TOC entry 3414 (class 0 OID 0)
-- Dependencies: 173
-- Name: topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topics_id_seq', 20, true);


--
-- TOC entry 3172 (class 0 OID 17435)
-- Dependencies: 212
-- Data for Name: twitter_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY twitter_user_infos (id, user_id, screen_name, twitter_user_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3415 (class 0 OID 0)
-- Dependencies: 211
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('twitter_user_infos_id_seq', 1, false);


--
-- TOC entry 3143 (class 0 OID 16891)
-- Dependencies: 183
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY uploads (id, user_id, original_filename, filesize, width, height, url, created_at, updated_at, sha1, origin, retain_hours) FROM stdin;
1	-1	gravatar.png	120627	500	500	/uploads/default/1/3332cb4826b68638.png	2014-11-01 07:31:03.124858	2014-11-01 07:31:03.134046	48d15c70043e5c6da051b473073a85d7e893c9d9	\N	\N
2	1	CKBRAAXC.png	1164602	656	500	/uploads/default/2/ac858d9fce8be9a0.png	2014-11-01 08:08:17.03491	2014-11-01 08:08:17.292791	47ee5952fb515a43d9cc9675df8103667806576f	\N	\N
3	1	logo.png	84366	173	173	/uploads/default/3/60a0128bed69589b.png	2014-11-01 08:12:24.662904	2014-11-01 08:12:24.680322	283a745135005fcd7d5348bc157a180812d981e7	\N	\N
4	1	JDC-logo(1024x1024).png	133312	500	500	/uploads/default/4/2435daeed1465e41.png	2014-11-30 13:29:19.135052	2014-11-30 13:29:19.169429	09168762f2cd57283ff54ec17bf3b806733a9cfb	\N	\N
5	1	JDC-logo(244x66).png	7551	244	66	/uploads/default/5/a87baee6a18e9159.png	2014-11-30 13:29:49.201644	2014-11-30 13:29:49.232878	9b86108525e78a25a6904b519ccd3c152054f741	\N	\N
6	1	JDC-logo(66x66).png	6005	66	66	/uploads/default/6/0d11ff046aee0976.png	2014-11-30 13:30:29.843624	2014-11-30 13:30:29.854406	7be55b6fba43e7d296162d0d550e0acbe6249517	\N	\N
\.


--
-- TOC entry 3416 (class 0 OID 0)
-- Dependencies: 182
-- Name: uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('uploads_id_seq', 6, true);


--
-- TOC entry 3163 (class 0 OID 17295)
-- Dependencies: 203
-- Data for Name: user_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_actions (id, action_type, user_id, target_topic_id, target_post_id, target_user_id, acting_user_id, created_at, updated_at) FROM stdin;
1	4	-1	1	-1	\N	-1	2014-11-01 07:31:03.316937	2014-11-01 07:31:03.370535
2	4	-1	2	-1	\N	-1	2014-11-01 07:31:03.729428	2014-11-01 07:31:03.744174
3	4	-1	3	-1	\N	-1	2014-11-01 07:31:03.850234	2014-11-01 07:31:03.861913
4	4	-1	4	-1	\N	-1	2014-11-01 07:31:04.228562	2014-11-01 07:31:04.247624
5	5	-1	4	5	\N	-1	2014-11-01 07:31:05.006787	2014-11-01 07:31:05.019004
6	4	-1	5	-1	\N	-1	2014-11-01 07:31:05.089891	2014-11-01 07:31:05.108894
7	5	-1	5	7	\N	-1	2014-11-01 07:31:05.501277	2014-11-01 07:31:05.511265
8	4	-1	6	-1	\N	-1	2014-11-01 07:31:05.565752	2014-11-01 07:31:05.580013
9	5	-1	6	9	\N	-1	2014-11-01 07:31:05.775228	2014-11-01 07:31:05.784826
10	4	-1	7	-1	\N	-1	2014-11-01 07:31:05.832832	2014-11-01 07:31:05.848633
11	4	-1	8	-1	\N	-1	2014-11-01 07:31:05.940649	2014-11-01 07:31:05.952548
12	4	-1	9	-1	\N	-1	2014-11-01 07:31:06.02105	2014-11-01 07:31:06.031726
13	4	-1	10	-1	\N	-1	2014-11-01 07:31:06.345691	2014-11-01 07:31:06.365671
14	4	1	11	-1	\N	1	2014-11-01 07:55:26.672072	2014-11-01 07:55:26.73342
15	4	1	12	-1	\N	1	2014-11-01 08:00:55.711458	2014-11-01 08:00:55.722491
16	4	1	13	-1	\N	1	2014-11-01 08:02:15.230601	2014-11-01 08:02:15.242636
17	4	1	14	-1	\N	1	2014-11-12 16:38:54.435564	2014-11-12 16:38:54.616805
18	4	1	15	-1	\N	1	2014-11-23 02:40:37.292395	2014-11-23 02:40:37.3747
19	4	1	16	-1	\N	1	2014-11-30 13:34:52.947674	2014-11-30 13:34:53.075379
20	4	1	17	-1	\N	1	2014-11-30 14:52:28.201796	2014-11-30 14:52:28.27306
21	5	1	17	21	\N	1	2014-11-30 14:52:48.701327	2014-11-30 14:52:48.746348
22	4	1	18	-1	\N	1	2014-11-30 15:36:39.516726	2014-11-30 15:36:39.600189
23	4	1	19	-1	\N	1	2014-11-30 15:55:18.466663	2014-11-30 15:55:18.549152
24	12	1	20	-1	\N	1	2014-12-08 15:56:01.945102	2014-12-08 15:56:02.014738
25	13	6	20	-1	\N	1	2014-12-08 15:56:01.945102	2014-12-08 15:56:02.038894
\.


--
-- TOC entry 3417 (class 0 OID 0)
-- Dependencies: 202
-- Name: user_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_actions_id_seq', 25, true);


--
-- TOC entry 3266 (class 0 OID 19049)
-- Dependencies: 306
-- Data for Name: user_avatars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_avatars (id, user_id, custom_upload_id, gravatar_upload_id, last_gravatar_download_attempt, created_at, updated_at) FROM stdin;
1	-1	\N	1	2014-11-01 07:31:02.772865	2014-11-01 07:31:02.769657	2014-11-01 07:31:03.137805
2	1	\N	\N	2014-11-01 07:37:14.672331	2014-11-01 07:37:14.670794	2014-11-01 07:37:14.831493
7	6	\N	\N	2014-12-08 15:50:26.789401	2014-12-08 15:50:26.78551	2014-12-08 15:50:26.959248
\.


--
-- TOC entry 3418 (class 0 OID 0)
-- Dependencies: 305
-- Name: user_avatars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_avatars_id_seq', 7, true);


--
-- TOC entry 3246 (class 0 OID 18857)
-- Dependencies: 286
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_badges (id, badge_id, user_id, granted_at, granted_by_id, post_id, notification_id, seq) FROM stdin;
2	10	1	2014-11-12 16:38:55.179517	-1	\N	2	0
3	14	1	2014-11-30 14:52:28.927981	-1	20	3	0
\.


--
-- TOC entry 3419 (class 0 OID 0)
-- Dependencies: 285
-- Name: user_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_badges_id_seq', 3, true);


--
-- TOC entry 3252 (class 0 OID 18943)
-- Dependencies: 292
-- Data for Name: user_custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_custom_fields (id, user_id, name, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3420 (class 0 OID 0)
-- Dependencies: 291
-- Name: user_custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_custom_fields_id_seq', 1, false);


--
-- TOC entry 3282 (class 0 OID 19395)
-- Dependencies: 323
-- Data for Name: user_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_fields (id, name, field_type, created_at, updated_at, editable, description, required) FROM stdin;
\.


--
-- TOC entry 3421 (class 0 OID 0)
-- Dependencies: 322
-- Name: user_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_fields_id_seq', 1, false);


--
-- TOC entry 3201 (class 0 OID 18191)
-- Dependencies: 241
-- Data for Name: user_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_histories (id, action, acting_user_id, target_user_id, details, created_at, updated_at, context, ip_address, email, subject, previous_value, new_value, topic_id, admin_only, post_id) FROM stdin;
1	3	1	\N	\N	2014-11-01 07:38:55.291933	2014-11-01 07:38:55.291933	\N	\N	\N	default_locale	en	zh_CN	\N	t	\N
2	3	1	\N	\N	2014-11-01 07:46:18.210256	2014-11-01 07:46:18.210256	\N	\N	\N	title	Discourse	暨大开发者社区	\N	t	\N
3	3	1	\N	\N	2014-11-01 07:46:23.419148	2014-11-01 07:46:23.419148	\N	\N	\N	contact_email		dengzuoheng@gmail.com	\N	t	\N
4	3	1	\N	\N	2014-11-01 07:46:30.995538	2014-11-01 07:46:30.995538	\N	\N	\N	site_contact_username		dengzuoheng	\N	t	\N
5	3	1	\N	\N	2014-11-01 07:47:29.999426	2014-11-01 07:47:29.999426	\N	\N	\N	site_description		暨大开发者社区官方论坛	\N	t	\N
6	3	1	\N	\N	2014-11-30 13:36:15.399861	2014-11-30 13:36:15.399861	\N	\N	\N	logo_url	/images/d-logo-sketch.png	/uploads/default/5/a87baee6a18e9159.png	\N	t	\N
7	3	1	\N	\N	2014-11-30 13:36:25.418435	2014-11-30 13:36:25.418435	\N	\N	\N	logo_small_url	/images/d-logo-sketch-small.png	/uploads/default/5/a87baee6a18e9159.png	\N	t	\N
8	3	1	\N	\N	2014-11-30 13:36:38.215989	2014-11-30 13:36:38.215989	\N	\N	\N	favicon_url	/images/default-favicon.ico	/uploads/default/6/0d11ff046aee0976.png	\N	t	\N
9	18	1	\N	id: 8\ncreated_at: 2014-11-01 07:31:05 UTC\nuser: system (system)\ntitle: Welcome to Discourse	2014-11-30 14:42:51.227161	2014-11-30 14:42:51.227161	/t/welcome-to-discourse/8	\N	\N	\N	\N	\N	8	f	\N
10	1	-1	\N	id: 2\nusername: guchayu159\nname: 廖晓科\ncreated_at: 2014-12-08 13:35:09 UTC\ntrust_level: 0\nlast_seen_at: \nlast_emailed_at: 2014-12-08 13:42:38 UTC	2014-12-16 12:05:20.161933	2014-12-16 12:05:20.161933	自动删除长期未使用或者未验证	113.76.199.104	1136058750@qq.com	\N	\N	\N	\N	f	\N
11	1	-1	\N	id: 3\nusername: guchayu\nname: 廖晓科\ncreated_at: 2014-12-08 13:50:12 UTC\ntrust_level: 0\nlast_seen_at: \nlast_emailed_at: 2014-12-08 13:50:12 UTC	2014-12-16 12:05:20.232598	2014-12-16 12:05:20.232598	自动删除长期未使用或者未验证	113.76.199.104	2689884163@qq.com	\N	\N	\N	\N	f	\N
12	1	-1	\N	id: 4\nusername: 2470423627\nname: 247\ncreated_at: 2014-12-08 15:01:21 UTC\ntrust_level: 0\nlast_seen_at: \nlast_emailed_at: 2014-12-08 15:01:22 UTC	2014-12-16 12:05:20.284667	2014-12-16 12:05:20.284667	自动删除长期未使用或者未验证	106.186.22.90	2470423627@qq.com	\N	\N	\N	\N	f	\N
13	1	-1	\N	id: 5\nusername: chenrenzhan\nname: chenrenzhan\ncreated_at: 2014-12-08 15:46:26 UTC\ntrust_level: 0\nlast_seen_at: \nlast_emailed_at: 2014-12-08 15:46:27 UTC	2014-12-16 12:05:20.325662	2014-12-16 12:05:20.325662	自动删除长期未使用或者未验证	106.186.22.90	chenrenzhan@gamil.com	\N	\N	\N	\N	f	\N
\.


--
-- TOC entry 3422 (class 0 OID 0)
-- Dependencies: 240
-- Name: user_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_histories_id_seq', 13, true);


--
-- TOC entry 3161 (class 0 OID 17229)
-- Dependencies: 201
-- Data for Name: user_open_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_open_ids (id, user_id, email, url, created_at, updated_at, active) FROM stdin;
\.


--
-- TOC entry 3423 (class 0 OID 0)
-- Dependencies: 200
-- Name: user_open_ids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_open_ids_id_seq', 1, false);


--
-- TOC entry 3267 (class 0 OID 19070)
-- Dependencies: 307
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_profiles (user_id, location, website, bio_raw, bio_cooked, profile_background, dismissed_banner_key, bio_cooked_version, badge_granted_title, card_background, card_image_badge_id) FROM stdin;
-1	\N	\N	\N	\N	\N	\N	1	f	\N	\N
1	\N	\N	\N	\N	\N	\N	1	f	\N	\N
6	\N	\N	\N	\N	\N	\N	1	f	\N	\N
\.


--
-- TOC entry 3195 (class 0 OID 17832)
-- Dependencies: 235
-- Data for Name: user_search_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_search_data (user_id, search_data, raw_data, locale) FROM stdin;
-1	'system':1,2	system system	en
1	'dengzuoheng':1,2	dengzuoheng dengzuoheng	en
6	'chen':1,3 'renzhan':2,4	chen renzhan chen renzhan 	zh_CN
\.


--
-- TOC entry 3224 (class 0 OID 18519)
-- Dependencies: 264
-- Data for Name: user_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_stats (user_id, topics_entered, time_read, days_visited, posts_read_count, likes_given, likes_received, topic_reply_count, new_since, read_faq, first_post_created_at, post_count, topic_count) FROM stdin;
1	9	2818	18	11	0	0	0	2014-11-01 07:37:14.63451	\N	2014-11-12 16:38:55.179517	7	6
6	1	32	1	1	0	0	0	2014-12-08 15:50:26.741324	\N	\N	0	0
-1	0	0	0	13	0	0	0	2014-11-01 07:31:02.675196	\N	2014-11-01 07:31:03.483706	12	9
\.


--
-- TOC entry 3185 (class 0 OID 17680)
-- Dependencies: 225
-- Data for Name: user_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_visits (id, user_id, visited_at, posts_read) FROM stdin;
1	1	2014-11-01	2
2	1	2014-11-04	0
3	1	2014-11-09	0
4	1	2014-11-11	0
5	1	2014-11-12	0
6	1	2014-11-14	0
7	1	2014-11-17	0
8	1	2014-11-19	0
9	1	2014-11-23	0
10	1	2014-11-30	2
11	1	2014-12-01	0
12	1	2014-12-02	0
13	1	2014-12-07	0
14	1	2014-12-08	0
15	6	2014-12-08	1
16	1	2014-12-09	0
17	1	2014-12-22	0
18	1	2014-12-23	0
19	1	2014-12-26	0
\.


--
-- TOC entry 3424 (class 0 OID 0)
-- Dependencies: 224
-- Name: user_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_visits_id_seq', 19, true);


--
-- TOC entry 3138 (class 0 OID 16754)
-- Dependencies: 178
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, username, created_at, updated_at, name, seen_notification_id, last_posted_at, email, password_hash, salt, active, username_lower, auth_token, last_seen_at, admin, last_emailed_at, email_digests, trust_level, email_private_messages, email_direct, approved, approved_by_id, approved_at, digest_after_days, previous_visit_at, suspended_at, suspended_till, date_of_birth, auto_track_topics_after_msecs, views, flag_level, ip_address, new_topic_duration_minutes, external_links_in_new_tab, enable_quoting, moderator, blocked, dynamic_favicon, title, uploaded_avatar_id, email_always, mailing_list_mode, locale, primary_group_id, registration_ip_address, last_redirected_to_top_at, disable_jump_reply, edit_history_public, trust_level_locked) FROM stdin;
-1	system	2014-11-01 07:31:02.648641	2014-11-01 07:31:06.657681	system	0	2014-11-01 07:31:06.388933	no_email	899c5c0fcd4a66f1f31be64fbb7eab2a19541c2eebf73b3c3d825261b6cde36d	ac2e1dd762cb552001d900ac57f5df49	t	system	\N	\N	t	\N	t	4	f	f	t	\N	\N	7	\N	\N	\N	\N	\N	0	0	\N	\N	f	t	t	f	f	\N	1	f	f	\N	\N	\N	\N	f	f	f
1	dengzuoheng	2014-11-01 07:37:14.595439	2014-12-08 15:56:03.406433	dengzuoheng	3	2014-12-08 15:56:02.231675	dengzuoheng@gmail.com	618154b5024ed1b78b89304457043551412181a0e4f72957e355f6f775d35fd7	0a757b21bb52cb4c220941a7ffb71509	t	dengzuoheng	d679e5083a7b1e25fce4dc6a9a74fecf	2014-12-26 10:49:04.426759	t	2014-12-16 14:02:03.721661	t	0	t	t	f	\N	\N	7	2014-12-23 13:18:45.589053	\N	\N	\N	\N	0	0	106.186.22.90	\N	f	t	f	f	f	\N	3	f	f	\N	\N	106.185.37.220	\N	f	f	f
6	chen_renzhan	2014-12-08 15:50:26.72285	2014-12-08 15:56:01.81656	chen_renzhan	0	\N	chenrenzhan@gmail.com	82f286c6acc1737f13f385aecaca940fa36173f32f1890caf20a9cccea81e514	9138b0b0cedeb9d62cff31ffee51e12b	t	chen_renzhan	9b41fa6f8571a587bf555dfbf7e21772	2014-12-08 15:56:04.087746	f	2014-12-08 16:06:13.588571	t	0	t	t	f	\N	\N	7	\N	\N	\N	\N	\N	0	0	106.186.22.90	\N	f	t	f	f	f	\N	\N	f	f	\N	\N	106.186.22.90	\N	f	f	f
\.


--
-- TOC entry 3425 (class 0 OID 0)
-- Dependencies: 177
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 6, true);


--
-- TOC entry 3140 (class 0 OID 16795)
-- Dependencies: 180
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY versions (id, versioned_id, versioned_type, user_id, user_type, user_name, modifications, number, reverted_from, tag, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3426 (class 0 OID 0)
-- Dependencies: 179
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('versions_id_seq', 1, false);


--
-- TOC entry 3280 (class 0 OID 19369)
-- Dependencies: 321
-- Data for Name: warnings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY warnings (id, topic_id, user_id, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3427 (class 0 OID 0)
-- Dependencies: 320
-- Name: warnings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('warnings_id_seq', 1, false);


--
-- TOC entry 2805 (class 2606 OID 17300)
-- Name: actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id);


--
-- TOC entry 2927 (class 2606 OID 18622)
-- Name: api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3005 (class 2606 OID 19198)
-- Name: badge_groupings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY badge_groupings
    ADD CONSTRAINT badge_groupings_pkey PRIMARY KEY (id);


--
-- TOC entry 2958 (class 2606 OID 18840)
-- Name: badge_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY badge_types
    ADD CONSTRAINT badge_types_pkey PRIMARY KEY (id);


--
-- TOC entry 2961 (class 2606 OID 18853)
-- Name: badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- TOC entry 2904 (class 2606 OID 18449)
-- Name: blocked_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY screened_emails
    ADD CONSTRAINT blocked_emails_pkey PRIMARY KEY (id);


--
-- TOC entry 2791 (class 2606 OID 17209)
-- Name: categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 2871 (class 2606 OID 17847)
-- Name: categories_search_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_search_data
    ADD CONSTRAINT categories_search_pkey PRIMARY KEY (category_id);


--
-- TOC entry 2977 (class 2606 OID 18969)
-- Name: category_custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_custom_fields
    ADD CONSTRAINT category_custom_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 2797 (class 2606 OID 18424)
-- Name: category_featured_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_featured_topics
    ADD CONSTRAINT category_featured_topics_pkey PRIMARY KEY (id);


--
-- TOC entry 2820 (class 2606 OID 17403)
-- Name: category_featured_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_featured_users
    ADD CONSTRAINT category_featured_users_pkey PRIMARY KEY (id);


--
-- TOC entry 2891 (class 2606 OID 18258)
-- Name: category_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_groups
    ADD CONSTRAINT category_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 2953 (class 2606 OID 18754)
-- Name: category_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_users
    ADD CONSTRAINT category_users_pkey PRIMARY KEY (id);


--
-- TOC entry 2971 (class 2606 OID 18939)
-- Name: color_scheme_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY color_scheme_colors
    ADD CONSTRAINT color_scheme_colors_pkey PRIMARY KEY (id);


--
-- TOC entry 2969 (class 2606 OID 18927)
-- Name: color_schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY color_schemes
    ADD CONSTRAINT color_schemes_pkey PRIMARY KEY (id);


--
-- TOC entry 2862 (class 2606 OID 17797)
-- Name: draft_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY draft_sequences
    ADD CONSTRAINT draft_sequences_pkey PRIMARY KEY (id);


--
-- TOC entry 2856 (class 2606 OID 17711)
-- Name: drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- TOC entry 2827 (class 2606 OID 17527)
-- Name: email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 2852 (class 2606 OID 17699)
-- Name: email_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_tokens
    ADD CONSTRAINT email_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 2837 (class 2606 OID 17584)
-- Name: facebook_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY facebook_user_infos
    ADD CONSTRAINT facebook_user_infos_pkey PRIMARY KEY (id);


--
-- TOC entry 2818 (class 2606 OID 17332)
-- Name: forum_thread_link_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_link_clicks
    ADD CONSTRAINT forum_thread_link_clicks_pkey PRIMARY KEY (id);


--
-- TOC entry 2771 (class 2606 OID 16925)
-- Name: forum_thread_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_links
    ADD CONSTRAINT forum_thread_links_pkey PRIMARY KEY (id);


--
-- TOC entry 2729 (class 2606 OID 16739)
-- Name: forum_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topics
    ADD CONSTRAINT forum_threads_pkey PRIMARY KEY (id);


--
-- TOC entry 2874 (class 2606 OID 18048)
-- Name: github_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY github_user_infos
    ADD CONSTRAINT github_user_infos_pkey PRIMARY KEY (id);


--
-- TOC entry 2991 (class 2606 OID 19044)
-- Name: google_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY google_user_infos
    ADD CONSTRAINT google_user_infos_pkey PRIMARY KEY (id);


--
-- TOC entry 2980 (class 2606 OID 18980)
-- Name: group_custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY group_custom_fields
    ADD CONSTRAINT group_custom_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 2888 (class 2606 OID 18236)
-- Name: group_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- TOC entry 2885 (class 2606 OID 18228)
-- Name: groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3010 (class 2606 OID 19267)
-- Name: incoming_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY incoming_domains
    ADD CONSTRAINT incoming_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 2786 (class 2606 OID 17124)
-- Name: incoming_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY incoming_links
    ADD CONSTRAINT incoming_links_pkey PRIMARY KEY (id);


--
-- TOC entry 3007 (class 2606 OID 19258)
-- Name: incoming_referers_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY incoming_referers
    ADD CONSTRAINT incoming_referers_pkey PRIMARY KEY (id);


--
-- TOC entry 2989 (class 2606 OID 19023)
-- Name: invited_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invited_groups
    ADD CONSTRAINT invited_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 2843 (class 2606 OID 17664)
-- Name: invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- TOC entry 2780 (class 2606 OID 16967)
-- Name: message_bus_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY message_bus
    ADD CONSTRAINT message_bus_pkey PRIMARY KEY (id);


--
-- TOC entry 2784 (class 2606 OID 16988)
-- Name: notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 2913 (class 2606 OID 18494)
-- Name: oauth2_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY oauth2_user_infos
    ADD CONSTRAINT oauth2_user_infos_pkey PRIMARY KEY (id);


--
-- TOC entry 2902 (class 2606 OID 18373)
-- Name: optimized_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY optimized_images
    ADD CONSTRAINT optimized_images_pkey PRIMARY KEY (id);


--
-- TOC entry 3017 (class 2606 OID 19348)
-- Name: permalinks_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY permalinks
    ADD CONSTRAINT permalinks_pkey PRIMARY KEY (id);


--
-- TOC entry 2916 (class 2606 OID 18511)
-- Name: plugin_store_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY plugin_store_rows
    ADD CONSTRAINT plugin_store_rows_pkey PRIMARY KEY (id);


--
-- TOC entry 2815 (class 2606 OID 17498)
-- Name: post_action_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_action_types
    ADD CONSTRAINT post_action_types_pkey PRIMARY KEY (id);


--
-- TOC entry 2813 (class 2606 OID 17315)
-- Name: post_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_actions
    ADD CONSTRAINT post_actions_pkey PRIMARY KEY (id);


--
-- TOC entry 2984 (class 2606 OID 18991)
-- Name: post_custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_custom_fields
    ADD CONSTRAINT post_custom_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 2921 (class 2606 OID 18588)
-- Name: post_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_details
    ADD CONSTRAINT post_details_pkey PRIMARY KEY (id);


--
-- TOC entry 2933 (class 2606 OID 18654)
-- Name: post_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_revisions
    ADD CONSTRAINT post_revisions_pkey PRIMARY KEY (id);


--
-- TOC entry 2898 (class 2606 OID 18347)
-- Name: post_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_uploads
    ADD CONSTRAINT post_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 2739 (class 2606 OID 16750)
-- Name: posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 2866 (class 2606 OID 17831)
-- Name: posts_search_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_search_data
    ADD CONSTRAINT posts_search_pkey PRIMARY KEY (post_id);


--
-- TOC entry 3003 (class 2606 OID 19184)
-- Name: quoted_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY quoted_posts
    ADD CONSTRAINT quoted_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 2925 (class 2606 OID 18611)
-- Name: screened_ip_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY screened_ip_addresses
    ADD CONSTRAINT screened_ip_addresses_pkey PRIMARY KEY (id);


--
-- TOC entry 2910 (class 2606 OID 18481)
-- Name: screened_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY screened_urls
    ADD CONSTRAINT screened_urls_pkey PRIMARY KEY (id);


--
-- TOC entry 2956 (class 2606 OID 18805)
-- Name: single_sign_on_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY single_sign_on_records
    ADD CONSTRAINT single_sign_on_records_pkey PRIMARY KEY (id);


--
-- TOC entry 2860 (class 2606 OID 17742)
-- Name: site_customizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY site_customizations
    ADD CONSTRAINT site_customizations_pkey PRIMARY KEY (id);


--
-- TOC entry 2800 (class 2606 OID 17226)
-- Name: site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 2951 (class 2606 OID 18720)
-- Name: top_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY top_topics
    ADD CONSTRAINT top_topics_pkey PRIMARY KEY (id);


--
-- TOC entry 2895 (class 2606 OID 18266)
-- Name: topic_allowed_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_allowed_groups
    ADD CONSTRAINT topic_allowed_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 2835 (class 2606 OID 17548)
-- Name: topic_allowed_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_allowed_users
    ADD CONSTRAINT topic_allowed_users_pkey PRIMARY KEY (id);


--
-- TOC entry 2987 (class 2606 OID 19005)
-- Name: topic_custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_custom_fields
    ADD CONSTRAINT topic_custom_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 2936 (class 2606 OID 18688)
-- Name: topic_embeds_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_embeds
    ADD CONSTRAINT topic_embeds_pkey PRIMARY KEY (id);


--
-- TOC entry 2847 (class 2606 OID 17674)
-- Name: topic_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_invites
    ADD CONSTRAINT topic_invites_pkey PRIMARY KEY (id);


--
-- TOC entry 3014 (class 2606 OID 19311)
-- Name: topic_search_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_search_data
    ADD CONSTRAINT topic_search_data_pkey PRIMARY KEY (topic_id);


--
-- TOC entry 2769 (class 2606 OID 18435)
-- Name: topic_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_users
    ADD CONSTRAINT topic_users_pkey PRIMARY KEY (id);


--
-- TOC entry 2825 (class 2606 OID 17440)
-- Name: twitter_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY twitter_user_infos
    ADD CONSTRAINT twitter_user_infos_pkey PRIMARY KEY (id);


--
-- TOC entry 2765 (class 2606 OID 16899)
-- Name: uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 2996 (class 2606 OID 19054)
-- Name: user_avatars_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_avatars
    ADD CONSTRAINT user_avatars_pkey PRIMARY KEY (id);


--
-- TOC entry 2967 (class 2606 OID 18862)
-- Name: user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- TOC entry 2975 (class 2606 OID 18951)
-- Name: user_custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_custom_fields
    ADD CONSTRAINT user_custom_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 3023 (class 2606 OID 19403)
-- Name: user_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_fields
    ADD CONSTRAINT user_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 2883 (class 2606 OID 18199)
-- Name: user_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_histories
    ADD CONSTRAINT user_histories_pkey PRIMARY KEY (id);


--
-- TOC entry 2803 (class 2606 OID 17237)
-- Name: user_open_ids_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_open_ids
    ADD CONSTRAINT user_open_ids_pkey PRIMARY KEY (id);


--
-- TOC entry 2999 (class 2606 OID 19074)
-- Name: user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id);


--
-- TOC entry 2918 (class 2606 OID 18524)
-- Name: user_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_stats
    ADD CONSTRAINT user_stats_pkey PRIMARY KEY (user_id);


--
-- TOC entry 2850 (class 2606 OID 17685)
-- Name: user_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_visits
    ADD CONSTRAINT user_visits_pkey PRIMARY KEY (id);


--
-- TOC entry 2747 (class 2606 OID 16759)
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 2869 (class 2606 OID 17839)
-- Name: users_search_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_search_data
    ADD CONSTRAINT users_search_pkey PRIMARY KEY (user_id);


--
-- TOC entry 2755 (class 2606 OID 16803)
-- Name: versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- TOC entry 3021 (class 2606 OID 19374)
-- Name: warnings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY warnings
    ADD CONSTRAINT warnings_pkey PRIMARY KEY (id);


--
-- TOC entry 2816 (class 1259 OID 17342)
-- Name: by_link; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX by_link ON topic_link_clicks USING btree (topic_link_id);


--
-- TOC entry 2795 (class 1259 OID 17215)
-- Name: cat_featured_threads; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX cat_featured_threads ON category_featured_topics USING btree (category_id, topic_id);


--
-- TOC entry 2734 (class 1259 OID 19329)
-- Name: idx_posts_created_at_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_posts_created_at_topic_id ON posts USING btree (created_at, topic_id) WHERE (deleted_at IS NULL);


--
-- TOC entry 2735 (class 1259 OID 18513)
-- Name: idx_posts_user_id_deleted_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_posts_user_id_deleted_at ON posts USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- TOC entry 2872 (class 1259 OID 17850)
-- Name: idx_search_category; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_category ON category_search_data USING gin (search_data);


--
-- TOC entry 2864 (class 1259 OID 17848)
-- Name: idx_search_post; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_post ON post_search_data USING gin (search_data);


--
-- TOC entry 3012 (class 1259 OID 19312)
-- Name: idx_search_topic; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_topic ON topic_search_data USING gin (search_data);


--
-- TOC entry 2867 (class 1259 OID 17849)
-- Name: idx_search_user; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_user ON user_search_data USING gin (search_data);


--
-- TOC entry 2730 (class 1259 OID 18887)
-- Name: idx_topics_front_page; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_topics_front_page ON topics USING btree (deleted_at, visible, archetype, category_id, id);


--
-- TOC entry 2731 (class 1259 OID 18514)
-- Name: idx_topics_user_id_deleted_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_topics_user_id_deleted_at ON topics USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- TOC entry 2809 (class 1259 OID 19326)
-- Name: idx_unique_actions; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_actions ON post_actions USING btree (user_id, post_action_type_id, post_id, targets_topic) WHERE (((deleted_at IS NULL) AND (disagreed_at IS NULL)) AND (deferred_at IS NULL));


--
-- TOC entry 2810 (class 1259 OID 19354)
-- Name: idx_unique_flags; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_flags ON post_actions USING btree (user_id, post_id, targets_topic) WHERE ((((deleted_at IS NULL) AND (disagreed_at IS NULL)) AND (deferred_at IS NULL)) AND (post_action_type_id = ANY (ARRAY[3, 4, 7, 8])));


--
-- TOC entry 2896 (class 1259 OID 18348)
-- Name: idx_unique_post_uploads; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_post_uploads ON post_uploads USING btree (post_id, upload_id);


--
-- TOC entry 2806 (class 1259 OID 17364)
-- Name: idx_unique_rows; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_rows ON user_actions USING btree (action_type, user_id, target_topic_id, target_post_id, acting_user_id);


--
-- TOC entry 2928 (class 1259 OID 18623)
-- Name: index_api_keys_on_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_api_keys_on_key ON api_keys USING btree (key);


--
-- TOC entry 2929 (class 1259 OID 18624)
-- Name: index_api_keys_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_api_keys_on_user_id ON api_keys USING btree (user_id);


--
-- TOC entry 2959 (class 1259 OID 18841)
-- Name: index_badge_types_on_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_badge_types_on_name ON badge_types USING btree (name);


--
-- TOC entry 2962 (class 1259 OID 18854)
-- Name: index_badges_on_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_badges_on_name ON badges USING btree (name);


--
-- TOC entry 2792 (class 1259 OID 18817)
-- Name: index_categories_on_email_in; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_categories_on_email_in ON categories USING btree (email_in);


--
-- TOC entry 2793 (class 1259 OID 17211)
-- Name: index_categories_on_topic_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_categories_on_topic_count ON categories USING btree (topic_count);


--
-- TOC entry 2978 (class 1259 OID 18992)
-- Name: index_category_custom_fields_on_category_id_and_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_category_custom_fields_on_category_id_and_name ON category_custom_fields USING btree (category_id, name);


--
-- TOC entry 2798 (class 1259 OID 18309)
-- Name: index_category_featured_topics_on_category_id_and_rank; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_category_featured_topics_on_category_id_and_rank ON category_featured_topics USING btree (category_id, rank);


--
-- TOC entry 2821 (class 1259 OID 17404)
-- Name: index_category_featured_users_on_category_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_category_featured_users_on_category_id_and_user_id ON category_featured_users USING btree (category_id, user_id);


--
-- TOC entry 2972 (class 1259 OID 18940)
-- Name: index_color_scheme_colors_on_color_scheme_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_color_scheme_colors_on_color_scheme_id ON color_scheme_colors USING btree (color_scheme_id);


--
-- TOC entry 2863 (class 1259 OID 17798)
-- Name: index_draft_sequences_on_user_id_and_draft_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_draft_sequences_on_user_id_and_draft_key ON draft_sequences USING btree (user_id, draft_key);


--
-- TOC entry 2857 (class 1259 OID 17712)
-- Name: index_drafts_on_user_id_and_draft_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_drafts_on_user_id_and_draft_key ON drafts USING btree (user_id, draft_key);


--
-- TOC entry 2828 (class 1259 OID 19335)
-- Name: index_email_logs_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_created_at ON email_logs USING btree (created_at DESC);


--
-- TOC entry 2829 (class 1259 OID 18333)
-- Name: index_email_logs_on_reply_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_reply_key ON email_logs USING btree (reply_key);


--
-- TOC entry 2830 (class 1259 OID 19333)
-- Name: index_email_logs_on_skipped_and_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_skipped_and_created_at ON email_logs USING btree (skipped, created_at);


--
-- TOC entry 2831 (class 1259 OID 19334)
-- Name: index_email_logs_on_user_id_and_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_user_id_and_created_at ON email_logs USING btree (user_id, created_at DESC);


--
-- TOC entry 2853 (class 1259 OID 17700)
-- Name: index_email_tokens_on_token; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_email_tokens_on_token ON email_tokens USING btree (token);


--
-- TOC entry 2854 (class 1259 OID 19327)
-- Name: index_email_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_tokens_on_user_id ON email_tokens USING btree (user_id);


--
-- TOC entry 2838 (class 1259 OID 18021)
-- Name: index_facebook_user_infos_on_facebook_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_facebook_user_infos_on_facebook_user_id ON facebook_user_infos USING btree (facebook_user_id);


--
-- TOC entry 2839 (class 1259 OID 17585)
-- Name: index_facebook_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_facebook_user_infos_on_user_id ON facebook_user_infos USING btree (user_id);


--
-- TOC entry 2875 (class 1259 OID 18049)
-- Name: index_github_user_infos_on_github_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_github_user_infos_on_github_user_id ON github_user_infos USING btree (github_user_id);


--
-- TOC entry 2876 (class 1259 OID 18050)
-- Name: index_github_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_github_user_infos_on_user_id ON github_user_infos USING btree (user_id);


--
-- TOC entry 2992 (class 1259 OID 19046)
-- Name: index_google_user_infos_on_google_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_google_user_infos_on_google_user_id ON google_user_infos USING btree (google_user_id);


--
-- TOC entry 2993 (class 1259 OID 19045)
-- Name: index_google_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_google_user_infos_on_user_id ON google_user_infos USING btree (user_id);


--
-- TOC entry 2981 (class 1259 OID 18993)
-- Name: index_group_custom_fields_on_group_id_and_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_group_custom_fields_on_group_id_and_name ON group_custom_fields USING btree (group_id, name);


--
-- TOC entry 2889 (class 1259 OID 18237)
-- Name: index_group_users_on_group_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_group_users_on_group_id_and_user_id ON group_users USING btree (group_id, user_id);


--
-- TOC entry 2886 (class 1259 OID 18279)
-- Name: index_groups_on_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_groups_on_name ON groups USING btree (name);


--
-- TOC entry 3011 (class 1259 OID 19269)
-- Name: index_incoming_domains_on_name_and_https_and_port; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_incoming_domains_on_name_and_https_and_port ON incoming_domains USING btree (name, https, port);


--
-- TOC entry 2787 (class 1259 OID 19332)
-- Name: index_incoming_links_on_created_at_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_incoming_links_on_created_at_and_user_id ON incoming_links USING btree (created_at, user_id);


--
-- TOC entry 2788 (class 1259 OID 19246)
-- Name: index_incoming_links_on_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_incoming_links_on_post_id ON incoming_links USING btree (post_id);


--
-- TOC entry 3008 (class 1259 OID 19268)
-- Name: index_incoming_referers_on_path_and_incoming_domain_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_incoming_referers_on_path_and_incoming_domain_id ON incoming_referers USING btree (path, incoming_domain_id);


--
-- TOC entry 2840 (class 1259 OID 19233)
-- Name: index_invites_on_email_and_invited_by_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_invites_on_email_and_invited_by_id ON invites USING btree (email, invited_by_id);


--
-- TOC entry 2841 (class 1259 OID 17665)
-- Name: index_invites_on_invite_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_invites_on_invite_key ON invites USING btree (invite_key);


--
-- TOC entry 2778 (class 1259 OID 19330)
-- Name: index_message_bus_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_message_bus_on_created_at ON message_bus USING btree (created_at);


--
-- TOC entry 2781 (class 1259 OID 17551)
-- Name: index_notifications_on_post_action_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_notifications_on_post_action_id ON notifications USING btree (post_action_id);


--
-- TOC entry 2782 (class 1259 OID 19331)
-- Name: index_notifications_on_user_id_and_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_notifications_on_user_id_and_created_at ON notifications USING btree (user_id, created_at);


--
-- TOC entry 2911 (class 1259 OID 18495)
-- Name: index_oauth2_user_infos_on_uid_and_provider; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_oauth2_user_infos_on_uid_and_provider ON oauth2_user_infos USING btree (uid, provider);


--
-- TOC entry 2899 (class 1259 OID 18374)
-- Name: index_optimized_images_on_upload_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_optimized_images_on_upload_id ON optimized_images USING btree (upload_id);


--
-- TOC entry 2900 (class 1259 OID 18375)
-- Name: index_optimized_images_on_upload_id_and_width_and_height; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_optimized_images_on_upload_id_and_width_and_height ON optimized_images USING btree (upload_id, width, height);


--
-- TOC entry 3015 (class 1259 OID 19353)
-- Name: index_permalinks_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_permalinks_on_url ON permalinks USING btree (url);


--
-- TOC entry 2914 (class 1259 OID 18512)
-- Name: index_plugin_store_rows_on_plugin_name_and_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_plugin_store_rows_on_plugin_name_and_key ON plugin_store_rows USING btree (plugin_name, key);


--
-- TOC entry 2811 (class 1259 OID 17316)
-- Name: index_post_actions_on_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_actions_on_post_id ON post_actions USING btree (post_id);


--
-- TOC entry 2982 (class 1259 OID 18994)
-- Name: index_post_custom_fields_on_post_id_and_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_custom_fields_on_post_id_and_name ON post_custom_fields USING btree (post_id, name);


--
-- TOC entry 2919 (class 1259 OID 18589)
-- Name: index_post_details_on_post_id_and_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_post_details_on_post_id_and_key ON post_details USING btree (post_id, key);


--
-- TOC entry 2789 (class 1259 OID 17129)
-- Name: index_post_replies_on_post_id_and_reply_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_post_replies_on_post_id_and_reply_id ON post_replies USING btree (post_id, reply_id);


--
-- TOC entry 2930 (class 1259 OID 18655)
-- Name: index_post_revisions_on_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_revisions_on_post_id ON post_revisions USING btree (post_id);


--
-- TOC entry 2931 (class 1259 OID 18656)
-- Name: index_post_revisions_on_post_id_and_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_revisions_on_post_id_and_number ON post_revisions USING btree (post_id, number);


--
-- TOC entry 2775 (class 1259 OID 19247)
-- Name: index_post_timings_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_timings_on_user_id ON post_timings USING btree (user_id);


--
-- TOC entry 2736 (class 1259 OID 16776)
-- Name: index_posts_on_reply_to_post_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_posts_on_reply_to_post_number ON posts USING btree (reply_to_post_number);


--
-- TOC entry 2737 (class 1259 OID 19167)
-- Name: index_posts_on_topic_id_and_post_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_posts_on_topic_id_and_post_number ON posts USING btree (topic_id, post_number);


--
-- TOC entry 3000 (class 1259 OID 19185)
-- Name: index_quoted_posts_on_post_id_and_quoted_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_quoted_posts_on_post_id_and_quoted_post_id ON quoted_posts USING btree (post_id, quoted_post_id);


--
-- TOC entry 3001 (class 1259 OID 19186)
-- Name: index_quoted_posts_on_quoted_post_id_and_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_quoted_posts_on_quoted_post_id_and_post_id ON quoted_posts USING btree (quoted_post_id, post_id);


--
-- TOC entry 2905 (class 1259 OID 18450)
-- Name: index_screened_emails_on_email; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_screened_emails_on_email ON screened_emails USING btree (email);


--
-- TOC entry 2906 (class 1259 OID 18453)
-- Name: index_screened_emails_on_last_match_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_screened_emails_on_last_match_at ON screened_emails USING btree (last_match_at);


--
-- TOC entry 2922 (class 1259 OID 18612)
-- Name: index_screened_ip_addresses_on_ip_address; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_screened_ip_addresses_on_ip_address ON screened_ip_addresses USING btree (ip_address);


--
-- TOC entry 2923 (class 1259 OID 18613)
-- Name: index_screened_ip_addresses_on_last_match_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_screened_ip_addresses_on_last_match_at ON screened_ip_addresses USING btree (last_match_at);


--
-- TOC entry 2907 (class 1259 OID 18483)
-- Name: index_screened_urls_on_last_match_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_screened_urls_on_last_match_at ON screened_urls USING btree (last_match_at);


--
-- TOC entry 2908 (class 1259 OID 18482)
-- Name: index_screened_urls_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_screened_urls_on_url ON screened_urls USING btree (url);


--
-- TOC entry 2954 (class 1259 OID 18806)
-- Name: index_single_sign_on_records_on_external_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_single_sign_on_records_on_external_id ON single_sign_on_records USING btree (external_id);


--
-- TOC entry 2858 (class 1259 OID 17743)
-- Name: index_site_customizations_on_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_site_customizations_on_key ON site_customizations USING btree (key);


--
-- TOC entry 2877 (class 1259 OID 18149)
-- Name: index_site_texts_on_text_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_site_texts_on_text_type ON site_texts USING btree (text_type);


--
-- TOC entry 2937 (class 1259 OID 18733)
-- Name: index_top_topics_on_daily_likes_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_daily_likes_count ON top_topics USING btree (daily_likes_count DESC);


--
-- TOC entry 2938 (class 1259 OID 18731)
-- Name: index_top_topics_on_daily_posts_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_daily_posts_count ON top_topics USING btree (daily_posts_count DESC);


--
-- TOC entry 2939 (class 1259 OID 18732)
-- Name: index_top_topics_on_daily_views_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_daily_views_count ON top_topics USING btree (daily_views_count DESC);


--
-- TOC entry 2940 (class 1259 OID 18727)
-- Name: index_top_topics_on_monthly_likes_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_monthly_likes_count ON top_topics USING btree (monthly_likes_count DESC);


--
-- TOC entry 2941 (class 1259 OID 18725)
-- Name: index_top_topics_on_monthly_posts_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_monthly_posts_count ON top_topics USING btree (monthly_posts_count DESC);


--
-- TOC entry 2942 (class 1259 OID 18726)
-- Name: index_top_topics_on_monthly_views_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_monthly_views_count ON top_topics USING btree (monthly_views_count DESC);


--
-- TOC entry 2943 (class 1259 OID 18721)
-- Name: index_top_topics_on_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_top_topics_on_topic_id ON top_topics USING btree (topic_id);


--
-- TOC entry 2944 (class 1259 OID 18730)
-- Name: index_top_topics_on_weekly_likes_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_weekly_likes_count ON top_topics USING btree (weekly_likes_count DESC);


--
-- TOC entry 2945 (class 1259 OID 18728)
-- Name: index_top_topics_on_weekly_posts_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_weekly_posts_count ON top_topics USING btree (weekly_posts_count DESC);


--
-- TOC entry 2946 (class 1259 OID 18729)
-- Name: index_top_topics_on_weekly_views_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_weekly_views_count ON top_topics USING btree (weekly_views_count DESC);


--
-- TOC entry 2947 (class 1259 OID 18724)
-- Name: index_top_topics_on_yearly_likes_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_yearly_likes_count ON top_topics USING btree (yearly_likes_count DESC);


--
-- TOC entry 2948 (class 1259 OID 18722)
-- Name: index_top_topics_on_yearly_posts_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_yearly_posts_count ON top_topics USING btree (yearly_posts_count DESC);


--
-- TOC entry 2949 (class 1259 OID 18723)
-- Name: index_top_topics_on_yearly_views_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_top_topics_on_yearly_views_count ON top_topics USING btree (yearly_views_count DESC);


--
-- TOC entry 2892 (class 1259 OID 18267)
-- Name: index_topic_allowed_groups_on_group_id_and_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_groups_on_group_id_and_topic_id ON topic_allowed_groups USING btree (group_id, topic_id);


--
-- TOC entry 2893 (class 1259 OID 18268)
-- Name: index_topic_allowed_groups_on_topic_id_and_group_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_groups_on_topic_id_and_group_id ON topic_allowed_groups USING btree (topic_id, group_id);


--
-- TOC entry 2832 (class 1259 OID 17549)
-- Name: index_topic_allowed_users_on_topic_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_users_on_topic_id_and_user_id ON topic_allowed_users USING btree (topic_id, user_id);


--
-- TOC entry 2833 (class 1259 OID 17550)
-- Name: index_topic_allowed_users_on_user_id_and_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_users_on_user_id_and_topic_id ON topic_allowed_users USING btree (user_id, topic_id);


--
-- TOC entry 2985 (class 1259 OID 19006)
-- Name: index_topic_custom_fields_on_topic_id_and_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_custom_fields_on_topic_id_and_name ON topic_custom_fields USING btree (topic_id, name);


--
-- TOC entry 2934 (class 1259 OID 18689)
-- Name: index_topic_embeds_on_embed_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_embeds_on_embed_url ON topic_embeds USING btree (embed_url);


--
-- TOC entry 2844 (class 1259 OID 17676)
-- Name: index_topic_invites_on_invite_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_invites_on_invite_id ON topic_invites USING btree (invite_id);


--
-- TOC entry 2845 (class 1259 OID 17675)
-- Name: index_topic_invites_on_topic_id_and_invite_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_invites_on_topic_id_and_invite_id ON topic_invites USING btree (topic_id, invite_id);


--
-- TOC entry 2772 (class 1259 OID 19093)
-- Name: index_topic_links_on_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_links_on_post_id ON topic_links USING btree (post_id);


--
-- TOC entry 2773 (class 1259 OID 16926)
-- Name: index_topic_links_on_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_links_on_topic_id ON topic_links USING btree (topic_id);


--
-- TOC entry 2766 (class 1259 OID 16912)
-- Name: index_topic_users_on_topic_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_users_on_topic_id_and_user_id ON topic_users USING btree (topic_id, user_id);


--
-- TOC entry 2767 (class 1259 OID 19377)
-- Name: index_topic_users_on_user_id_and_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_users_on_user_id_and_topic_id ON topic_users USING btree (user_id, topic_id);


--
-- TOC entry 2756 (class 1259 OID 19291)
-- Name: index_topic_views_on_topic_id_and_viewed_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_views_on_topic_id_and_viewed_at ON topic_views USING btree (topic_id, viewed_at);


--
-- TOC entry 2757 (class 1259 OID 19292)
-- Name: index_topic_views_on_viewed_at_and_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_views_on_viewed_at_and_topic_id ON topic_views USING btree (viewed_at, topic_id);


--
-- TOC entry 2732 (class 1259 OID 17395)
-- Name: index_topics_on_bumped_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topics_on_bumped_at ON topics USING btree (bumped_at DESC);


--
-- TOC entry 2733 (class 1259 OID 18517)
-- Name: index_topics_on_id_and_deleted_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topics_on_id_and_deleted_at ON topics USING btree (id, deleted_at);


--
-- TOC entry 2822 (class 1259 OID 18637)
-- Name: index_twitter_user_infos_on_twitter_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_twitter_user_infos_on_twitter_user_id ON twitter_user_infos USING btree (twitter_user_id);


--
-- TOC entry 2823 (class 1259 OID 17442)
-- Name: index_twitter_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_twitter_user_infos_on_user_id ON twitter_user_infos USING btree (user_id);


--
-- TOC entry 2760 (class 1259 OID 18515)
-- Name: index_uploads_on_id_and_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_uploads_on_id_and_url ON uploads USING btree (id, url);


--
-- TOC entry 2761 (class 1259 OID 18396)
-- Name: index_uploads_on_sha1; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_uploads_on_sha1 ON uploads USING btree (sha1);


--
-- TOC entry 2762 (class 1259 OID 18397)
-- Name: index_uploads_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_uploads_on_url ON uploads USING btree (url);


--
-- TOC entry 2763 (class 1259 OID 16901)
-- Name: index_uploads_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_uploads_on_user_id ON uploads USING btree (user_id);


--
-- TOC entry 2807 (class 1259 OID 17302)
-- Name: index_user_actions_on_acting_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_actions_on_acting_user_id ON user_actions USING btree (acting_user_id);


--
-- TOC entry 2808 (class 1259 OID 17301)
-- Name: index_user_actions_on_user_id_and_action_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_actions_on_user_id_and_action_type ON user_actions USING btree (user_id, action_type);


--
-- TOC entry 2994 (class 1259 OID 19055)
-- Name: index_user_avatars_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_avatars_on_user_id ON user_avatars USING btree (user_id);


--
-- TOC entry 2963 (class 1259 OID 19033)
-- Name: index_user_badges_on_badge_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_badges_on_badge_id_and_user_id ON user_badges USING btree (badge_id, user_id);


--
-- TOC entry 2964 (class 1259 OID 19113)
-- Name: index_user_badges_on_badge_id_and_user_id_and_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_user_badges_on_badge_id_and_user_id_and_post_id ON user_badges USING btree (badge_id, user_id, post_id) WHERE (post_id IS NOT NULL);


--
-- TOC entry 2965 (class 1259 OID 19320)
-- Name: index_user_badges_on_badge_id_and_user_id_and_seq; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_user_badges_on_badge_id_and_user_id_and_seq ON user_badges USING btree (badge_id, user_id, seq) WHERE (post_id IS NULL);


--
-- TOC entry 2973 (class 1259 OID 18952)
-- Name: index_user_custom_fields_on_user_id_and_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_custom_fields_on_user_id_and_name ON user_custom_fields USING btree (user_id, name);


--
-- TOC entry 2878 (class 1259 OID 18525)
-- Name: index_user_histories_on_acting_user_id_and_action_and_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_histories_on_acting_user_id_and_action_and_id ON user_histories USING btree (acting_user_id, action, id);


--
-- TOC entry 2879 (class 1259 OID 18454)
-- Name: index_user_histories_on_action_and_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_histories_on_action_and_id ON user_histories USING btree (action, id);


--
-- TOC entry 2880 (class 1259 OID 18496)
-- Name: index_user_histories_on_subject_and_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_histories_on_subject_and_id ON user_histories USING btree (subject, id);


--
-- TOC entry 2881 (class 1259 OID 18456)
-- Name: index_user_histories_on_target_user_id_and_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_histories_on_target_user_id_and_id ON user_histories USING btree (target_user_id, id);


--
-- TOC entry 2801 (class 1259 OID 17243)
-- Name: index_user_open_ids_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_open_ids_on_url ON user_open_ids USING btree (url);


--
-- TOC entry 2997 (class 1259 OID 19293)
-- Name: index_user_profiles_on_bio_cooked_version; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_profiles_on_bio_cooked_version ON user_profiles USING btree (bio_cooked_version);


--
-- TOC entry 2848 (class 1259 OID 17686)
-- Name: index_user_visits_on_user_id_and_visited_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_user_visits_on_user_id_and_visited_at ON user_visits USING btree (user_id, visited_at);


--
-- TOC entry 2740 (class 1259 OID 17242)
-- Name: index_users_on_auth_token; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_users_on_auth_token ON users USING btree (auth_token);


--
-- TOC entry 2741 (class 1259 OID 19187)
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (lower((email)::text));


--
-- TOC entry 2742 (class 1259 OID 17199)
-- Name: index_users_on_last_posted_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_users_on_last_posted_at ON users USING btree (last_posted_at);


--
-- TOC entry 2743 (class 1259 OID 19303)
-- Name: index_users_on_last_seen_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_users_on_last_seen_at ON users USING btree (last_seen_at);


--
-- TOC entry 2744 (class 1259 OID 18916)
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_username ON users USING btree (username);


--
-- TOC entry 2745 (class 1259 OID 18917)
-- Name: index_users_on_username_lower; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_username_lower ON users USING btree (username_lower);


--
-- TOC entry 2748 (class 1259 OID 19328)
-- Name: index_versions_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_created_at ON versions USING btree (created_at);


--
-- TOC entry 2749 (class 1259 OID 16807)
-- Name: index_versions_on_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_number ON versions USING btree (number);


--
-- TOC entry 2750 (class 1259 OID 16808)
-- Name: index_versions_on_tag; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_tag ON versions USING btree (tag);


--
-- TOC entry 2751 (class 1259 OID 16805)
-- Name: index_versions_on_user_id_and_user_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_user_id_and_user_type ON versions USING btree (user_id, user_type);


--
-- TOC entry 2752 (class 1259 OID 16806)
-- Name: index_versions_on_user_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_user_name ON versions USING btree (user_name);


--
-- TOC entry 2753 (class 1259 OID 16804)
-- Name: index_versions_on_versioned_id_and_versioned_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_versioned_id_and_versioned_type ON versions USING btree (versioned_id, versioned_type);


--
-- TOC entry 3018 (class 1259 OID 19376)
-- Name: index_warnings_on_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_warnings_on_topic_id ON warnings USING btree (topic_id);


--
-- TOC entry 3019 (class 1259 OID 19375)
-- Name: index_warnings_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_warnings_on_user_id ON warnings USING btree (user_id);


--
-- TOC entry 2758 (class 1259 OID 19290)
-- Name: ip_address_topic_id_topic_views; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX ip_address_topic_id_topic_views ON topic_views USING btree (ip_address, topic_id) WHERE (user_id IS NULL);


--
-- TOC entry 2776 (class 1259 OID 16969)
-- Name: post_timings_summary; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX post_timings_summary ON post_timings USING btree (topic_id, post_number);


--
-- TOC entry 2777 (class 1259 OID 16970)
-- Name: post_timings_unique; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX post_timings_unique ON post_timings USING btree (topic_id, post_number, user_id);


--
-- TOC entry 2794 (class 1259 OID 19094)
-- Name: unique_index_categories_on_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX unique_index_categories_on_name ON categories USING btree ((COALESCE(parent_category_id, (-1))), name);


--
-- TOC entry 2774 (class 1259 OID 17343)
-- Name: unique_post_links; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX unique_post_links ON topic_links USING btree (topic_id, post_id, url);


--
-- TOC entry 2727 (class 1259 OID 16731)
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- TOC entry 2759 (class 1259 OID 19289)
-- Name: user_id_topic_id_topic_views; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX user_id_topic_id_topic_views ON topic_views USING btree (user_id, topic_id) WHERE (user_id IS NOT NULL);


-- Completed on 2014-12-26 10:49:06 UTC

--
-- PostgreSQL database dump complete
--

